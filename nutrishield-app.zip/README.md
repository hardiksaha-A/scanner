# NutriShield: Scan, Know, Choose Healthy

Smart product ingredient scanner and health analysis app (Android, built with Capacitor). Scan a food label or barcode and get an ingredient-by-ingredient rating, a 0-100 product score, a hazard level, nutrition effects and advice for your age, allergies and special modes. **No AI is used:** scanning, databases and fixed rules only (see `docs/SCORING.md`).

## Features (problem-statement checklist)
| Requirement | Status |
|---|---|
| Ingredient scanner (camera + upload, on-device OCR) | Done. Google's on-device text reader first (Android), Tesseract as fallback; both work offline |
| Two common applications of each ingredient | Done. 354 ingredients, about 5,950 recognised names (E-numbers plus French, German, Spanish, Italian, Portuguese and Dutch additive names), each with 2 real uses |
| Registration: name, age, allergies; Pregnancy and Senior modes | Done |
| Barcode scan; check if two products are the same | Done |
| Ingredient rating /100, overall score, hazard level with explanation | Done |
| Calories and nutrition details with health effects | Done |
| Daily-consumption question and advice | Done |
| Compare products of the same type | Done, side by side with products from your history, favourites and built-in benchmarks (works offline) |
| Who can consume / who should avoid | Done |
| Voice assistant reads results aloud | Done (device text-to-speech) |
| Light / dark mode | Done |
| Language | Done. English active; add languages in `www/lang/`. The country selector was removed (nothing depended on it) |
| Favourites and scan history | Done |
| Feedback, report an issue, satisfaction rating | Done |
| Data stored locally | Done. Server sync not built |
| Food now, other categories later | Food only |
| Show how correct the rating is | Done: confidence, rated/not-rated counts, self-test result |

## How to scan
Take or upload a photo, then drag a box around the **ingredient list (and nutrition table)**. Licence and contact text is then never read. If the text is still noisy, the app matches known ingredient names inside that area and marks the result low confidence. Always check the text box.

## How consistency works
Camera, upload and barcode all use the same analysis. Each result shows a **Match ID** (NS-xxxxxx): the same product gives the same Match ID on every route. A pack listed in `data/products.csv` is recognised even from a partly unreadable photo.

## Install / build
1. Put `nutrishield-app.zip` (do not unzip) and `build.yaml` in your GitHub repo; `build.yaml` goes in `.github/workflows/`.
2. Run the workflow. Download the APK from the run artifacts or the `latest` release.
3. Signed release APK: see `docs/RELEASE.md`.

## Folders
- `www/` the app that ships (`index.html` UI; `engine.js` scoring; `nutrition.js`; `advice.js` modes; `smartscan.js` and `shim.js` OCR)
- `data/products.csv` offline barcode list (turned into `www/localdb.js` on every build)
- `scripts/` build checks: `verify.js`, `selftest.js`, `accuracy.js` + `labels.json`, `modes-test.js`, `build-localdb.js`
- `docs/` scoring method and release steps
- `android-icons/` launcher icons and splash

## Tests (run on every build; the build fails if one fails)
`node scripts/verify.js` runs: consistency self-test, offline-barcode agreement, 25 reference labels (`accuracy.js`), 17 Pregnancy/Senior cases (`modes-test.js`). The OCR engine is copied in by `scripts/prep.js`, so run `npm ci && node scripts/prep.js` first.

## Legal and security
See `docs/PRIVACY_POLICY.md`, `docs/TERMS.md` (drafts: fill in the brackets and have a lawyer review) and `docs/SECURITY.md`. The app shows a medical-advice disclaimer, an About / licences screen and a Delete All My Local Data button. Android cloud backup and plain-http traffic are turned off in the build.

## Limits
- The on-device reader (ML Kit) is a machine-learning text reader, free and offline. Remove `@pantrist/capacitor-plugin-ml-kit-text-recognition` from `package.json` if your rules forbid it; the app then uses Tesseract only.
- OCR quality depends on photo focus, light and glare; always check the text box after a scan.
- The 25 reference labels are typed samples, not photographed packs.
- The offline product list holds only the products you add to `data/products.csv`.
- Pregnancy and Senior rules are general guidance; get them reviewed by a doctor or dietitian before release.
- Scores come from our rule set and are not medical advice. Always read the printed pack for allergens.
