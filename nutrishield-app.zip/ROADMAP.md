# NutriShield: order of work
Done (Phase 1, this build): one scan pipeline. Camera, upload and barcode feed the same analyser; footnotes and OCR header slips no longer change the result; Match ID (NS-xxxxxx) proves two scans are the same product; a scanned label is linked to its barcode and reused; self-test runs in `scripts/verify.js` during the CI build.

Done (Phase 2): every ingredient has two real uses (`uses.js` + inline rows); database grown from 155 to 235 entries and ~1,270 names/aliases (E-numbers, Indian names); yeast extract no longer scored as plain yeast.

Done (Phase 3): unknown ingredients show as "Not rated" chips; confidence line shows rated/not-rated counts and the self-test result; `scripts/labels.json` holds 25 reference labels checked by `scripts/accuracy.js` in every CI build (build fails if any drifts).

Done (Phase 4): offline barcode list. Add rows to `data/products.csv` (barcode, name, ingredients, nutrition per 100 g); `scripts/build-localdb.js` turns it into `www/localdb.js` on every build and rejects invalid barcodes. Lookup order: bundled list, your scanned label, device cache, Open Food Facts online. The seed row (Kurkure Masala Munch) must be confirmed against the pack.

Done (Phase 5): Pregnancy and Senior rules extended (raw/unpasteurised food, high-mercury fish, liver, energy-drink additives, vitamin A note; phosphate additives, potassium chloride, alcohol, liquorice, sugar alcohols, sodium additives for seniors) with 17 mode test cases run on every build (`scripts/modes-test.js`). Rules are general guidance, not medical advice; have a doctor or dietitian review them before release.

Done (Phase 5b, from real test: barcode 45 / camera 50 / upload 52): bundled verified entry now beats saved labels and cache; score uses recognised ingredients only; text box keeps only ingredients, allergen and nutrition lines; a partly unreadable photo of a pack in `data/products.csv` snaps to its verified entry.

Done (Phase 6): `legacy_unused/` removed; version 1.0.0; README, `docs/SCORING.md`, `docs/RELEASE.md`; optional signed release APK step in `build.yaml`; UI formula text corrected to match the code.

Done (Phase 7): crop step (draw a box around the ingredient and nutrition area before reading), list rescue for noisy text (`Engine.analyzeRobust`, only when the normal reading cannot score), allergy banner never says Clear on unreadable labels. Needs a real-phone test.

Done (Phase 8): crop box is now fixed with corner/edge handles (resize, move, reset); partial reads of a pack in `data/products.csv` ask 'Use verified data?'; 'Nutrition: not scanned' shown when the score is ingredients only.

Done (Phase 9): global additives batch. 118 new entries and 2,400+ extra names, built from the Open Food Facts additives reference (E-number identity checked by script; names in fr/de/es/it/pt/nl). Scores and hazards are judgement: review `docs/new-ingredients-review.csv` with an expert. Still to do for a world app: OCR data and ingredient names for other languages, allergen lists by region, banned-additive rules by country.

Done (Phase 10): Google ML Kit on-device text reader added (Capacitor plugin 6.2.1, matches Capacitor 6) and tried first; Tesseract is the fallback; the build retries without the plugin if it fails. Needs a real-phone test.

Done (Phase 11, safety): consent box no longer pre-ticked, disclaimer on every result, About / licences / data credits screen, Google Lens wording and unregistered trademark signs removed, Android backup and cleartext traffic off, draft privacy policy, terms and security notes. Still needs a lawyer's review, a dietitian's review of the special modes, and a decision on the minimum age.

Done (Phase 12, from phone test): sharp crop preview (screen-density aware), separate Ingredients and Nutrition boxes, every new scan clears the old product, link to a barcode only when it had no ingredient list, 'How this score was computed' panel. Same ingredients plus same nutrition now give the same score on every route (self-test: overall 45 for the reference pack).

Done (Phase 13, stress and security tests): `scripts/stress-test.js` found and fixed (1) a freeze on one huge unbroken word, (2) a crash when saved allergies were damaged, (3) damaged history/favourites storage; input is now capped (8,000 characters, 80 per word). `docs/TESTING.md` lists the device-level attack and load tests to run on the APK.

Next, in this order:
3b. Replace the typed reference labels with your own photographed packs (add to `scripts/labels.json`).
