# NutriShield: order of work
Done (Phase 1, this build): one scan pipeline. Camera, upload and barcode feed the same analyser; footnotes and OCR header slips no longer change the result; Match ID (NS-xxxxxx) proves two scans are the same product; a scanned label is linked to its barcode and reused; self-test runs in `scripts/verify.js` during the CI build.

Done (Phase 2): every ingredient has two real uses (`uses.js` + inline rows); database grown from 155 to 235 entries and ~1,270 names/aliases (E-numbers, Indian names); yeast extract no longer scored as plain yeast.

Done (Phase 3): unknown ingredients show as "Not rated" chips; confidence line shows rated/not-rated counts and the self-test result; `scripts/labels.json` holds 25 reference labels checked by `scripts/accuracy.js` in every CI build (build fails if any drifts).

Done (Phase 4): offline barcode list. Add rows to `data/products.csv` (barcode, name, ingredients, nutrition per 100 g); `scripts/build-localdb.js` turns it into `www/localdb.js` on every build and rejects invalid barcodes. Lookup order: bundled list, your scanned label, device cache, Open Food Facts online. The seed row (Kurkure Masala Munch) must be confirmed against the pack.

Done (Phase 5): Pregnancy and Senior rules extended (raw/unpasteurised food, high-mercury fish, liver, energy-drink additives, vitamin A note; phosphate additives, potassium chloride, alcohol, liquorice, sugar alcohols, sodium additives for seniors) with 17 mode test cases run on every build (`scripts/modes-test.js`). Rules are general guidance, not medical advice; have a doctor or dietitian review them before release.

Done (Phase 5b, from real test: barcode 45 / camera 50 / upload 52): bundled verified entry now beats saved labels and cache; score uses recognised ingredients only; text box keeps only ingredients, allergen and nutrition lines; a partly unreadable photo of a pack in `data/products.csv` snaps to its verified entry.

Done (Phase 6): `legacy_unused/` removed; version 1.0.0; README, `docs/SCORING.md`, `docs/RELEASE.md`; optional signed release APK step in `build.yaml`; UI formula text corrected to match the code.

Done (Phase 7): crop step (draw a box around the ingredient and nutrition area before reading), list rescue for noisy text (`Engine.analyzeRobust`, only when the normal reading cannot score), allergy banner never says Clear on unreadable labels. Needs a real-phone test.

Next, in this order:
3b. Replace the typed reference labels with your own photographed packs (add to `scripts/labels.json`).
