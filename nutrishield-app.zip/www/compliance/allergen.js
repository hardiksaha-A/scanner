// Allergen result states. A scan can never "clear" a product: the best outcome is NO_MATCH_IN_AVAILABLE_INFO and it is worded as such.
(function (root) {
  'use strict';
  const dep = (n, f) => root[n] || (typeof require === 'function' ? require(f) : null);
  const Engine = dep('Engine', '../engine.js');
  const STATES = Object.freeze({ MATCH: 'MATCH_DETECTED', MAY: 'MAY_CONTAIN_DETECTED', NO_MATCH: 'NO_MATCH_IN_AVAILABLE_INFO', INCOMPLETE: 'INFO_INCOMPLETE',
    OCR_UNCERTAIN: 'OCR_UNCERTAIN', NOT_POSSIBLE: 'NOT_POSSIBLE', OUTDATED: 'DATA_OUTDATED_OR_UNAVAILABLE', NONE: 'NO_ALLERGIES_SET' });
  // Safety heuristics (product decisions, NOT legal rules and NOT score thresholds). Adjustable, reviewed with the safety QA.
  const DEFAULTS = { minCoverage: 0.8, minTextChars: 15, staleDays: 365 };
  const MAY_RE = /(may contain|might contain|can contain|could contain|traces? of|trace amounts?|manufactured (in|on|at)|made (in|on)|produced (in|on)|processed (in|on)|packed (in|on)|same (facility|factory|line|equipment)|shared (facility|equipment))/;
  const esc = s => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // Allergy entries: >=3 letters use the engine's term lists; exactly 2 letters match WHOLE WORDS only; anything else cannot be checked and is reported, never dropped silently.
  function normalise(list) {
    const seen = new Set(), checkable = [], unchecked = [];
    for (const raw of [].concat(list || [])) {
      const t = String(raw == null ? '' : raw).toLowerCase().replace(/\s+/g, ' ').trim(); if (!t || seen.has(t)) continue; seen.add(t);
      const letters = (t.match(/[a-z]/g) || []).length;
      if (!letters) unchecked.push({ term: t, reason: /[^\x00-\x7f]/.test(t) ? 'non_latin' : 'too_short' });
      else if (letters < 2) unchecked.push({ term: t, reason: 'too_short' });
      else checkable.push({ term: t, mode: letters === 2 ? 'word' : 'engine' });
    }
    return { checkable, unchecked };
  }
  function wordHits(term, texts, tags) {
    const out = [], re = new RegExp('(^|[^a-z])' + esc(term) + '(s|es)?(?![a-z])');
    for (const tx of texts) for (const s of String(tx || '').toLowerCase().split(/[.\n;|]+/)) if (s.trim() && re.test(s)) { const may = MAY_RE.test(s); out.push({ kind: may ? 'may' : 'contains', text: (may ? 'may contain traces of ' : 'contains ') + term }); }
    for (const g of tags.declared) if (re.test(String(g).replace(/-/g, ' '))) out.push({ kind: 'contains', text: 'declares the allergen "' + String(g).replace(/-/g, ' ') + '"' });
    for (const g of tags.traces) if (re.test(String(g).replace(/-/g, ' '))) out.push({ kind: 'may', text: 'may contain traces of "' + String(g).replace(/-/g, ' ') + '"' });
    return out;
  }
  function collect(norm, ing, product, texts) {
    const out = [], done = new Set(), add = (allergy, kind, text) => { const k = allergy + '|' + kind; if (!done.has(k)) { done.add(k); out.push({ allergy, kind, text }); } };
    const names = new Set(norm.checkable.filter(c => c.mode === 'engine').map(c => c.term));
    if (ing && ing.warnings) ing.warnings.forEach(w => { if (names.has(String(w.allergy).toLowerCase().trim())) add(w.allergy, w.kind, (w.kind === 'may' ? 'may contain traces of ' : 'contains ') + w.ingredient); });
    if (product) names.forEach(a => {
      const terms = Engine.termsFor(a), hit = tags => (tags || []).find(t => { const s = String(t).replace(/-/g, ' '); return terms.some(x => s.includes(x) || x.includes(s)); });
      const d = hit(product.allergens); if (d) add(a, 'contains', 'declares the allergen "' + d.replace(/-/g, ' ') + '"');
      const tr = hit(product.traces); if (tr) add(a, 'may', 'may contain traces of "' + tr.replace(/-/g, ' ') + '"');
    });
    const tags = { declared: (product && product.allergens) || [], traces: (product && product.traces) || [] };
    norm.checkable.filter(c => c.mode === 'word').forEach(c => wordHits(c.term, texts, tags).forEach(h => add(c.term, h.kind, h.text)));
    return out;
  }
  const fmtDate = ms => { try { return new Date(ms).toISOString().slice(0, 10); } catch (e) { return ''; } };
  function sourceInfo(o, now, cfg) {
    const p = o.product, kind = o.source || (p ? 'off' : 'label_text'); let label, dataDate = null, cachedAt = null, stale = false;
    if (kind === 'bundled') label = 'NutriShield bundled sample list (not confirmed against the pack)';
    else if (kind === 'off' || kind === 'cache') {
      label = 'Open Food Facts (community-edited data)';
      if (p && Number.isFinite(p.lastModified) && p.lastModified > 0) dataDate = p.lastModified * 1000;
      if (kind === 'cache' && p && Number.isFinite(p.cachedAt)) cachedAt = p.cachedAt;
      const old = ms => ms !== null && (now - ms) > cfg.staleDays * 86400000; stale = old(dataDate) || old(cachedAt);
    } else label = 'Text read from your photo or typed by you';
    return { kind, label, dataDate: dataDate ? fmtDate(dataDate) : '', cachedAt: cachedAt ? fmtDate(cachedAt) : '', stale };
  }
  // Quality of the information for the allergies that had no match. Never returns a reassuring state unless every condition holds.
  function quality(o, ing, product, src, cfg) {
    const txt = String(o.text || (product && product.ingredients) || '').trim();
    if (!ing || !txt) return { state: product ? STATES.INCOMPLETE : STATES.NOT_POSSIBLE, why: product ? 'The product record has no ingredient list.' : 'No ingredient text was available.' };
    if (txt.length < cfg.minTextChars || ing.coverage < 0.6 || ing.rescued) return { state: src.kind === 'label_text' || ing.rescued ? STATES.OCR_UNCERTAIN : STATES.INCOMPLETE, why: src.kind === 'label_text' || ing.rescued ? 'The label text was not read clearly enough.' : 'The ingredient text is hard to interpret.' };
    if (ing.coverage < cfg.minCoverage) return { state: STATES.INCOMPLETE, why: 'Part of the ingredient text was not recognised.' };
    if (src.stale) return { state: STATES.OUTDATED, why: 'This product data may be out of date' + (src.dataDate ? ' (updated ' + src.dataDate + ')' : '') + '.' };
    return { state: STATES.NO_MATCH, why: '' };
  }
  function assess(o) {
    o = o || {}; const cfg = Object.assign({}, DEFAULTS, o.config || {}), now = o.now == null ? Date.now() : o.now, norm = normalise(o.allergies);
    const ing = o.ing || null, product = o.product || null, src = sourceInfo(o, now, cfg);
    const res = { state: STATES.NONE, items: [], matches: [], checkedTerms: norm.checkable.map(c => c.term), uncheckedTerms: norm.unchecked, source: src, reassuring: false, spoken: '' };
    if (!norm.checkable.length && !norm.unchecked.length) return res;
    const hits = collect(norm, ing, product, [o.text, product && product.ingredients].filter(Boolean)); res.matches = hits;
    hits.forEach(h => res.items.push({ tone: h.kind === 'contains' ? 'red' : 'amber', icon: '🚨', title: h.kind === 'contains' ? 'ALLERGY WARNING' : 'MAY CONTAIN TRACES', body: 'This product ' + h.text + ' (you listed "' + h.allergy + '").' }));
    const hitSet = new Set(hits.map(h => h.allergy)), rest = res.checkedTerms.filter(t => !hitSet.has(t));
    let status = null;
    if (rest.length) {
      const q = quality(o, ing, product, src, cfg), list = rest.join(', ');
      const dateNote = src.dataDate ? ' Data last updated ' + src.dataDate + '.' : (src.kind === 'off' || src.kind === 'cache' ? ' Data update date unknown.' : '');
      const srcLine = ' Source: ' + src.label + '.' + dateNote + (src.cachedAt ? ' Saved on this device ' + src.cachedAt + '.' : '');
      const T = {
        [STATES.NO_MATCH]: ['info', 'ℹ️', 'No match found in the available information', 'Nothing matching ' + list + ' was found in the information NutriShield has. This does NOT mean the product is free of it: data can be incomplete, wrong or out of date, and cross-contact is not covered. Read the current printed pack.'],
        [STATES.INCOMPLETE]: ['amber', '⚠️', 'Product information incomplete', q.why + ' NutriShield cannot rule out ' + list + '. Read the printed pack.'],
        [STATES.OCR_UNCERTAIN]: ['amber', '⚠️', 'Label reading uncertain', q.why + ' NutriShield cannot rule out ' + list + '. Retake the photo or read the printed pack.'],
        [STATES.NOT_POSSIBLE]: ['amber', '⚠️', 'Allergy check not possible', q.why + ' NutriShield could not check ' + list + '. Read the printed pack.'],
        [STATES.OUTDATED]: ['amber', '⚠️', 'Product data may be outdated', q.why + ' NutriShield cannot rule out ' + list + '. Read the current printed pack.']
      }[q.state];
      res.items.push({ tone: T[0], icon: T[1], title: T[2], body: T[3] + srcLine }); status = q.state;
    }
    if (norm.unchecked.length) res.items.push({ tone: 'amber', icon: '⚠️', title: 'Some entries cannot be checked', body: 'Not checked: ' + norm.unchecked.map(u => '"' + u.term + '" (' + (u.reason === 'non_latin' ? 'non-English text is not supported' : 'too short to match reliably') + ')').join(', ') + '. Read the printed pack for these.' });
    // Overall state = the most cautious applicable outcome.
    res.state = hits.some(h => h.kind === 'contains') ? STATES.MATCH : hits.length ? STATES.MAY : norm.unchecked.length ? STATES.NOT_POSSIBLE : status;
    res.reassuring = res.state === STATES.NO_MATCH;
    res.spoken = hits.length ? 'Allergy warning. See the screen for details.' : res.reassuring ? 'No allergy match found in the available information. This is not a guarantee. Read the printed pack.' : 'Allergy check incomplete. Read the printed pack.';
    return res;
  }
  const api = { STATES, DEFAULTS, normalise, assess };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Allergen = api;
})(typeof window !== 'undefined' ? window : globalThis);
