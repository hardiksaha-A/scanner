// Every storage location the app writes. wipe.js and the tests are checked against this list.
(function (root) {
  'use strict';
  const E = (id, category, match, purpose, personal) => ({ id, category, match, purpose, personal: personal !== false });
  const ENTRIES = Object.freeze([
    E('profile', 'profile_basic', { key: 'nutrishield.profile' }, 'nickname, mode (+ health fields only while consent is active)'),
    E('suspended', 'health_data', { key: 'ns.suspended.v1' }, 'legacy health fields held unused until the user re-consents or deletes'),
    E('age', 'age_status', { key: 'ns.age.v1' }, 'self-declared age status'),
    E('consent', 'consent_records', { key: 'ns.consent.v1' }, 'consent ledger'),
    E('history', 'scan_history', { key: 'ls.history' }, 'scan history'),
    E('fav', 'favourites', { key: 'ls.fav' }, 'favourites'),
    E('labels', 'saved_labels', { prefix: 'ns_lbl_' }, 'OCR text saved per barcode'),
    E('cache', 'barcode_cache', { key: 'nutrishield.cache' }, 'offline product cache', false),
    E('feedback', 'feedback', { key: 'ls.feedback' }, 'feedback text'),
    E('theme', 'preferences', { key: 'nutrishield.theme' }, 'theme', false),
    E('lang', 'preferences', { key: 'nutrishield.lang' }, 'language', false),
    E('speak', 'preferences', { key: 'nutrishield.speak' }, 'auto voice', false),
    E('schema', 'preferences', { key: 'ns.schema' }, 'storage schema version and one-time migration notice', false)
  ]);
  // Things this app CANNOT delete from inside the WebView. Shown to the user after deletion.
  const NOT_DELETABLE = Object.freeze([
    { id: 'off_server_logs', text: 'Open Food Facts may hold request logs (barcode, IP address) on its own servers. NutriShield cannot delete them.' },
    { id: 'google_services', text: 'Google Play services / ML Kit manage their own downloaded models and any usage data. NutriShield cannot delete them.' },
    { id: 'webview_native_cache', text: 'The Android WebView disk cache is outside JavaScript control. To clear it: Android Settings > Apps > NutriShield > Storage > Clear cache (or Clear storage).' },
    { id: 'clipboard', text: 'Text you copied with "Export Saved Feedback" stays on the clipboard until replaced.' },
    { id: 'os_copies', text: 'Screenshots, recent-apps thumbnails, text-to-speech engine data, and any backup or copy you made yourself are outside the app.' }
  ]);
  function find(key) { return ENTRIES.find(e => e.match.key ? e.match.key === key : key.indexOf(e.match.prefix) === 0) || null; }
  function listKeys(st) { const out = []; for (let i = 0; i < st.length; i++) out.push(st.key(i)); return out; }
  const unregistered = st => listKeys(st).filter(k => !find(k));
  function deleteCategories(st, cats) {
    const set = new Set(cats), gone = [];
    for (const k of listKeys(st)) { const e = find(k); if (e && set.has(e.category)) { st.removeItem(k); gone.push(k); } }
    return gone;
  }
  const api = { ENTRIES, NOT_DELETABLE, find, listKeys, unregistered, deleteCategories };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Registry = api;
})(typeof window !== 'undefined' ? window : globalThis);
