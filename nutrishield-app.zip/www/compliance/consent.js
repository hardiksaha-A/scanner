// Append-only consent ledger (per purpose). Local evidence only; retention period for these records is UNSET pending counsel.
(function (root) {
  'use strict';
  const KEY = 'ns.consent.v1';
  const PURPOSES = Object.freeze({
    TERMS_PRIVACY: 'terms_privacy_ack',   // required to use the app
    HEALTH_PROFILE: 'health_profile',     // optional: allergies, conditions, pregnancy mode. Adults (self-declared) only
    LOCAL_HISTORY: 'local_history'        // optional: history, favourites, saved labels, offline product cache. Adults (self-declared) only
  });
  const ADULT_ONLY = new Set([PURPOSES.HEALTH_PROFILE, PURPOSES.LOCAL_HISTORY]);
  function createLedger(storage, opts) {
    opts = opts || {};
    const clock = opts.clock || (() => Date.now()), tz = opts.tz || (() => -new Date().getTimezoneOffset());
    const read = () => { try { const a = JSON.parse(storage.getItem(KEY)); return Array.isArray(a) ? a.filter(r => r && typeof r.purpose === 'string') : []; } catch (e) { return []; } };
    const write = a => { try { storage.setItem(KEY, JSON.stringify(a)); return true; } catch (e) { return false; } };
    const latest = p => { const a = read().filter(r => r.purpose === p); return a.length ? a[a.length - 1] : null; };
    const isActive = p => { const r = latest(p); return !!r && r.granted === true && !r.withdrawnAt; };
    function grant(purpose, ctx) {
      ctx = ctx || {};
      if (!Object.values(PURPOSES).includes(purpose)) { const e = new Error('unknown purpose'); e.code = 'UNKNOWN_PURPOSE'; throw e; }
      if (ADULT_ONLY.has(purpose) && ctx.ageStatus !== 'adult_self_declared') { const e = new Error('purpose not available for this age status'); e.code = 'AGE_NOT_PERMITTED'; throw e; }
      if (!ctx.noticeVersion) { const e = new Error('notice version required'); e.code = 'NOTICE_VERSION_REQUIRED'; throw e; }
      const a = read(), rec = { id: 'c' + a.length + '-' + clock(), purpose, granted: true, ts: new Date(clock()).toISOString(), tzOffsetMinutes: tz(),
        noticeVersion: ctx.noticeVersion, docVersions: ctx.docVersions || {}, lang: ctx.lang || 'en', ageStatus: ctx.ageStatus, ageVerified: false,
        method: 'in_app_checkbox_unverified', withdrawnAt: null };
      a.push(rec); if (!write(a)) { const e = new Error('could not store consent record'); e.code = 'STORAGE_FAILED'; throw e; } return rec;
    }
    function withdraw(purpose) {
      const a = read(); let hit = false;
      for (let i = a.length - 1; i >= 0; i--) if (a[i].purpose === purpose && a[i].granted && !a[i].withdrawnAt) { a[i].withdrawnAt = new Date(clock()).toISOString(); hit = true; break; }
      if (hit) write(a); return hit;
    }
    // Per-document acceptance. `current` = {docId: version}. A document is stale unless the user's latest active record
    // accepted exactly that version. Records without docVersions (older builds) count as accepting nothing. Nothing is rewritten.
    const acceptance = (p, current) => {
      const r = latest(p), acc = isActive(p) && r && r.docVersions && typeof r.docVersions === 'object' ? r.docVersions : {};
      const stale = Object.keys(current).filter(k => acc[k] !== current[k]);
      return { everAccepted: !!r, stale, current: stale.length === 0, accepted: Object.assign({}, acc) };
    };
    return { grant, withdraw, isActive, latest, acceptance, records: read };
  }
  const api = { KEY, PURPOSES, ADULT_ONLY, createLedger };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Consent = api;
})(typeof window !== 'undefined' ? window : globalThis);
