// Permission gate: what the current age status and consents allow. Pure functions + one cascade helper.
(function (root) {
  'use strict';
  const dep = (n, f) => root[n] || (typeof require === 'function' ? require(f) : null);
  const Age = dep('Age', './age.js'), Consent = dep('Consent', './consent.js'), Registry = dep('Registry', './registry.js');
  const P = Consent.PURPOSES, SUSPENDED = 'ns.suspended.v1';
  function permissions(ageRec, ledger) {
    const adult = Age.isAdultSelfDeclared(ageRec), health = adult && ledger.isActive(P.HEALTH_PROFILE), hist = adult && ledger.isActive(P.LOCAL_HISTORY);
    return { adult, childSafe: !adult, canOfferHealth: adult, healthActive: health, historyActive: hist, collectName: adult,
      modes: adult ? (health ? ['adult', 'kids', 'pregnancy', 'older'] : ['adult', 'kids', 'older']) : ['kids'] };
  }
  // Returns a copy that can never carry health fields, a pregnancy mode or a child's name unless allowed.
  function sanitizeProfile(profile, perms) {
    if (!profile || typeof profile !== 'object') return { profile: null, changed: false };
    const before = JSON.stringify(profile), p = JSON.parse(before);
    delete p.age;
    if (!perms.healthActive) { p.allergies = []; p.conditions = []; }
    if (!perms.collectName) p.name = '';
    // Not collected by this version: purge any value an earlier build saved (data minimisation).
    delete p.email; delete p.mobile; delete p.country; delete p.countrySource;
    if (!perms.modes.includes(p.mode)) p.mode = perms.modes[0];
    return { profile: p, changed: JSON.stringify(p) !== before };
  }
  function readJson(st, k) { try { return JSON.parse(st.getItem(k)); } catch (e) { return null; } }
  // Withdrawal cascade: stops processing and deletes the data that depended on the consent.
  function withdraw(env, purpose) {
    const { storage, ledger } = env, deleted = [];
    const had = ledger.withdraw(purpose);
    if (purpose === P.HEALTH_PROFILE) {
      const p = readJson(storage, 'nutrishield.profile');
      if (p) { p.allergies = []; p.conditions = []; if (p.mode === 'pregnancy') p.mode = 'adult'; storage.setItem('nutrishield.profile', JSON.stringify(p)); deleted.push('profile health fields'); }
      if (storage.getItem(SUSPENDED) !== null) { storage.removeItem(SUSPENDED); deleted.push(SUSPENDED); }
    } else if (purpose === P.LOCAL_HISTORY) {
      deleted.push.apply(deleted, Registry.deleteCategories(storage, ['scan_history', 'favourites', 'saved_labels', 'barcode_cache']));
    }
    return { withdrawn: had, deleted };
  }
  const api = { SUSPENDED, permissions, sanitizeProfile, withdraw };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Gate = api;
})(typeof window !== 'undefined' ? window : globalThis);
