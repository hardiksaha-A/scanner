// Delete All My Local Data across every WebView storage the app can reach, then verify and report.
(function (root) {
  'use strict';
  const dep = (n, f) => root[n] || (typeof require === 'function' ? require(f) : null);
  const Registry = dep('Registry', './registry.js');
  const KNOWN_IDB = ['keyval-store', 'tesseract'];
  const count = st => { try { return st ? st.length : 0; } catch (e) { return -1; } };
  async function deleteAll(env) {
    env = env || root; const rep = [];
    const step = async (store, fn) => { try { rep.push(Object.assign({ store }, await fn())); } catch (e) { rep.push({ store, status: 'error', detail: String((e && e.message) || e) }); } };
    const web = st => async () => { if (!env[st]) return { status: 'unsupported' }; const before = count(env[st]); env[st].clear(); const after = count(env[st]); return { status: after === 0 ? (before ? 'cleared' : 'empty') : 'partial', before, after }; };
    await step('localStorage', web('localStorage'));
    await step('sessionStorage', web('sessionStorage'));
    await step('indexedDB', async () => {
      const idb = env.indexedDB; if (!idb) return { status: 'unsupported' };
      const del = n => new Promise((res, rej) => { const r = idb.deleteDatabase(n); r.onsuccess = () => res('ok'); r.onerror = () => rej(r.error || new Error('delete failed')); r.onblocked = () => res('blocked'); });
      let names, listed = typeof idb.databases === 'function';
      names = listed ? (await idb.databases()).map(d => d.name).filter(Boolean) : KNOWN_IDB.slice();
      let blocked = 0; for (const n of names) if (await del(n) === 'blocked') blocked++;
      const left = listed ? (await idb.databases()).length : null;
      return { status: blocked || left ? 'partial' : (names.length ? 'cleared' : 'empty'), before: names.length, after: left, detail: listed ? '' : 'databases() unsupported: deleted known names only' };
    });
    await step('CacheStorage', async () => {
      if (!env.caches) return { status: 'unsupported' };
      const ks = await env.caches.keys(); for (const k of ks) await env.caches.delete(k);
      const left = (await env.caches.keys()).length; return { status: left ? 'partial' : (ks.length ? 'cleared' : 'empty'), before: ks.length, after: left };
    });
    await step('serviceWorkers', async () => {
      const sw = env.navigator && env.navigator.serviceWorker; if (!sw || !sw.getRegistrations) return { status: 'unsupported' };
      const rs = await sw.getRegistrations(); for (const r of rs) await r.unregister();
      const left = (await sw.getRegistrations()).length; return { status: left ? 'partial' : (rs.length ? 'cleared' : 'empty'), before: rs.length, after: left };
    });
    await step('cookies', async () => {
      const d = env.document; if (!d || typeof d.cookie !== 'string') return { status: 'unsupported' };
      const names = d.cookie.split(';').map(s => s.split('=')[0].trim()).filter(Boolean);
      names.forEach(n => { d.cookie = n + '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/'; });
      const left = d.cookie.split(';').filter(s => s.trim()).length; return { status: left ? 'partial' : (names.length ? 'cleared' : 'empty'), before: names.length, after: left };
    });
    const ok = rep.every(r => r.status !== 'error' && r.status !== 'partial');
    return { ok, report: rep, notDeletable: Registry.NOT_DELETABLE };
  }
  const api = { deleteAll };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Wipe = api;
})(typeof window !== 'undefined' ? window : globalThis);
