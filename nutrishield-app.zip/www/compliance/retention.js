// Data-category retention configuration. NO PERIOD IS HARD-CODED for any legally open question.
// maxAgeDays: null means "no automatic expiry; kept until the user deletes or withdraws". It is NOT a legal conclusion.
(function (root) {
  'use strict';
  const COUNSEL = 'COUNSEL_PENDING', USER = 'USER_CONTROLLED';
  const C = (id, label, extra) => Object.assign({ id, label, maxAgeDays: null, status: USER, legalControls: [], openQuestion: '' }, extra);
  const CATEGORIES = Object.freeze([
    C('profile_basic', 'Nickname, mode', { legalControls: ['SPDI r.5 purpose limitation', 'DPDP s.8 (scheduled)'], openQuestion: 'Operator role for local-only processing' }),
    C('age_status', 'Self-declared age status', { legalControls: ['DPDP s.9 (scheduled)'], openQuestion: 'Whether recording age status itself needs parental authorisation for under-18 users' }),
    C('health_data', 'Allergies, conditions, pregnancy mode', { legalControls: ['SPDI r.3, r.5 prior consent/withdrawal'], openQuestion: 'SPDI scope; MDSW classification' }),
    C('scan_history', 'Scan history', { openQuestion: 'Product decision on automatic expiry' }),
    C('favourites', 'Favourites'), C('saved_labels', 'Saved scanned labels (OCR text)', { openQuestion: 'Product decision on automatic expiry' }),
    C('barcode_cache', 'Offline product cache (capped at 100 entries)'), C('feedback', 'Feedback written by the user'),
    C('preferences', 'Theme, language, voice'),
    C('consent_records', 'Consent ledger', { status: COUNSEL, openQuestion: 'Retention period and whether a minimal record must survive deletion' }),
    C('parent_verification_evidence', 'Parent-verification evidence (none exists: verifier not configured)', { status: COUNSEL, openQuestion: 'Rule 10 method and evidence retention' }),
    C('rule8_3_seventh_schedule', 'DPDP Rule 8(3) one-year minimum (Seventh Schedule)', { status: COUNSEL, openQuestion: 'Applicability to NutriShield purposes; illustrations vs Schedule wording. NOT coded.' }),
    C('security_logs_rule6_1_e', 'DPDP Rule 6(1)(e) security-purpose retention', { status: COUNSEL, openQuestion: 'Applicability; app keeps no remote logs' }),
    C('cert_in_ict_logs', 'CERT-In 180-day ICT-system logs', { status: COUNSEL, openQuestion: 'Coverage of operator; no operator infrastructure exists yet' }),
    C('vendor_logs', 'Vendor-held logs (Open Food Facts, Google)', { status: COUNSEL, openQuestion: 'Vendor roles and retention: obtain from vendors' }),
    C('backups_diagnostics', 'Backups and diagnostics', { openQuestion: 'allowBackup=false is applied in CI; verify on a built APK' })
  ]);
  const PROTECTED = ['consent_records', 'parent_verification_evidence', 'rule8_3_seventh_schedule', 'security_logs_rule6_1_e', 'cert_in_ict_logs', 'vendor_logs'];
  const config = () => ({ version: 'retention-0.1-draft', categories: CATEGORIES.map(c => Object.assign({}, c)) });
  // Rejects any attempt to hard-code an unresolved period or a blanket period.
  function validate(cfg) {
    const errs = [];
    if (!cfg || !Array.isArray(cfg.categories)) return ['config missing categories'];
    for (const k of Object.keys(cfg)) if (/blanket|allUser|defaultPeriod|globalPeriod|oneYear/i.test(k)) errs.push('forbidden blanket key: ' + k);
    for (const c of cfg.categories) {
      if (PROTECTED.includes(c.id) && (c.maxAgeDays !== null || c.status !== COUNSEL)) errs.push(c.id + ': period must stay null and status COUNSEL_PENDING until counsel decides');
      if (c.maxAgeDays !== null && !(Number.isFinite(c.maxAgeDays) && c.maxAgeDays > 0)) errs.push(c.id + ': invalid maxAgeDays');
      if (c.maxAgeDays !== null && c.source !== 'PRODUCT_DECISION') errs.push(c.id + ': a numeric period needs source PRODUCT_DECISION (not a legal claim)');
    }
    return errs;
  }
  const expired = (savedAtMs, cat, now) => !!cat && cat.maxAgeDays !== null && Number.isFinite(savedAtMs) && ((now == null ? Date.now() : now) - savedAtMs) > cat.maxAgeDays * 86400000;
  const api = { CATEGORIES, PROTECTED, config, validate, expired };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Retention = api;
})(typeof window !== 'undefined' ? window : globalThis);
