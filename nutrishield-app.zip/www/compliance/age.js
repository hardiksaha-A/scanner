// Age status. Self-declared only. NOTHING in this module can produce a "verified" status.
(function (root) {
  'use strict';
  const KEY = 'ns.age.v1';
  const STATUS = Object.freeze({ UNKNOWN: 'unknown', UNDER18: 'under18', ADULT_SELF: 'adult_self_declared' });
  const iso = now => new Date(now == null ? Date.now() : now).toISOString();
  function record(status, source, now) {
    if (!Object.values(STATUS).includes(status)) status = STATUS.UNKNOWN;
    return { status, source: source || 'self_declared', verified: false, ts: iso(now), v: 1 };
  }
  // choice: 'adult' | 'under18' | anything else (including prefer-not-to-say / no choice) => unknown
  function declare(choice, now) {
    return record(choice === 'adult' ? STATUS.ADULT_SELF : choice === 'under18' ? STATUS.UNDER18 : STATUS.UNKNOWN, 'self_declared', now);
  }
  function fromLegacyAge(age, now) { // pre-2.0 profiles stored a free integer that nothing verified
    const n = typeof age === 'number' ? age : parseInt(age, 10);
    if (!Number.isFinite(n) || n < 1 || n > 120) return record(STATUS.UNKNOWN, 'legacy_age_field_invalid', now);
    return record(n >= 18 ? STATUS.ADULT_SELF : STATUS.UNDER18, 'legacy_age_field', now);
  }
  const isAdultSelfDeclared = r => !!r && r.status === STATUS.ADULT_SELF;
  const isChildSafe = r => !isAdultSelfDeclared(r); // unknown, under18 and missing all get child-safe defaults
  // Exact completed years (no calendar-year shortcut). Feb 29 births turn 18 on 1 March in a non-leap year: the later,
  // more conservative reading. That reading is an assumption for counsel, not a statement of law.
  function completedYears(dob, now) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(dob || '')); if (!m) return null;
    const y = +m[1], mo = +m[2], d = +m[3], t = new Date(now == null ? Date.now() : now);
    const chk = new Date(Date.UTC(y, mo - 1, d)); if (chk.getUTCFullYear() !== y || chk.getUTCMonth() !== mo - 1 || chk.getUTCDate() !== d) return null;
    const ty = t.getUTCFullYear(), tm = t.getUTCMonth() + 1, td = t.getUTCDate();
    let years = ty - y; const leapBirth = mo === 2 && d === 29, leapNow = (ty % 4 === 0 && ty % 100 !== 0) || ty % 400 === 0;
    const bm = leapBirth && !leapNow ? 3 : mo, bd = leapBirth && !leapNow ? 1 : d;
    if (tm < bm || (tm === bm && td < bd)) years--;
    return years < 0 ? null : years;
  }
  const isAdultByDob = (dob, now) => { const y = completedYears(dob, now); return y !== null && y >= 18; };
  function load(storage) { try { const r = JSON.parse(storage.getItem(KEY)); return r && Object.values(STATUS).includes(r.status) ? Object.assign(r, { verified: false }) : null; } catch (e) { return null; } }
  function save(storage, rec) { try { storage.setItem(KEY, JSON.stringify(rec)); return true; } catch (e) { return false; } }
  const api = { KEY, STATUS, declare, fromLegacyAge, isAdultSelfDeclared, isChildSafe, completedYears, isAdultByDob, load, save };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Age = api;
})(typeof window !== 'undefined' ? window : globalThis);
