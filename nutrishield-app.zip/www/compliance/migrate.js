// One-time storage migration (schema 1 -> 2). Never silently keeps data that this build cannot lawfully-safely use for a child.
(function (root) {
  'use strict';
  const dep = (n, f) => root[n] || (typeof require === 'function' ? require(f) : null);
  const Age = dep('Age', './age.js'), Registry = dep('Registry', './registry.js'), SCHEMA = 'ns.schema', SUSPENDED = 'ns.suspended.v1';
  const rd = (st, k) => { try { return JSON.parse(st.getItem(k)); } catch (e) { return null; } };
  function run(st, now) {
    const cur = rd(st, SCHEMA); if (cur && cur.v >= 2) return { ran: false, notices: cur.notices || [] };
    const notices = [], actions = [];
    let p = rd(st, 'nutrishield.profile'); if (p && (typeof p !== 'object' || Array.isArray(p))) p = null;
    if (p) {
      const rec = Age.load(st) || Age.fromLegacyAge(p.age, now); Age.save(st, rec); delete p.age; actions.push('legacy age field removed; status=' + rec.status);
      const al = [].concat(p.allergies || []).filter(x => typeof x === 'string'), co = [].concat(p.conditions || []).filter(x => typeof x === 'string');
      const hasHealth = al.length > 0 || co.length > 0 || p.mode === 'pregnancy';
      if (Age.isAdultSelfDeclared(rec)) {
        if (hasHealth) { st.setItem(SUSPENDED, JSON.stringify({ allergies: al, conditions: co, mode: p.mode })); notices.push('health_reconsent'); actions.push('health fields moved to suspended store (unused until consent)'); }
        if (p.mode === 'pregnancy') p.mode = 'adult';
        if (rd(st, 'ls.history') || rd(st, 'ls.fav') || Registry.listKeys(st).some(k => k.indexOf('ns_lbl_') === 0)) notices.push('history_reconsent');
      } else {
        if (hasHealth || st.getItem(SUSPENDED) !== null) notices.push('child_health_removed'); st.removeItem(SUSPENDED); p.name = ''; p.mode = 'kids';
        const gone = Registry.deleteCategories(st, ['scan_history', 'favourites', 'saved_labels', 'barcode_cache']); if (gone.length) notices.push('child_history_removed');
        actions.push('under-18/unknown: health fields, name and history deleted (' + gone.length + ' keys)');
      }
      p.allergies = []; p.conditions = []; st.setItem('nutrishield.profile', JSON.stringify(p));
    }
    st.setItem(SCHEMA, JSON.stringify({ v: 2, ts: new Date(now == null ? Date.now() : now).toISOString(), notices }));
    return { ran: true, actions, notices };
  }
  function dismissNotices(st) { const c = rd(st, SCHEMA); if (c) { c.notices = []; st.setItem(SCHEMA, JSON.stringify(c)); } }
  const api = { SCHEMA, run, dismissNotices };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Migrate = api;
})(typeof window !== 'undefined' ? window : globalThis);
