// India rules registry. DATA ONLY: nothing here is a legal conclusion. Reviewer status is NOT_REVIEWED_BY_COUNSEL.
// Behaviour is deliberately NOT gated on these dates: this build applies the strictest combination of the current
// SPDI-era controls and the scheduled DPDP child controls from day one, so commencement needs no rewrite.
(function (root) {
  'use strict';
  const GAZETTE_PENDING = 'Dates corroborated by secondary commentary only. Official Gazette verification (G.S.R. 843(E), G.S.R. 846(E)) NOT completed.';
  const IN = Object.freeze({
    code: 'IN', rulesVersion: 'in-rules-0.1-draft', reviewStatus: 'NOT_REVIEWED_BY_COUNSEL', lastChecked: '2026-11-25',
    // Separate concepts, never one "consent age" constant (research report 15.1).
    ages: Object.freeze({
      majority: { value: 18, source: 'Majority Act 1875 s.3' },
      dpdpChild: { value: 18, source: 'DPDP Act 2023 s.2(f) (under 18)' },
      digitalConsent: { value: null, note: 'No separate DPDP 13/16 threshold identified' }
    }),
    regimes: Object.freeze([
      { id: 'IN-SPDI-CURRENT', label: 'IT Act s.43A / SPDI Rules 2011 (current)', effectiveTo: '2027-05-13', verification: GAZETTE_PENDING,
        note: 'Treatment of existing consents/records after s.44(2) commencement is a counsel question; this build does not assume SPDI ceases.' },
      { id: 'IN-DPDP-CHILD', label: 'DPDP Act ss.3-17 incl. s.9; Rules 3, 5-16, 22-23 (scheduled)', effectiveFrom: '2027-05-13', verification: GAZETTE_PENDING },
      { id: 'IN-DPDP-RULE4', label: 'DPDP s.6(9), Rule 4 Consent Managers', effectiveFrom: '2026-11-13', verification: GAZETTE_PENDING },
      { id: 'IN-S.O.5458E', label: 'Removal of Difficulties Order S.O. 5458(E), 5 Oct 2026', verification: 'UNVERIFIED: Gazette text not retrieved by research or this audit. Do not rely on its wording.' }
    ]),
    // Controls are static (not date-gated). Values are enforced by gate.js.
    controls: Object.freeze({
      selfDeclaredAgeIsVerified: false,
      unknownAgeTreatedAsChild: true,
      healthProfileUnder18: 'BLOCKED_PENDING_COUNSEL',
      healthProfileUnknownAge: 'BLOCKED',
      historyUnderOrUnknownAge: 'BLOCKED',
      parentVerification: 'NOT_CONFIGURED',
      childTracking: 'PROHIBITED', childTargetedAds: 'PROHIBITED',
      rule8_3: 'UNRESOLVED_COUNSEL_GATE'
    })
  });
  const BUILD_EPOCH = Date.parse('2026-11-25T00:00:00Z');
  // A rolled-back device clock must not select an earlier (weaker) description of the regime.
  const effectiveNow = now => Math.max(now == null ? Date.now() : +now, BUILD_EPOCH);
  function dpdpChildStatus(now) {
    const from = Date.parse('2027-05-13T00:00:00+05:30');
    return effectiveNow(now) >= from ? 'SCHEDULED_COMMENCEMENT_REACHED_PER_UNVERIFIED_DATE' : 'SCHEDULED_NOT_YET_COMMENCED_PER_UNVERIFIED_DATE';
  }
  function forCountry(code) { // only India is researched; every other value gets the same strict controls plus a flag
    return { rules: IN, researched: String(code || '').toUpperCase() === 'IN', strictestApplied: true };
  }
  const api = { IN, effectiveNow, dpdpChildStatus, forCountry, GAZETTE_PENDING };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Rules = api;
})(typeof window !== 'undefined' ? window : globalThis);
