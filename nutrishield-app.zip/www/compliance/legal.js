// DRAFT legal documents. Single source for the in-app viewer and docs/*.md. NOT reviewed by counsel, NOT approved, NOT production-ready.
// Statements about app behaviour describe this build. Publisher identity, contacts, governing law, liability wording and retention periods
// are deliberately left as [REQUIRED INPUT: ...] placeholders: nothing here is invented.
(function (root) {
  'use strict';
  // Each document has its OWN version. Bump a document's version only for a material change that needs fresh acceptance
  // (new data use or sharing, changed rights or liability). Editorial fixes keep the version. Users re-accept only the document that changed.
  const VERSIONS = Object.freeze({ privacy: 'draft-0.2.0', terms: 'draft-0.1.0' });
  const HISTORY = Object.freeze({
    privacy: Object.freeze([
      { version: 'draft-0.1.0', change: 'First draft.' },
      { version: 'draft-0.2.0', change: 'States that email address, mobile number and country are not collected, and discloses that data on the device is stored without extra encryption by NutriShield.' }]),
    terms: Object.freeze([{ version: 'draft-0.1.0', change: 'First draft.' }])
  });
  const R = t => '[REQUIRED INPUT: ' + t + ']';
  const STATUS = Object.freeze({ approved: false, reviewer: null, approvedOn: null,
    banner: 'DRAFT. Placeholders are not completed. Not reviewed by legal counsel. Not approved for production or publication.' });
  const privacy = { id: 'privacy', title: 'Privacy Policy', version: VERSIONS.privacy, sections: [
    { h: 'Document status', p: [STATUS.banner, 'Effective date: ' + R('effective date after counsel approval')] },
    { h: 'Who is responsible', p: ['Publisher: ' + R('legal name and legal form of the publisher'), 'Address: ' + R('registered postal address'), 'Contact: ' + R('contact email'),
      'Grievance contact: ' + R('name, designation and contact of the grievance officer; counsel to confirm the requirement')] },
    { h: 'What NutriShield stores on your device', p: [
      '- Self-declared age status (adult, under 18, or not stated). NutriShield cannot verify your age.',
      '- An optional nickname (adults only) and your selected mode.',
      '- NutriShield does not ask for or store your email address, mobile number or country.',
      '- Only if you separately agree: allergies, health conditions and pregnancy mode (health profile). Adults only.',
      '- Only if you separately agree: scan history, favourites, scanned label text and an offline product cache.',
      '- Feedback you write, theme, language and voice settings, and a record of the consents you gave or withdrew.',
      'NutriShield has no account system and no server of its own. In this version it does not send this data to the publisher.'] },
    { h: 'Age and children', p: [
      'You tell the app whether you are 18 or older. This is not checked. If you say you are under 18, or do not say, NutriShield switches to child-safe defaults: no health profile, no nickname, no history or favourites, stricter scoring checks, and no advertising or tracking.',
      'Parental authorisation is not available in this version. Because of that, a health profile cannot be created for anyone under 18 or whose age is not stated.',
      'Counsel to confirm: ' + R('consent and guardian process for under-18 users under current and future Indian law')] },
    { h: 'Health information (optional)', p: [
      'Allergies, health conditions and pregnancy mode are health-related. They are used only on your device to adjust results. You can use barcode and label scanning without them.',
      'You can withdraw this consent at any time in Settings. Withdrawing deletes the health information from the app.'] },
    { h: 'Camera and photos', p: ['The camera and photos are used to read labels and barcodes. The app does not save or upload your photos. Text reading runs on your device. Google ML Kit and Google Play services may download text-reading models and may send usage or performance data to Google: ' + R('confirm exact Google ML Kit / Google Play services data practices for the released build')] },
    { h: 'What leaves your device', p: [
      '- Barcode lookup: when you scan a barcode that is not in the app or in your saved cache, the barcode number is sent to Open Food Facts (openfoodfacts.org). Open Food Facts also sees your IP address and ordinary connection details.',
      '- Compare feature: to find similar products, the app sends a product category name to Open Food Facts.',
      '- No profile, age, allergy, health, history or feedback data is sent to Open Food Facts.',
      '- Open Food Facts role, logs and retention: ' + R('confirm from Open Food Facts directly'),
      'The app has no advertising, analytics or crash-reporting service.'] },
    { h: 'How long data is kept', p: [
      'This version does not delete data automatically. Data stays on your device until you delete it or withdraw a consent.',
      'Statutory retention periods: ' + R('retention periods per data category, pending written Indian counsel advice'),
      'Consent record retention: ' + R('period pending counsel'), 'Parent-verification evidence retention: ' + R('not applicable until a verification method is approved')] },
    { h: 'Your choices and deletion', p: [
      'Settings lets you withdraw each consent, delete health data, delete history/favourites/saved labels, and delete everything stored by the app.',
      'Some things cannot be deleted by the app: Open Food Facts server logs, Google-managed data, the Android WebView disk cache (clear it in Android Settings > Apps > NutriShield > Storage), text you copied to the clipboard, and copies you made elsewhere.'] },
    { h: 'Security of data on your device', p: ['Everything NutriShield stores is kept on your device. In this version NutriShield does not add its own encryption to that data. It relies on your phone\'s own protections, such as the screen lock. Anyone who can unlock your phone or read the app\'s data (for example on a rooted device) may be able to read it. You can delete it at any time in Settings.'] },
    { h: 'Changes', p: ['If features that collect or share data are added (for example ads, accounts or cloud sync), this policy will be updated and consent asked again where required.'] }
  ] };
  const terms = { id: 'terms', title: 'Terms of Use', version: VERSIONS.terms, sections: [
    { h: 'Document status', p: [STATUS.banner, 'Effective date: ' + R('effective date after counsel approval')] },
    { h: '1. Information only', p: ['NutriShield gives general, rule-based information about ingredients and nutrition. It is not medical, dietary or allergy advice and does not replace a doctor, dietitian or the printed label.'] },
    { h: '2. Check the pack', p: ['Always read the current printed pack, especially for allergies. Camera reading can make mistakes, product data can be incomplete or out of date, and the app cannot know about cross-contact or recipe changes. A result of "no match found" is never a guarantee that a product is safe for you.'] },
    { h: '3. Scores are opinions', p: ['Scores and hazard levels are NutriShield\'s own rule-based assessments. They are not official ratings, certifications or statements about any brand.'] },
    { h: '4. Special modes', p: ['Pregnancy and Senior modes give general guidance only. Ask a qualified professional about your situation.'] },
    { h: '5. Age', p: ['You tell the app your age status yourself and it is not verified. Use of the health profile and history features is limited as described in the Privacy Policy.'] },
    { h: '6. Third-party data', p: ['Product data comes from Open Food Facts and other open sources and may be incomplete or wrong.'] },
    { h: '7. No warranty and liability', p: [R('warranty disclaimer and limitation of liability wording approved by counsel')] },
    { h: '8. Trademarks', p: ['Product names and trademarks belong to their owners. No affiliation or endorsement is implied.'] },
    { h: '9. Changes, governing law and disputes', p: ['Changes to these terms: ' + R('change procedure'), 'Governing law: ' + R('governing law'), 'Courts / dispute resolution: ' + R('forum')] },
    { h: '10. Contact', p: [R('contact email and postal address')] }
  ] };
  const docs = { privacy, terms };
  const PH = /\[REQUIRED INPUT:[^\]]*\]/g;
  const textOf = d => d.sections.map(s => s.h + '\n' + s.p.join('\n')).join('\n');
  function placeholders() { const all = []; Object.values(docs).forEach(d => (textOf(d).match(PH) || []).forEach(x => all.push(x))); return Array.from(new Set(all)); }
  const placeholderCount = () => Object.values(docs).reduce((n, d) => n + (textOf(d).match(PH) || []).length, 0);
  // Production readiness requires BOTH an approval record and zero placeholders. Shipped build has neither.
  const isProductionReady = () => !!(STATUS.approved && STATUS.reviewer && STATUS.approvedOn) && placeholderCount() === 0;
  function toMarkdown(d) { return '# NutriShield ' + d.title + ' (' + d.version + ')\n\n> ' + STATUS.banner + '\n> Generated from www/compliance/legal.js. Edit that file, not this one.\n\n' + d.sections.map(s => '## ' + s.h + '\n' + s.p.map(x => x.charAt(0) === '-' ? x : x + '\n').join('\n')).join('\n\n') + '\n\n## Version history\n\n' + (HISTORY[d.id] || []).map(h => '- ' + h.version + ': ' + h.change).join('\n') + '\n'; }
  function toHtml(d, esc) {
    const hi = s => esc(s).replace(/\[REQUIRED INPUT:[^\]]*\]/g, m => '<mark class="req">' + m + '</mark>');
    return d.sections.map(s => '<h3>' + esc(s.h) + '</h3>' + s.p.map(x => x.charAt(0) === '-' ? '<p class="li">' + hi(x.slice(1).trim()) + '</p>' : '<p>' + hi(x) + '</p>').join('')).join('');
  }
  const api = { VERSIONS, HISTORY, STATUS, docs, placeholders, placeholderCount, isProductionReady, toMarkdown, toHtml };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Legal = api;
})(typeof window !== 'undefined' ? window : globalThis);
