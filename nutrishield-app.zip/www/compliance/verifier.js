// ParentVerifier interface. THIS IS NOT A VERIFICATION SYSTEM. No provider is configured or approved in this build.
// Even if a provider were installed, health-profile processing for under-18 users stays BLOCKED by Rules.controls until counsel decides.
(function (root) {
  'use strict';
  const REQUIRED = ['startVerification', 'checkResult', 'withdraw'];
  let provider = null;
  const NOT_CONFIGURED = Object.freeze({ configured: false, operational: false, code: 'NOT_CONFIGURED', label: 'Parental authorisation is not available in this version of NutriShield.' });
  const status = () => provider ? Object.freeze({ configured: true, operational: false, code: 'PROVIDER_INSTALLED_UNREVIEWED', label: 'A verification provider is installed but has not been tested or approved for use.' }) : NOT_CONFIGURED;
  async function verify() { return { ok: false, code: provider ? 'PROVIDER_NOT_APPROVED' : 'NOT_CONFIGURED', verified: false }; }
  // Future use only: needs a provider object and a counsel approval reference. Never called by the shipped app.
  function install(p, meta) {
    if (!p || !REQUIRED.every(m => typeof p[m] === 'function')) throw Object.assign(new Error('provider must implement ' + REQUIRED.join(', ')), { code: 'BAD_PROVIDER' });
    if (!meta || !meta.counselApprovalRef || !meta.methodId) throw Object.assign(new Error('counsel approval reference and methodId required'), { code: 'APPROVAL_REQUIRED' });
    provider = p;
  }
  const _resetForTests = () => { provider = null; };
  const api = { REQUIRED, status, verify, install, _resetForTests };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.ParentVerifier = api;
})(typeof window !== 'undefined' ? window : globalThis);
