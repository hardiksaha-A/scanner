// Extract: turns raw OCR text (a whole pack, noise and all) into ONLY what NutriShield scores:
// the ingredient list, allergen statements and a validated nutrition table. Camera, upload and barcode
// all go through the same functions, so the same product gives the same result.
(function (root) {
  'use strict';
  const NODE = typeof module !== 'undefined' && module.exports;
  const eng = () => (NODE ? require('./engine.js') : root.Engine);
  const rowsSrc = () => (NODE ? require('./ingredients.js') : root.INGREDIENT_ROWS) || [];
  const has = v => typeof v === 'number' && isFinite(v);
  const letters = s => String(s || '').toLowerCase().replace(/[^a-z]/g, '');

  function lev(a, b, max) {
    if (Math.abs(a.length - b.length) > max) return max + 1;
    let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i++) {
      const cur = [i]; let best = i;
      for (let j = 1; j <= b.length; j++) { cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); if (cur[j] < best) best = cur[j]; }
      if (best > max) return max + 1; prev = cur;
    }
    return prev[b.length];
  }

  // ---------- what is NOT an ingredient ----------
  const END = /(\*\s*as\s|[\u2018\u2019'"\u201C*]\s*as\s+flavou?ring|as flavou?ring agent|to know the specific|batch n|nutrition|nutritional|per 100\s*(g|ml)|serve size|serving size|may contain|might contain|contains\s*:|allergen|manufactured|marketed|mfd|best before|use by|storage|fssai|\bmrp\b|net (wt|weight|qty|quantity)|approximate|unit sale|customer care|consumer (care|services)|distributed by|imported by|packed by|store in|keep in|dated:|for (feedback|queries)|\bpack\s*<)/i;
  const NOISE = /(\blic(ence|ense)?\b\.?\s*(no|number)|fssai|\bmrp\b|\bmfd\b|marketed by|manufactured by|p\.?\s?o\.?\s?box|\b\d{6}\b|consumer (care|services)|customer care|toll free|\b1800[\s\d]{6,}|@[\w.]+|www\.|https?:|facebook|pvt\.?\s*ltd|registered trade ?mark|trade ?mark of|unit sale price|no\. of serves|batch n|packs? without|limited period)/i;
  const ALLERGEN_CUE = /\b(may contain|might contain|can contain|contains?\s*(:|wheat|milk|soy|soya|peanut|nuts?|gluten|egg|fish|sesame|mustard|celery|sulph|tree)|allergen|traces? of|(manufactured|processed|produced|packed) (in|on|at) )/i;

  // ---------- ingredient list ----------
  function headerAt(line) { // index in `line` where the ingredient list starts, or -1 (tolerates "INGK DIENTS", "IGREDIER TS", no colon)
    const re = /[:;]/g; let m;
    while ((m = re.exec(line))) {
      const pre = letters(line.slice(Math.max(0, m.index - 18), m.index));
      if (pre.length >= 6 && (lev(pre.slice(-11), 'ingredients', 4) <= 4 || lev(pre.slice(-10), 'ingredient', 3) <= 3 || /ingr|redie|gredi|dients/.test(pre.slice(-12)))) return m.index + 1;
    }
    const p = letters(line.slice(0, 22));
    if (p.length >= 8 && (lev(p.slice(0, 11), 'ingredients', 3) <= 3 || lev(p.slice(0, 10), 'ingredient', 2) <= 2)) {
      let seen = 0, i = 0; while (i < line.length && seen < 10) { if (/[a-z]/i.test(line[i])) seen++; i++; }
      while (i < line.length && /[^A-Za-z0-9(]/.test(line[i])) i++;
      return i;
    }
    return -1;
  }
  function endIdx(s) { const m = END.exec(s); return m ? m.index : -1; }
  const listy = l => { const a = (l.match(/[A-Za-z]/g) || []).length; return l.length > 3 && (a / l.length >= 0.4 || (l.match(/,/g) || []).length >= 2) && /[A-Za-z]{3,}/.test(l) && ((l.match(/[A-Za-z]{3,}/g) || []).length >= 2 || /[,()]/.test(l)); };

  let VOCAB = null;
  function vocab() {
    if (VOCAB) return VOCAB; VOCAB = new Set();
    const extra = 'ingredients products cereal vegetable flavouring flavour natural identical substances regulators acidity seasoning spices condiments iodised powder colour edible emulsifier emulsifiers preservative preservatives antioxidant antioxidants stabiliser stabilizer thickener sweetener permitted artificial nature vitamins minerals extract concentrate protein starch modified refined wheat flour sugar salt maltodextrin hydrolysed solids';
    extra.split(' ').forEach(w => VOCAB.add(w));
    rowsSrc().forEach(r => String(r).split('|').slice(0, 2).join(' ').toLowerCase().split(/[^a-z]+/).forEach(w => { if (w.length >= 5) VOCAB.add(w); }));
    return VOCAB;
  }
  function lexFix(text) { // repair single words damaged by OCR, only to a unique close word of the ingredient vocabulary
    const V = vocab(), list = Array.from(V);
    return text.replace(/[A-Za-z]{6,}/g, w => {
      const lw = w.toLowerCase(); if (V.has(lw)) return w;
      const max = lw.length <= 8 ? 1 : 2; let best = null, bd = max + 1, tie = false;
      for (const v of list) { if (v[0] !== lw[0] || Math.abs(v.length - lw.length) > max) continue; const d = lev(lw, v, max); if (d < bd) { bd = d; best = v; tie = false; } else if (d === bd) tie = true; }
      if (!best || tie || bd > max) return w;
      return w[0] === w[0].toUpperCase() ? best[0].toUpperCase() + best.slice(1) : best;
    });
  }
  function tidy(s) {
    return lexFix(String(s || '')
      .replace(/[\u00AE\u2122\u00A9]/g, '')
      .replace(/[\u201C\u201D\u2018\u2019`\u00B4|\u00A6_~=<>{}\u2022\u00A7\u25CA\u25CB#]/g, ' ')
      .replace(/^\s*[A-Z]{1,3}\s+(?=[A-Z][a-z])/, '')
      .replace(/\s+/g, ' ').replace(/\s+([,.)])/g, '$1').replace(/\(\s+/g, '(').trim());
  }
  function quality(text) {
    if (!text || text.trim().length < 8) return { q: 0, found: 0, cov: 0 };
    let r; try { r = eng().analyze(text, {}); } catch (e) { return { q: 0, found: 0, cov: 0 }; }
    return { q: r.found.length * 2 + Math.round(r.coverage * 3), found: r.found.length, cov: r.coverage };
  }
  function collect(lines, i, off) {
    const parts = []; const first = lines[i].slice(off), e0 = endIdx(first);
    if (e0 === 0) return '';
    if (e0 > 0) { parts.push(first.slice(0, e0)); return tidy(parts.join(' ')); }
    parts.push(first);
    for (let j = i + 1; j < lines.length && j < i + 14; j++) {
      const l = lines[j], e = endIdx(l);
      if (e === 0) break;
      if (NOISE.test(l) && !/,/.test(l)) break;
      if (e > 0) { parts.push(l.slice(0, e)); break; }
      if (!listy(l)) break;
      parts.push(l);
    }
    return tidy(parts.join(' '));
  }
  function density(lines) { // no heading found: the longest run of lines that really look like an ingredient list
    let best = '', bq = 0, run = [], gap = 0;
    const flush = () => { if (run.length) { const t = tidy(run.join(' ')), q = quality(t).q; if (q > bq) { bq = q; best = t; } } run = []; gap = 0; };
    for (const l of lines) {
      if (NOISE.test(l) && !/,/.test(l)) { flush(); continue; }
      const f = quality(l).found;
      if (f >= 2 || (f >= 1 && /,/.test(l))) { run.push(l.slice(0, (endIdx(l) > 0 ? endIdx(l) : l.length))); gap = 0; }
      else if (run.length && gap < 1 && listy(l)) { run.push(l); gap++; } else flush();
    }
    flush(); return best;
  }
  function ingredients(raw) { // best ingredient list found in the text ('' if none)
    const lines = String(raw || '').replace(/\r/g, '').split('\n').map(s => s.trim()).filter(Boolean);
    let best = '', bq = -1, method = 'none';
    lines.forEach((l, i) => { const o = headerAt(l); if (o < 0) return; const t = collect(lines, i, o), q = quality(t).q; if (t && q > bq) { bq = q; best = t; method = 'heading'; } });
    if (bq < 4) { const d = density(lines), dq = quality(d).q; if (dq > bq && dq >= 6) { best = d; bq = dq; method = 'pattern'; } }
    return { text: best, method, quality: bq < 0 ? 0 : bq };
  }
  function allergenText(raw) {
    const out = [];
    String(raw || '').replace(/\r/g, '').split(/\n|(?<=\.)\s+(?=[A-Z])/).map(s => s.trim()).forEach(l => {
      if (l.length < 8 || l.length > 220 || !ALLERGEN_CUE.test(l) || /pack\s*(<|contain)|consumption|nutrition|% rda/i.test(l) || NOISE.test(l)) return;
      const t = l.replace(/[\u201C\u201D\u2018\u2019`|]/g, ' ').replace(/\s+/g, ' ').trim(); if (!out.includes(t) && out.length < 3) out.push(t);
    });
    return out.join(' ');
  }

  // ---------- nutrition table ----------
  const L1 = (w, t, m) => lev(w, t, m) <= m;
  function labelOf(line) { // which nutrient does this row describe?
    const ws = line.toLowerCase().replace(/[^a-z\s]/g, ' ').split(/\s+/).filter(Boolean).slice(0, 3); if (!ws.length) return null;
    const [a, b = ''] = ws;
    if (a.length >= 5 && L1(a, 'energy', 2)) return 'kcal';
    if (a.length >= 5 && L1(a, 'protein', 2)) return 'protein';
    if (a.length >= 4 && (/^carb/.test(a) || L1(a, 'carbohydrate', 3) || L1(a, 'carbohydrates', 3))) return 'carbs';
    if (a.length >= 5 && L1(a, 'saturated', 3)) return 'sat';
    if (a.length >= 4 && L1(a, 'trans', 1)) return 'trans';
    if (a.length >= 5 && L1(a, 'sodium', 2)) return 'sodium';
    if (a === 'salt') return 'salt';
    if (a.length >= 4 && (L1(a, 'fibre', 1) || L1(a, 'fiber', 1))) return 'fibre';
    if (a === 'dietary' && /^fib/.test(b)) return 'fibre';
    if ((a === 'added' || L1(a, 'added', 1)) && /^sug/.test(b)) return 'added';
    if (/^(sugars?|ugars?)$/.test(a) || (['total', 'otal', 'tot', 'tota'].includes(a) && /^(sug|ug)/.test(b))) return 'sugars';
    if (a === 'fat' || (['total', 'otal', 'tot', 'tota'].includes(a) && b === 'fat')) return 'fat';
    return null;
  }
  function valueOf(line) { // first number after the row label, with its unit
    const l = line.replace(/\([^)]*\)/g, ' ').replace(/,/g, '.'), i = l.search(/\d/); if (i < 0) return null;
    const m = /(\d+(?:\.\d+)?)\s*(kcal|kj|mg|g)?/i.exec(l.slice(i));
    return m ? { v: parseFloat(m[1]), u: (m[2] || '').toLowerCase(), line: l } : null;
  }
  function sanitize(n) { // physical sanity checks; returns the cleaned table or null when it cannot be right
    if (!n) return null;
    const o = Object.assign({}, n);
    if (has(o.fat) && has(o.sat) && o.sat > o.fat + 0.05) o.sat = null;
    if (has(o.carbs) && has(o.sugars) && o.sugars > o.carbs + 0.05) o.sugars = null;
    if (has(o.salt) && (o.salt < 0 || o.salt > 30)) o.salt = null;
    const f = has(o.fat) ? o.fat : 0, c = has(o.carbs) ? o.carbs : 0, p = has(o.protein) ? o.protein : 0;
    if (f + c + p > 101) return null;
    if (has(o.kcal)) {
      if (o.kcal < 0 || o.kcal > 900) return null;
      const est = 9 * f + 4 * c + 4 * p + 2 * (has(o.fibre) ? o.fibre : 0), all = has(o.fat) && has(o.carbs) && has(o.protein);
      if (all && (est < o.kcal * 0.78 || est > o.kcal * 1.25)) return null;
      if (!all && est > o.kcal * 1.2 + 15) return null;
    }
    o.count = ['kcal', 'fat', 'sat', 'carbs', 'sugars', 'fibre', 'protein', 'salt'].filter(k => has(o[k])).length;
    return o;
  }
  function validate(n) { const o = sanitize(n); return o && o.count >= 4 && (has(o.kcal) || (has(o.fat) && has(o.carbs))) ? o : null; } // a photo-read table needs enough rows
  function nutrition(raw) { // parse an OCR'd table into per-100 g values, then validate
    const o = { kcal: null, fat: null, sat: null, carbs: null, sugars: null, fibre: null, protein: null, salt: null }; let sodium = null;
    String(raw || '').replace(/\r/g, '').split('\n').forEach(line => {
      if (line.length > 90 || (line.match(/,/g) || []).length >= 3) return;
      const k = labelOf(line.trim().replace(/^[^A-Za-z]+/, '')); if (!k || k === 'trans' || k === 'added') return;
      const r = valueOf(line); if (!r) return;
      if (k === 'kcal') { const kc = /(\d+(?:\.\d+)?)\s*kcal/i.exec(r.line), kj = /(\d+(?:\.\d+)?)\s*kj/i.exec(r.line); const v = kc ? +kc[1] : kj ? Math.round(+kj[1] / 4.184) : (r.u === 'kj' ? Math.round(r.v / 4.184) : r.v); if (o.kcal === null && v <= 900) o.kcal = v; }
      else if (k === 'sodium') { if (sodium === null) sodium = r.u === 'mg' || r.v > 20 ? r.v / 1000 : r.v; }
      else if (o[k] === null && r.v <= 100) o[k] = r.v;
    });
    if (o.salt === null && sodium !== null) o.salt = Math.round(sodium * 2.5 * 100) / 100;
    return validate(o);
  }
  const fmt = n => {
    if (!n) return ''; const r = [];
    if (has(n.kcal)) r.push('Energy ' + n.kcal + ' kcal');
    [['protein', 'Protein'], ['carbs', 'Carbohydrate'], ['sugars', 'Sugars'], ['fat', 'Fat'], ['sat', 'Saturated fat'], ['fibre', 'Fibre'], ['salt', 'Salt']].forEach(([k, l]) => { if (has(n[k])) r.push(l + ' ' + n[k] + ' g'); });
    return r.join('\n');
  };

  // ---------- same product? ----------
  function names(text) { try { return new Set(eng().analyze(text || '', {}).found.map(f => f.name)); } catch (e) { return new Set(); } }
  function similarity(a, b) { if (!a.size || !b.size) return { sim: 0, shared: 0, precision: 0, recall: 0 }; let s = 0; a.forEach(x => { if (b.has(x)) s++; }); return { sim: s / (a.size + b.size - s), shared: s, precision: s / a.size, recall: s / b.size }; }
  function identify(ingText, products) { // a known product whose verified ingredient list matches the scan closely
    const A = names(ingText); if (A.size < 4) return null; let best = null;
    (products || []).forEach(p => {
      if (!p || !p.ingredients) return; const B = names(p.ingredients), r = similarity(A, B);
      if (r.shared >= 5 && r.sim >= 0.5 && r.precision >= 0.8 && r.recall >= 0.5 && (!best || r.sim > best.sim)) best = { product: p, sim: r.sim, shared: r.shared };
    });
    return best;
  }
  function gtinsIn(text, isValid) { // printed digits under a barcode, e.g. "8 901491 367219"
    const out = [];
    String(text || '').split('\n').forEach(l => { const m = /^\W*(\d[\d \-]{6,18}\d)\W*$/.exec(l.trim()); if (m) { const d = m[1].replace(/\D/g, ''); if (isValid(d) && !out.includes(d)) out.push(d); } });
    return out;
  }

  // ---------- one entry point ----------
  // texts: raw OCR strings (whole page, ingredient crop, nutrition crop). products: known products for matching.
  function process(texts, products) {
    texts = [].concat(texts || []).filter(Boolean); const all = texts.join('\n');
    let ing = { text: '', method: 'none', quality: 0 };
    texts.concat([all]).forEach(t => { const r = ingredients(t); if (r.text && r.quality > ing.quality) ing = r; });
    let nut = null; texts.concat([all]).forEach(t => { if (!nut) nut = nutrition(t); });
    const allergen = allergenText(all), q = quality(ing.text), id = ing.text ? identify(ing.text, products) : null;
    let text = ing.text, n = nut, verified = false;
    if (id) { text = id.product.ingredients; n = validate(Object.assign({}, id.product.nutrition)) || id.product.nutrition || nut; verified = true; }
    const clean = (text ? 'Ingredients: ' + text : '') + (allergen ? '\nAllergen information: ' + allergen : '') + (n && !verified ? '\n' + fmt(n) : '');
    return { text, method: ing.method, found: q.found, coverage: q.cov, nutrition: n, allergen, identified: id, verified, clean: clean.trim(), gtins: [] };
  }

  const api = { process, ingredients, nutrition, validate, sanitize, identify, allergenText, gtinsIn, headerAt, endIdx, labelOf, format: fmt, quality, tidy, lev };
  if (NODE) module.exports = api; else root.Extract = api;
})(typeof window !== 'undefined' ? window : globalThis);
