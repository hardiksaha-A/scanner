// Pure geometry for the photo crop box (no DOM), so it can be tested. hit(): which part of the box a touch is on. move(): new box after a drag.
(function (root) {
  function hit(r, x, y, m) {
    const L = r.x, R = r.x + r.w, T = r.y, B = r.y + r.h, n = (a, b) => Math.abs(a - b) <= m;
    if (n(x, L) && n(y, T)) return 'tl'; if (n(x, R) && n(y, T)) return 'tr';
    if (n(x, L) && n(y, B)) return 'bl'; if (n(x, R) && n(y, B)) return 'br';
    if (n(y, T) && x > L && x < R) return 't'; if (n(y, B) && x > L && x < R) return 'b';
    if (n(x, L) && y > T && y < B) return 'l'; if (n(x, R) && y > T && y < B) return 'r';
    return (x > L && x < R && y > T && y < B) ? 'move' : null;
  }
  function move(r0, mode, dx, dy, W, H, min) {
    min = min || 40;
    let L = r0.x, T = r0.y, R = r0.x + r0.w, B = r0.y + r0.h;
    if (mode === 'move') { L = Math.max(0, Math.min(W - r0.w, L + dx)); T = Math.max(0, Math.min(H - r0.h, T + dy)); return { x: L, y: T, w: r0.w, h: r0.h }; }
    if (/l/.test(mode)) L = Math.max(0, Math.min(R - min, L + dx));
    if (/r/.test(mode)) R = Math.min(W, Math.max(L + min, R + dx));
    if (/t/.test(mode)) T = Math.max(0, Math.min(B - min, T + dy));
    if (/b/.test(mode)) B = Math.min(H, Math.max(T + min, B + dy));
    return { x: L, y: T, w: R - L, h: B - T };
  }
  const api = { hit, move };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Crop = api;
})(typeof window !== 'undefined' ? window : globalThis);
