// OCR worker wrapper. Android packaging can drop or rename *.gz assets and serves unknown file types without a
// content type, so the English language data is also shipped as a plain eng.lstm.bin and every request the OCR
// engine makes for "eng.traineddata[.gz]" is answered from that file. Everything else passes through untouched.
(function () {
  var base = self.location.origin + '/vendor/tess/', real = self.fetch.bind(self);
  self.fetch = function (input, init) {
    var url = typeof input === 'string' ? input : (input && input.url) || String(input);
    if (/\/lang\/eng\.traineddata(\.gz)?(\?.*)?$/.test(url)) return real(base + 'lang/eng.lstm.bin', init);
    return real(input, init);
  };
  importScripts(base + 'worker.min.js');
})();
