// Column-aware nutrition-table reader. It only READS numbers off label text; scoring stays in nutrition.js (unchanged, hash-pinned).
// Corrections vs the original first-number reader are listed in docs/SCANNER_PIPELINE_REPORT.md and tested in scripts/harness/parser-test.js.
(function (root) {
  'use strict';
  // ---- Column-aware reader (replaces the first-number rule). Separately identified corrections vs the original: see docs/SCANNER_PIPELINE_REPORT.md ----
  const HEADW = /per\s*100|per\s*serv|%\s*(rda|nrv|dv|ri)\b|\brda\b|\bnrv\b/i;
  const COLRE = /%\s*(?:rda|nrv|dv|ri|daily)\b(?:\s*(?:per|\/)\s*serv\w*)?|\brda\b|\bnrv\b|per\s*100\s*(?:g|ml)?|per\s*serv\w*|per\s*pack/gi;
  function headerCols(lines) {
    for (let i = 0; i < lines.length; i++) {
      if (!HEADW.test(lines[i])) continue;
      let h = lines[i]; for (let j = i + 1; j < Math.min(lines.length, i + 3) && HEADW.test(lines[j]); j++) h += ' | ' + lines[j];
      const cols = (h.toLowerCase().match(COLRE) || []).map(m => /per\s*100/.test(m) ? 'p100' : /per\s*pack/.test(m) ? 'pack' : /^%|rda|nrv/.test(m) ? 'rda' : 'serve');
      return cols.includes('p100') || cols.includes('serve') ? cols : null;
    }
    return null;
  }
  function fixDigits(line, fixes) { // 3O.4 -> 30.4, 1l5 -> 115 (only inside tokens that already hold a real digit; every change is logged)
    return line.replace(/(^|[^A-Za-z0-9])([0-9OoIl][0-9OoIl.,]*)(?=$|[^A-Za-z0-9]|(?:g|mg|kcal|kj|ml|mcg)\b)/g, (m, pre, tok) => {
      if (!/[0-9]/.test(tok)) return m; const f = tok.replace(/[Oo]/g, '0').replace(/[Il]/g, '1'); if (f !== tok) fixes.push(tok + ' -> ' + f); return pre + f;
    });
  }
  const numTokens = s => { const out = [], re = /(\d+(?:[.,]\d+)?)\s*(%)?/g; let m; while ((m = re.exec(s))) out.push({ v: parseFloat(m[1].replace(',', '.')), pct: !!m[2] }); return out; };
  function parseNutritionV2(text) {
    text = String(text == null ? '' : text).slice(0, 20000);
    const o = { kcal: null, fat: null, sat: null, carbs: null, sugars: null, fibre: null, protein: null, salt: null };
    const flags = [], corrections = []; let sodium = null, count = 0, paired = false;
    let lines = text.split(/\r?\n/).map(r => r.toLowerCase().replace(/\s+/g, ' ').trim());
    const sv = /serv(?:e|ing)\s*size\D{0,12}(\d+(?:[.,]\d+)?)\s*(g|ml)\b/i.exec(text), serving = sv ? parseFloat(sv[1].replace(',', '.')) + ' ' + sv[2].toLowerCase() : '';
    const cols = headerCols(lines), p100 = cols ? cols.indexOf('p100') : -1;
    const LAB = /energy|calorie|kcal|saturat|sat\.? fat|(^|\s)(total )?fat\b|carbohydrate|carbs|sugar|fib(re|er)|protein|salt|sodium/;
    const isLab = l => LAB.test(l) && !/\d/.test(l) && l.length < 40, isVal = l => /^[\s\d.,oOlI%]*\s*(kcal|kj|mg|g|ml)?\s*(\/\s*[\d.,]+\s*(kcal|kj|mg|g)?)?[\s\d.,%]*$/.test(l) && /\d/.test(l);
    const labIdx = lines.map((l, i) => isLab(l) ? i : -1).filter(i => i >= 0), valIdx = lines.map((l, i) => isVal(l) ? i : -1).filter(i => i >= 0);
    if (labIdx.length >= 3 && labIdx.length === valIdx.length) { // OCR gave all the labels, then all the numbers: pair them in order (flagged, never silent)
      lines = lines.slice(); labIdx.forEach((li, k) => { lines[li] = lines[li] + ' ' + lines[valIdx[k]]; lines[valIdx[k]] = ''; }); paired = true; flags.push('paired-by-order');
    }
    const set = (k, v, max) => { if (v !== null && v >= 0 && v <= max && o[k] === null) { o[k] = Math.round(v * 100) / 100; count++; } else if (v !== null && (v < 0 || v > max)) flags.push(k + '-out-of-range'); };
    const pick = tk => { // one number from a row, chosen by column
      if (!tk.length) return null;
      if (cols && cols.length && p100 >= 0) {
        if (tk.length === cols.length) return tk[p100].pct ? null : tk[p100].v;
        if (p100 === 0 && !tk[0].pct) return tk[0].v;
        flags.push('ambiguous-row'); return null;
      }
      if (cols && cols.length && p100 < 0) return null; // only per-serve / per-pack values on this label: not per 100 g
      const f = tk.find(t => !t.pct); if (tk.length > 1) flags.push('no-column-header'); return f ? f.v : null;
    };
    const tailOf = (l, re) => { const m = re.exec(l); return m ? l.slice(m.index + m[0].length) : null; };
    lines.forEach(raw => {
      if (!raw) return;
      const fixes = [], fx = fixDigits(raw, fixes); if (!/^\s*ingredients?/.test(fx) && fixes.length) corrections.push(...fixes);
      const l = fx;
      if (/^\s*ingredients?/.test(l) || (l.match(/,/g) || []).length >= 3) return;
      const l2 = l.replace(/\([^)]*\)/g, ' ');
      if (/energy|calorie|kcal/.test(l)) {
        const kc = [...l.matchAll(/(\d+(?:[.,]\d+)?)\s*kcal/g)].map(m => parseFloat(m[1].replace(',', '.'))), kj = [...l.matchAll(/(\d+(?:[.,]\d+)?)\s*kj/g)].map(m => parseFloat(m[1].replace(',', '.')));
        const idx = (arr) => (cols && p100 >= 0 && arr.length === cols.filter(c => c !== 'rda').length) ? cols.filter(c => c !== 'rda').indexOf('p100') : (cols && p100 > 0 && arr.length > 1 ? -1 : 0);
        if (kc.length) { const i = idx(kc); if (i < 0) flags.push('ambiguous-row'); else if (cols && p100 < 0) { /* per-serve only */ } else set('kcal', kc[i], 900); }
        else if (kj.length) { const i = idx(kj); if (i < 0) flags.push('ambiguous-row'); else if (!(cols && p100 < 0)) set('kcal', Math.round(kj[i] / 4.184), 900); }
        else { const tk = numTokens(tailOf(l2, /energy|calories?/) || ''), v = pick(tk.slice(0, 3)); if (v !== null) set('kcal', /\bkj\b/.test(l) && !/kcal/.test(l) ? Math.round(v / 4.184) : v, 900); }
      }
      if (/unsaturat/.test(l)) { /* mono / poly-unsaturated lines ignored */ }
      else if (/saturat|sat\.? fat/.test(l)) set('sat', pick(numTokens(tailOf(l2, /saturat\w*( fat(ty acids)?)?|sat\.? fat/) || '')), 100);
      else if (/trans/.test(l)) { /* trans fat ignored */ }
      else if (/(^|\s)(total )?fat\b/.test(l2) && !/low fat|fat free/.test(l)) set('fat', pick(numTokens(tailOf(l2, /(total )?fat\b/) || '')), 100);
      if (/carbohydrate|carbs/.test(l)) { const t = tailOf(l2, /carbohydrates?|carbs/); if (t !== null) set('carbs', pick(numTokens(t.split(/of which|sugar/)[0])), 100); }
      if (/sugar/.test(l) && !/added|no sugar|sugar free|sugar-free/.test(l)) set('sugars', pick(numTokens(tailOf(l2, /sugars?/) || '')), 100);
      if (/fib(re|er)/.test(l)) set('fibre', pick(numTokens(tailOf(l2, /(dietary )?fib(re|er)/) || '')), 100);
      if (/protein/.test(l)) set('protein', pick(numTokens(tailOf(l2, /proteins?/) || '')), 100);
      if (/salt/.test(l) && !/salted|saltin/.test(l)) { const v = pick(numTokens(tailOf(l2, /salt/) || '')); if (v !== null) set('salt', /\bmg\b/.test(l) ? v / 1000 : v, 30); }
      if (/sodium/.test(l) && sodium === null) { const v = pick(numTokens(tailOf(l2, /sodium/) || '')); if (v !== null) sodium = (/\bmg\b/.test(l) || v > 20) ? v / 1000 : v; }
    });
    if (o.salt === null && sodium !== null) set('salt', sodium * 2.5, 30);
    // Plausibility checks: reported, never corrected (the label numbers are kept as read)
    const g = k => (typeof o[k] === 'number' ? o[k] : null);
    if (g('sat') !== null && g('fat') !== null && o.sat > o.fat + 0.05) flags.push('sat-fat-above-total-fat');
    if (g('sugars') !== null && g('carbs') !== null && o.sugars > o.carbs + 0.05) flags.push('sugars-above-carbohydrate');
    if (g('fat') !== null && g('carbs') !== null && g('protein') !== null) {
      if (o.fat + o.carbs + o.protein > 100.5) flags.push('macros-above-100g');
      const calc = 4 * (o.carbs + o.protein) + 9 * o.fat; if (g('kcal') !== null && calc > 0 && Math.abs(o.kcal - calc) / calc > 0.25) flags.push('kcal-vs-macros-mismatch');
    }
    const basis = cols ? (p100 >= 0 ? 'per_100' : 'per_serve_or_pack_only') : 'assumed_per_100';
    if (cols && p100 < 0 && !flags.includes('per-serve-only')) flags.push('per-serve-only');
    return Object.assign(o, { count, basis, serving, paired, flags: Array.from(new Set(flags)), corrections });
  }
  const api = { parse: parseNutritionV2, headerCols, fixDigits };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.NutritionReader = api;
})(typeof window !== 'undefined' ? window : globalThis);
