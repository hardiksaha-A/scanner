// On-device text reader (Google ML Kit, via the Capacitor plugin). Used first on Android; the Tesseract reader stays as the fallback.
(function (root) {
  const NAME = 'CapacitorPluginMlKitTextRecognition', MAXSIDE = 2400;
  function plugin() {
    try {
      const C = root.Capacitor; if (!C || !C.isNativePlatform || !C.isNativePlatform()) return null;
      return (C.Plugins && C.Plugins[NAME]) || (C.registerPlugin && C.registerPlugin(NAME)) || null;
    } catch (e) { return null; }
  }
  const available = () => !!plugin();
  // Blocks come back in the reader's own order (it groups text by column); keep every line on its own row.
  function textFrom(res) {
    const blocks = (res && res.blocks) || [];
    if (!blocks.length) return String((res && res.text) || '').trim();
    return blocks.map(b => (b.lines && b.lines.length ? b.lines.map(l => l.text).join('\n') : (b.text || ''))).filter(Boolean).join('\n').trim();
  }
  function prepare(src, deg) { // src canvas -> JPEG data (no data: prefix), scaled to MAXSIDE, optionally turned 90/180/270 degrees
    const s = Math.min(1, MAXSIDE / Math.max(src.width, src.height)), w = Math.round(src.width * s), h = Math.round(src.height * s);
    const c = document.createElement('canvas'), turn = deg === 90 || deg === 270;
    c.width = turn ? h : w; c.height = turn ? w : h;
    const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
    x.translate(c.width / 2, c.height / 2); x.rotate(((deg || 0) * Math.PI) / 180); x.drawImage(src, -w / 2, -h / 2, w, h);
    return c.toDataURL('image/jpeg', 0.92).split(',')[1];
  }
  async function read(src, deg) {
    const p = plugin(); if (!p) throw new Error('native reader not available');
    return textFrom(await p.detectText({ base64Image: prepare(src, deg || 0), rotation: 0 }));
  }
  const api = { available, read, textFrom };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.NativeOcr = api;
})(typeof window !== 'undefined' ? window : globalThis);
