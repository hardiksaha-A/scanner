// On-device text reader (Google ML Kit, via the Capacitor plugin). Used first on Android; the Tesseract reader stays as the fallback.
(function (root) {
  const NAME = 'CapacitorPluginMlKitTextRecognition', MAXSIDE = 2400;
  function plugin() {
    try {
      const C = root.Capacitor; if (!C || !C.isNativePlatform || !C.isNativePlatform()) return null;
      return (C.Plugins && C.Plugins[NAME]) || (C.registerPlugin && C.registerPlugin(NAME)) || null;
    } catch (e) { return null; }
  }
  const available = () => !!plugin();
  // Blocks come back in the reader's own order (it groups text by column); keep every line on its own row.
  // Original behaviour: blocks in reading order, one line per text line. Added: a nutrient name and the numbers printed on the SAME row
  // (which ML Kit often returns as separate lines or blocks) are joined back into one line using the line boxes. Only nutrient rows are touched,
  // so multi-column ingredient text is never merged across columns. Without usable boxes the output is exactly the original.
  const NUT = /energy|calorie|kcal|saturat|(^|\s)(total )?fat\b|carbohydrate|carbs|sugar|fib(re|er)|protein|salt|sodium/i;
  const isValueLine = t => { const r = String(t).toLowerCase().replace(/kcal|kj|mg|mcg|µg|ml|g|%/g, ' ').replace(/[\s/()]/g, ''); return /\d/.test(t) && /^[\d.,oil]*$/.test(r) && !/[a-z]{2,}/.test(String(t).toLowerCase().replace(/kcal|kj|mg|mcg|ml/g, '')); };
  const okBox = b => b && [b.left, b.top, b.right, b.bottom].every(Number.isFinite) && b.right > b.left && b.bottom > b.top;
  function joinRows(items) { // items: [{text, box}] in reading order
    if (!items.every(i => okBox(i.box))) return items.map(i => i.text);
    const used = new Set(), out = [];
    items.forEach((it, i) => {
      if (used.has(i)) return;
      if (NUT.test(it.text) && !/\d/.test(it.text) && it.text.length < 40) {
        const cy = (it.box.top + it.box.bottom) / 2, hh = it.box.bottom - it.box.top;
        const vals = items.map((v, j) => ({ v, j })).filter(({ v, j }) => j !== i && !used.has(j) && isValueLine(v.text) && Math.abs((v.box.top + v.box.bottom) / 2 - cy) < 0.6 * hh && v.box.left >= it.box.right - 0.2 * hh).sort((a, b) => a.v.box.left - b.v.box.left);
        if (vals.length) { vals.forEach(({ j }) => used.add(j)); out.push(it.text + ' ' + vals.map(x => x.v.text).join(' ')); return; }
      }
      out.push(it.text);
    });
    return out;
  }
  function textFrom(res) {
    const blocks = (res && res.blocks) || [];
    if (!blocks.length) return String((res && res.text) || '').trim();
    const items = []; blocks.forEach(b => { if (b.lines && b.lines.length) b.lines.forEach(l => items.push({ text: l.text, box: l.boundingBox })); else if (b.text) items.push({ text: b.text, box: b.boundingBox }); });
    return joinRows(items.filter(i => i.text)).join('\n').trim();
  }
  function prepare(src, deg) { // src canvas -> JPEG data (no data: prefix), scaled to MAXSIDE, optionally turned 90/180/270 degrees
    const s = Math.min(1, MAXSIDE / Math.max(src.width, src.height)), w = Math.round(src.width * s), h = Math.round(src.height * s);
    const c = document.createElement('canvas'), turn = deg === 90 || deg === 270;
    c.width = turn ? h : w; c.height = turn ? w : h;
    const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
    x.translate(c.width / 2, c.height / 2); x.rotate(((deg || 0) * Math.PI) / 180); x.drawImage(src, -w / 2, -h / 2, w, h);
    return c.toDataURL('image/jpeg', 0.92).split(',')[1];
  }
  async function read(src, deg) {
    const p = plugin(); if (!p) throw new Error('native reader not available');
    return textFrom(await p.detectText({ base64Image: prepare(src, deg || 0), rotation: 0 }));
  }
  const api = { available, read, textFrom };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.NativeOcr = api;
})(typeof window !== 'undefined' ? window : globalThis);
