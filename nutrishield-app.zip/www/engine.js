// Rule-based ingredient analysis. No AI, no network. Works in browser and Node.
(function (root) {
  'use strict';
  const NODE = typeof module !== 'undefined' && module.exports;
  const rows = NODE ? require('./ingredients.js') : root.INGREDIENT_ROWS;
  const USES = NODE ? require('./uses.js') : (root.INGREDIENT_USES || {});
  const HAZ = { L: 'low', M: 'moderate', H: 'high' };
  const IGNORE = new Set(['preservative', 'preservatives', 'colour', 'colours', 'color', 'colors', 'emulsifier', 'emulsifiers',
    'antioxidant', 'antioxidants', 'stabiliser', 'stabilizer', 'stabilisers', 'stabilizers', 'acidity regulator', 'acidity regulators',
    'thickener', 'thickeners', 'sweetener', 'sweeteners', 'and', 'contains', 'ingredients', 'class ii preservative', 'seasoning', 'cereal products', 'cereal product', 'flavour enhancer', 'flavour enhancers', 'flavouring substances', 'nature identical flavouring substances', 'natural', 'raising agent', 'raising agents', 'anticaking agent', 'anti caking agent', 'humectant', 'firming agent', 'proprietary food', 'namkeen', 'dough conditioner', 'flour treatment agent', 'flour treatment agents', 'tastemaker', 'taste maker']);

  function esc(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  function norm(s) {
    return String(s).toLowerCase()
      .replace(/\b(e|ins)[\s-]?(\d{3,4}[a-z]?)\b/g, 'e$2')
      .replace(/[^a-z0-9\s'&.-]/g, ' ').replace(/\s+/g, ' ')
      .replace(/^[\s.\-]+|[\s.\-]+$/g, '');
  }

  const DB = rows.map(r => {
    const [name, al, score, h, note, alg, uses] = r.split('|');
    return { uses: uses ? uses.split('~') : (USES[name] || null), name, aliases: [name].concat(al ? al.split(';') : []), score: +score, hazard: HAZ[h], note: note || '', allergens: alg ? alg.split(',') : [] };
  });
  const INDEX = new Map(), LIST = [];
  DB.forEach(e => e.aliases.forEach(a => {
    a = norm(a); if (!a) return;
    INDEX.set(a, e); LIST.push([a, e, new RegExp('(^| )' + esc(a) + '( |$)')]);
  }));
  LIST.sort((x, y) => y[0].length - x[0].length);

  const MAXTEXT = 8000, MAXTOKEN = 80; // real labels are far shorter; anything bigger is junk or an attack
  function findHeader(t) { // tolerant of OCR slips such as "INGR EDIENTS" or "lngredients"
    const re = /[:;]/g; let m;
    while ((m = re.exec(t))) {
      const pre = t.slice(Math.max(0, m.index - 16), m.index).replace(/[^a-z]/gi, '').toLowerCase();
      if (pre.length >= 8 && (lev(pre.slice(-11), 'ingredients', 3) <= 3 || lev(pre.slice(-10), 'ingredient', 2) <= 2)) return m.index + 1;
    }
    const o = t.search(/ingredients?\s*[:\-]/i);
    return o >= 0 ? o + t.slice(o).match(/ingredients?\s*[:\-]/i)[0].length : -1;
  }
  const END = /(\u00b6|\*\s*as\s|to know the specific|batch n|nutrition|per 100\s*(g|ml)|serve size|may contain|contains\s*:|allergen|manufactured|marketed|mfd|best before|use by|storage|fssai|\bmrp\b|net (wt|weight|qty|quantity))/i;
  function extractSection(text) {
    text = String(text == null ? '' : text).slice(0, MAXTEXT);
    let t = String(text || '').replace(/\r/g, ' ').replace(/\n+/g, ' ');
    const h = findHeader(t);
    if (h >= 0) t = t.slice(h);
    const e = t.search(END);
    if (e > 0) t = t.slice(0, e);
    // claims such as "gluten free" or "does not contain milk" are not ingredients
    return t.replace(/\b(\w+[\s-]free\b|free (from|of) [\w\s]+?(?=[.,;]|$)|(does not|doesn.t) contain [\w\s]+?(?=[.,;]|$)|without [\w\s]+?(?=[.,;]|$))/gi, ' ');
  }
  function split(t) {
    return t.replace(/\((i{1,3}|iv|v)\)/gi, ' ').replace(/\d+(\.\d+)?\s*%/g, ' ').split(/[,;()\[\]{}:\u2022]|\.(?!\d)|\s[-\u2013]\s/).map(norm).filter(x => x && x.length > 1);
  }
  function lev(a, b, max) { // edit distance, gives up above max
    if (Math.abs(a.length - b.length) > max) return max + 1;
    let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i++) { const cur = [i]; let best = i;
      for (let j = 1; j <= b.length; j++) { cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); if (cur[j] < best) best = cur[j]; }
      if (best > max) return max + 1; prev = cur; }
    return prev[b.length];
  }
  function fuzzyKeys(tok, keys) { // closest key allowing for OCR slips; null if none or ambiguous
    if (tok.length < 6) return null; const max = tok.length <= 8 ? 1 : 2; let best = null, bd = max + 1, tie = false;
    for (const k of keys) { const d = lev(tok, k, max); if (d < bd) { bd = d; best = k; tie = false; } else if (d === bd && k !== best) tie = true; }
    return bd <= max && !tie ? best : null;
  }
  const KEYS = Array.from(INDEX.keys()).filter(k => k.length >= 6), IGN = Array.from(IGNORE).filter(k => k.length >= 6);
  function matchToken(tok) {
    if (INDEX.has(tok)) return INDEX.get(tok);
    if (/^\d{3,4}[a-i]?$/.test(tok) && INDEX.has('e' + tok)) return INDEX.get('e' + tok); // bare INS/E number, e.g. "319"
    const f = fuzzyKeys(tok, KEYS); if (f) return INDEX.get(f); // OCR slips first, so "edible vegetable oi" is not read as "vegetable"
    for (const [, e, re] of LIST) if (re.test(tok)) return e;
    return null;
  }

  // ---- allergy knowledge: what a user's word means when it appears on a label ----
  const TREE = ['almond', 'cashew', 'hazelnut', 'walnut', 'pistachio', 'pecan', 'macadamia', 'brazil nut', 'pine nut'];
  const GENERIC_NUTS = ['nuts', 'tree nut', 'tree nuts', 'mixed nuts'];
  const ALLERGY_TERMS = {
    milk: ['milk', 'dairy', 'lactose', 'casein', 'caseinate', 'whey', 'butter', 'cream', 'cheese', 'ghee', 'curd', 'yogurt', 'yoghurt', 'paneer', 'milk solids', 'skimmed milk'],
    peanut: ['peanut', 'peanuts', 'groundnut', 'groundnuts', 'arachis', 'monkey nut', 'nuts', 'mixed nuts'],
    nut: TREE.concat(GENERIC_NUTS, ['marzipan', 'nut']),
    gluten: ['gluten', 'wheat', 'barley', 'rye', 'malt', 'semolina', 'spelt', 'triticale', 'maida'],
    wheat: ['wheat', 'semolina', 'maida', 'spelt', 'durum'],
    egg: ['egg', 'eggs', 'albumen', 'albumin', 'mayonnaise', 'ovalbumin'],
    soy: ['soy', 'soya', 'soybean', 'soybeans', 'tofu', 'edamame'],
    sesame: ['sesame', 'tahini', 'gingelly'],
    fish: ['fish', 'anchovy', 'anchovies', 'salmon', 'tuna', 'cod'],
    shellfish: ['shellfish', 'shrimp', 'prawn', 'prawns', 'crab', 'lobster', 'crustacean', 'crustaceans', 'mollusc', 'molluscs', 'squid', 'oyster', 'clam', 'mussel'],
    mustard: ['mustard'], celery: ['celery'], lupin: ['lupin', 'lupine'],
    sulphite: ['sulphite', 'sulphites', 'sulfite', 'sulfites', 'sulphur dioxide', 'sulfur dioxide', 'metabisulphite']
  };
  TREE.forEach(n => { ALLERGY_TERMS[n] = [n, n + 's'].concat(GENERIC_NUTS); });
  const ALLERGY_ALIAS = { dairy: 'milk', lactose: 'milk', 'milk allergy': 'milk', groundnut: 'peanut', groundnuts: 'peanut', peanuts: 'peanut', nuts: 'nut', 'tree nut': 'nut', 'tree nuts': 'nut',
    eggs: 'egg', soya: 'soy', soybean: 'soy', sulphites: 'sulphite', sulfite: 'sulphite', sulfites: 'sulphite', 'shell fish': 'shellfish', seafood: 'shellfish', 'celiac': 'gluten', coeliac: 'gluten' };
  const FUZZY_OK = new Set(['peanut', 'sesame', 'cashew', 'almond', 'gluten', 'casein', 'shrimp', 'walnut', 'pecan', 'lupin', 'celery', 'hazelnut']);
  function termsFor(a) {
    a = String(a).toLowerCase().trim(); let k = ALLERGY_ALIAS[a] || a;
    if (!ALLERGY_TERMS[k] && /s$/.test(k) && ALLERGY_TERMS[k.slice(0, -1)]) k = k.slice(0, -1);
    return Array.from(new Set((ALLERGY_TERMS[k] || []).concat([a, a.replace(/s$/, '')]))).filter(t => t.length >= 3);
  }
  const MAY = /(may contain|might contain|can contain|could contain|traces? of|trace amounts?|manufactured (in|on|at)|made (in|on)|produced (in|on)|processed (in|on)|packed (in|on)|same (facility|factory|line|equipment)|shared (facility|equipment))/;
  function allergyScan(text, algs, found) {
    const hits = [], seen = new Set();
    const put = (allergy, kind, what, fuzzy) => { const k = allergy + '|' + kind; if (seen.has(k)) return; seen.add(k); hits.push({ allergy, kind, ingredient: what, fuzzy: !!fuzzy }); };
    const sentences = String(text || '').toLowerCase().split(/[.\n;|]+/);
    for (const a of algs) {
      const terms = termsFor(a);
      for (const x of found) if (x.allergens.some(t => terms.includes(t) || t.includes(a) || a.includes(t)) || terms.includes(x.name) || x.name.includes(a)) put(a, 'contains', x.name);
      for (const s of sentences) {
        if (!s.trim()) continue; const may = MAY.test(s), kind = may ? 'may' : 'contains';
        for (const t of terms) {
          const re = new RegExp('(^|[^a-z])' + esc(t) + '(s|es)?(?![a-z])', 'g'); let m;
          while ((m = re.exec(s))) {
            const start = m.index + m[1].length, before = s.slice(Math.max(0, start - 28), start), after = s.slice(m.index + m[0].length, m.index + m[0].length + 10);
            if (/(free from|free of|without|does not contain|doesn.t contain|no|not)\s+(\w+\s+){0,2}$/.test(before) || /^[\s-]*free/.test(after)) continue;
            put(a, kind, t);
          }
        }
        for (const w of s.match(/[a-z]{6,}/g) || []) for (const t of terms) {
          if (!(t.length >= 7 || FUZZY_OK.has(t)) || w === t) continue; const mx = t.length <= 8 ? 1 : 2;
          if (lev(w, t, mx) <= mx) put(a, kind, t + ' (possible misread: "' + w + '")', true);
        }
      }
    }
    return hits;
  }
  const SUGARS = new Set(['sugar', 'glucose syrup', 'high fructose corn syrup', 'dextrose', 'invert sugar', 'jaggery', 'fructose', 'brown sugar', 'maple syrup']);

  function analyze(text, profile) {
    text = String(text == null ? '' : text).slice(0, MAXTEXT);
    const toks = split(extractSection(text));
    const seen = new Set(), found = [], unknown = [], order = [];
    for (const tok of toks) {
      if (IGNORE.has(tok) || fuzzyKeys(tok, IGN) || tok.split(' ').length > 6 || tok.length > MAXTOKEN) continue;
      let ents = [];
      const e = matchToken(tok);
      if (e) ents = [e];
      else if (/ and | & /.test(tok)) ents = tok.split(/ and | & /).map(p => matchToken(norm(p))).filter(Boolean);
      if (!ents.length) { if (!/[a-z]/.test(tok)) continue; if (!unknown.includes(tok)) { unknown.push(tok); order.push({ name: tok, s: 55, known: false }); } continue; }
      for (const x of ents) if (!seen.has(x.name)) { seen.add(x.name); found.push(Object.assign({}, x, { matched: tok })); order.push({ name: x.name, s: x.score, known: true }); }
    }
    const high = found.filter(x => x.hazard === 'high').length;
    const mod = found.filter(x => x.hazard === 'moderate').length;
    const total = found.length + unknown.length, coverage = total ? found.length / total : 0;
    let score = null, verdict = 'Not enough recognised ingredients to score', hazard = 'unknown', confidence = 'none';
    if (found.length && coverage >= 0.34) {
      // earlier ingredients weigh more (labels list the largest first); only recognised ingredients are scored, unrecognised ones lower the confidence
      const kn = order.filter(o => o.known); let sw = 0, sv = 0; kn.forEach((o, i) => { const w = 1 / (1 + 0.2 * i); sw += w; sv += w * o.s; });
      let sc = sv / sw - high * 8 - Math.min(mod, 5) * 2;
      const sp = kn.map((o, i) => SUGARS.has(o.name) ? i : -1).filter(i => i >= 0);
      if (sp.length >= 3) sc -= 8;                                   // sugar hidden under several names
      if (sp.length && sp[0] === 0) sc = Math.min(sc, 39); else if (sp.length && sp[0] <= 2) sc = Math.min(sc, 49); // sugar is a main ingredient
      confidence = coverage >= 0.8 ? 'high' : coverage >= 0.5 ? 'medium' : 'low';
      if (confidence === 'low') sc = Math.min(sc, 69);               // never "Good" on thin evidence
      score = Math.round(Math.max(0, Math.min(100, sc)));
      verdict = score >= 75 ? 'Good' : score >= 50 ? 'Okay' : score >= 25 ? 'Poor' : 'Avoid';
      hazard = (high >= 1 || score < 35) ? 'high' : (score < 65 || mod >= 2) ? 'moderate' : 'low';
    }
    const algs = [].concat((profile && profile.allergies) || []).slice(0, 50).map(a => String(a).toLowerCase().trim()).filter(a => a.length >= 3);
    const warnings = algs.length ? allergyScan(text, algs, found) : [];
    const readable = String(text || '').trim().length >= 15 && total >= 2 && coverage >= 0.6;
    const allergyStatus = !algs.length ? 'none' : warnings.some(w => w.kind === 'contains') ? 'match' : warnings.length ? 'traces' : readable ? 'clear' : 'unverified';
    let h = 5381; const fs = found.map(x => x.name).sort().join('|'); for (let i = 0; i < fs.length; i++) h = ((h << 5) + h + fs.charCodeAt(i)) >>> 0;
    const fp = found.length ? 'NS-' + h.toString(36).toUpperCase().padStart(6, '0').slice(-6) : '';
    return { fp, found, unknown, score, verdict, hazard, high, moderate: mod, warnings, coverage, confidence, allergyStatus };
  }


  // Keep only what matters from a whole-pack OCR dump: the ingredient list, allergen lines and nutrition lines.
  function focusParts(text) {
    text = String(text == null ? '' : text).slice(0, MAXTEXT);
    const raw = String(text || '').replace(/\r/g, ''), flat = raw.replace(/\n+/g, ' ');
    const h = findHeader(flat); if (h < 0) return { ingredients: raw.trim(), nutrition: '' };
    let sec = flat.slice(h); const e = sec.search(END); if (e > 0) sec = sec.slice(0, e);
    const secN = sec.toLowerCase().replace(/\s+/g, ' ');
    const nutRe = /(kcal|\benergy\b|protein|carbohydrate|sugars?\b|\bfat\b|saturat|trans fat|sodium|\bsalt\b|fib(re|er)|cholesterol|per 100|serve size|nutrition information|\brda\b)/i;
    const alg = /(may contain|contains\s*:|allergen|traces? of)/i;
    const lines = raw.split('\n').map(s => s.trim()).filter(Boolean)
      .filter(l => !(secN.includes(l.toLowerCase().replace(/\s+/g, ' ')) || /ingredients?\s*[:;]/i.test(l)));
    return { ingredients: ['Ingredients: ' + sec.trim()].concat(lines.filter(l => alg.test(l))).join('\n'), nutrition: lines.filter(l => !alg.test(l) && nutRe.test(l)).join('\n') };
  }
  function focusText(text) { const p = focusParts(text); return p.nutrition ? p.ingredients + '\n' + p.nutrition : p.ingredients; }
  // If the OCR reads only part of a pack we already know (brand seen, every recognised ingredient belongs to it), use the verified entry.
  function snapKnown(text, ing, products) {
    if (!ing || ing.found.length < 2) return null;
    const words = String(text || '').toLowerCase().match(/[a-z]{4,}/g) || [];
    for (const p of products || []) {
      if (!p.ingredients) continue;
      const brand = String(p.brand || String(p.name).split(' ')[0]).toLowerCase().replace(/[^a-z]/g, '');
      if (brand.length < 4 || !words.some(w => w === brand || lev(w, brand, 1) <= 1)) continue;
      const pf = new Set(analyze(p.ingredients, {}).found.map(x => x.name));
      if (ing.found.every(x => pf.has(x.name))) return p;
    }
    return null;
  }


  // List rescue: when the normal reading recognises too little (noisy OCR), search the ingredient part of the text for names we know.
  const CLS = /(enhancer|regulator|thickener|colour|color|preservative|emulsifier|antioxidant|stabili[sz]er|acid)s?\s*[(\[{]?\s*((?:\d{3,4}[a-i]?\s*(?:[,&]|and)?\s*)+)/g;
  function rescue(text) {
    text = String(text == null ? '' : text).slice(0, MAXTEXT);
    const flat = String(text || '').replace(/\r/g, ' ').replace(/\n+/g, ' ');
    const h = findHeader(flat); let sec = h >= 0 ? flat.slice(h) : flat;
    const cut = sec.slice(60).search(/(\*\s*as\s|to know the specific|utrition|per 100\s*(g|ml)|serve size|best before|\bmrp\b|may contain|contains?\s+(wheat|milk|soy|mustard|nuts?|egg|peanut|gluten))/i);
    if (cut >= 0) sec = sec.slice(0, cut + 60);
    let n = norm(sec); const hits = [];
    const add = (pos, alias, e) => { if (!hits.some(x => x.e === e)) hits.push({ pos, alias, e }); };
    let m; CLS.lastIndex = 0;
    while ((m = CLS.exec(n))) m[2].match(/\d{3,4}[a-i]?/g).forEach(num => { const e = INDEX.get('e' + num); if (e) add(m.index, 'e' + num, e); });
    (n.match(/[(\[{]\s*\d{3,4}[a-i]?\s*[)\]}]/g) || []).forEach(s => { const e = INDEX.get('e' + s.replace(/[^0-9a-i]/g, '')); if (e) add(n.indexOf(s), 'e' + s.replace(/[^0-9a-i]/g, ''), e); });
    for (const [a, e, re] of LIST) {
      if (a.length < 4 && !/^e\d/.test(a)) continue;
      const mm = re.exec(n); if (!mm) continue;
      add(mm.index, a, e); n = n.replace(re, ' ' + ' '.repeat(a.length) + ' ');
    }
    const words = Array.from(new Set(n.match(/[a-z]{8,}/g) || []));
    for (const w of words) { const k = fuzzyKeys(w, KEYS); if (k && !k.includes(' ')) add(sec.toLowerCase().indexOf(w.slice(0, 4)), k, INDEX.get(k)); }
    return hits.sort((x, y) => x.pos - y.pos);
  }
  function analyzeRobust(text, profile) {
    text = String(text == null ? '' : text).slice(0, MAXTEXT);
    const r = analyze(text, profile);
    if (r.score !== null) return r; // the normal reading worked: keep it
    const hits = rescue(text);
    if (hits.length < 4) return r;
    const q = analyze('Ingredients: ' + hits.map(x => x.alias).join(', '), profile);
    q.rescued = true; q.confidence = 'low'; q.coverage = Math.min(q.coverage, 0.49);
    if (q.score !== null) {
      q.score = Math.min(q.score, 69);
      q.verdict = q.score >= 75 ? 'Good' : q.score >= 50 ? 'Okay' : q.score >= 25 ? 'Poor' : 'Avoid';
      q.hazard = (q.high >= 1 || q.score < 35) ? 'high' : (q.score < 65 || q.moderate >= 2) ? 'moderate' : 'low';
    }
    q.warnings = r.warnings; q.allergyStatus = r.allergyStatus === 'clear' ? 'unverified' : r.allergyStatus;
    return q;
  }


  // A scan that reads only part of a pack we know: same ingredients, same order. The app asks the user before using the verified entry.
  function suggestKnown(ing, products) {
    if (!ing || ing.found.length < 3) return null;
    const names = ing.found.map(x => x.name); let best = null, bs = 0;
    for (const p of products || []) {
      if (!p.ingredients) continue;
      const order = analyze(p.ingredients, {}).found.map(x => x.name);
      let last = -1, ok = true;
      for (const n of names) { const i = order.indexOf(n, last + 1); if (i < 0) { ok = false; break; } last = i; }
      const s = names.length / order.length;
      if (ok && s > bs) { bs = s; best = p; }
    }
    return best;
  }

  const api = { focusParts, suggestKnown, analyzeRobust, rescue, focusText, snapKnown, lev, analyze, termsFor, extractSection, split, norm, DB_SIZE: DB.length };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Engine = api;
})(typeof window !== 'undefined' ? window : globalThis);
