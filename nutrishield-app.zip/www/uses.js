// Real-world uses for older ingredient rows: name -> [food use, everyday use]
(function (r) {
  r.INGREDIENT_USES = {
"water": [
"Dissolves, hydrates and carries flavour in drinks and sauces",
"Home use for drinking, cooking and cleaning"
],
"sugar": [
"Sweetens and browns biscuits, sweets and drinks",
"Home use in tea, desserts and preserves"
],
"salt": [
"Seasons and preserves snacks, pickles and ready meals",
"Home use in cooking and curing"
],
"sea salt": [
"Seasoning and mild flavour in snacks and bread",
"Home use for cooking and finishing dishes"
],
"wheat flour": [
"Main base of biscuits, bread and noodles",
"Home use for rotis, puris and baking"
],
"whole wheat flour": [
"Fibre-rich base for bread, biscuits and rotis",
"Home use for chapati and paratha"
],
"rice flour": [
"Crisp base in snacks and gluten-free products",
"Home use in dosa, idli and batters"
],
"oats": [
"Base for breakfast cereals and bars",
"Home use in porridge and smoothies"
],
"palm oil": [
"Frying and shortening fat in snacks and noodles",
"Home use in cooking and frying"
],
"sunflower oil": [
"Frying and salad oil in packaged foods",
"Home use in everyday cooking"
],
"olive oil": [
"Dressings and sauces in packaged foods",
"Home use in salads and light cooking"
],
"soybean oil": [
"Frying and mayonnaise base",
"Home use for cooking and frying"
],
"hydrogenated palm oil": [
"Solid fat in biscuits, creams and sweets",
"Cheap baking and frying fat"
],
"high fructose corn syrup": [
"Sweetens soft drinks, sauces and bakery",
"Used as a cheap liquid sugar in industry"
],
"glucose syrup": [
"Sweet and chewy texture in candy and biscuits",
"Home use in candy making and icing"
],
"dextrose": [
"Quick sweetener and browning agent in bakery",
"Used in sports drinks and medical drips"
],
"maltodextrin": [
"Bulks and thickens snacks, powders and drinks",
"Used in sports nutrition powders"
],
"honey": [
"Natural sweetener in cereals and bars",
"Home use in tea, remedies and cooking"
],
"jaggery": [
"Traditional sweetener in sweets and bars",
"Home use in chikki, tea and laddoo"
],
"milk": [
"Creamy base in chocolates, desserts and drinks",
"Home use in tea, curd and cooking"
],
"butter": [
"Rich flavour in biscuits, bakery and spreads",
"Home use for cooking and on bread"
],
"cheese": [
"Savoury flavour in pizza, snacks and sauces",
"Home use in sandwiches and cooking"
],
"cocoa": [
"Chocolate flavour in drinks, biscuits and cakes",
"Home use in baking and hot chocolate"
],
"egg": [
"Binds and aerates cakes and mayonnaise",
"Home use in omelettes and baking"
],
"peanut": [
"Crunch and protein in snacks and bars",
"Home use in chutney, chikki and peanut butter"
],
"almond": [
"Crunch and richness in sweets and cereals",
"Home use in snacks, milk and desserts"
],
"cashew": [
"Richness in sweets, gravies and snacks",
"Home use in curries and mithai"
],
"yeast": [
"Makes bread and buns rise",
"Home use in baking and brewing"
],
"baking soda": [
"Raising agent in cakes, biscuits and namkeen",
"Home use in baking and cleaning"
],
"citric acid": [
"Adds sourness and preserves drinks and candy",
"Home use for descaling and lemon-style tang"
],
"ascorbic acid": [
"Antioxidant that prevents browning in juices and bread",
"Used as vitamin C in supplements"
],
"sodium benzoate": [
"Preserves soft drinks, sauces and pickles",
"Used in cosmetics and medicines"
],
"potassium sorbate": [
"Stops mold in cheese, bakery and wine",
"Used in cosmetics"
],
"tartrazine": [
"Yellow colour in sweets, drinks and snacks",
"Used in medicine coatings and cosmetics"
],
"caramel colour": [
"Brown colour in colas, sauces and bakery",
"Used in spirits and gravies"
],
"aspartame": [
"Zero-calorie sweetness in diet drinks and gums",
"Tabletop sweetener tablets"
],
"sucralose": [
"Zero-calorie sweetness in drinks and desserts",
"Home use in tea and baking"
],
"monosodium glutamate": [
"Boosts savoury taste in noodles, chips and soups",
"Home use in Chinese-style cooking"
],
"xanthan gum": [
"Thickens and stabilises sauces, dressings and drinks",
"Home use in gluten-free baking"
],
"guar gum": [
"Thickens ice cream, sauces and gluten-free bakery",
"Used in textile and oil industry"
],
"pectin": [
"Sets jams and jellies",
"Home use in jam making"
],
"gelatin": [
"Sets jellies, gummies and desserts",
"Used in capsules and photography"
],
"soy lecithin": [
"Mixes oil and water in chocolate and bakery",
"Used in supplements and cosmetics"
],
"mono and diglycerides": [
"Keeps bread soft and ice cream smooth",
"Used in cosmetics"
],
"modified starch": [
"Thickens soups, sauces and fillings",
"Used in paper and adhesives"
],
"bha": [
"Antioxidant that stops oils going rancid",
"Used in packaging and cosmetics"
],
"tbhq": [
"Antioxidant that extends oil and snack shelf life",
"Used in biodiesel and varnish"
],
"titanium dioxide": [
"White colour in sweets, coatings and sauces",
"Used in paints, sunscreen and toothpaste"
],
"tomato": [
"Natural flavour and colour in sauces, snacks and soups",
"Home use in curries, chutney and salads"
],
"potato": [
"Base for chips, snacks and instant mash",
"Home use in curries, fries and parathas"
],
"spices": [
"Flavour and aroma in snacks, noodles and sauces",
"Home use in tadka, curries and pickles"
],
"onion": [
"Savoury flavour in snacks, soups and sauces",
"Home use in curries and salads"
],
"garlic": [
"Savoury flavour in sauces, snacks and ready meals",
"Home use in tadka and pickles"
],
"chilli": [
"Heat and colour in snacks and sauces",
"Home use in curries and pickles"
],
"black pepper": [
"Pungent seasoning in snacks, sauces and meats",
"Home use in cooking and remedies"
],
"vitamins": [
"Fortifies cereals, milk and drinks",
"Used in supplements"
],
"caffeine": [
"Stimulant in cola, energy drinks and coffee",
"Used in painkillers and supplements"
],
"vinegar": [
"Tang and preservation in sauces and pickles",
"Home use in pickles and cleaning"
],
"corn": [
"Base for chips, cereals and snacks",
"Home use in roasted corn and flour"
],
"coconut": [
"Flavour and fat in sweets and curries",
"Home use in chutney and cooking oil"
],
"artificial flavour": [
"Gives taste to snacks, drinks and sweets",
"Used in perfumes and household products"
],
"natural flavour": [
"Gives taste to drinks, biscuits and sweets",
"Used in food and fragrance"
],
"spice extract": [
"Concentrated spice flavour in snacks and sauces",
"Used in seasonings"
],
"gluten": [
"Improves dough stretch in bread and noodles",
"Home use as meat substitute (seitan)"
],
"soy protein": [
"Protein boost in biscuits and breads",
"Home use mixed into atta"
],
"milk solids": [
"Protein in sports drinks and bars",
"Home use in shakes and baking"
],
"sesame": [
"Flavour and frying in snacks and dressings",
"Home use in cooking and massage oil"
],
"sorbitol": [
"Sugar-free sweets and gums",
"Home use in sugar-free baking"
],
"sodium carbonate": [
"Gives crispness to biscuits and crackers",
"Traditional raising agent in baking"
],
"sodium phosphate": [
"Keeps meats juicy and noodles springy",
"Used in detergents and cheeses"
],
"calcium propionate": [
"Keeps bread and cakes mold-free",
"Used in animal feed"
],
"turmeric": [
"Colours snacks, rice and dairy yellow",
"Home use in curry and skin care"
],
"added vitamins and minerals": [
"Yellow colour and vitamin fortification",
"Found in cereals and drinks"
],
"natural colour": [
"Green colour in sweets and drinks",
"Used in herbal products"
],
"disodium inosinate": [
"Boosts savoury taste in noodles and chips",
"Used with MSG in seasonings"
],
"herbs and spices": [
"Flavour in snacks and masalas",
"Home use in tadka and chaas"
],
"mustard oil": [
"Tang in sauces, pickles and dressings",
"Home use in tadka and pickles"
],
"raisins": [
"Natural sweetener in bars and spreads",
"Home use in desserts and energy balls"
],
"raising agent": [
"Makes cakes, biscuits and pakoras fluffy",
"Home use in baking"
],
"vanilla": [
"Vanilla taste in biscuits, ice cream and bakery",
"Home use in cakes and desserts"
],
"black salt": [
"Tangy mineral salt in chaat and snack seasoning",
"Home use in chaat, raita and digestive drinks"
],
"gram flour": [
"Base of bhujia, sev and pakora coatings",
"Home use in besan chilla, kadhi and sweets"
],
"malic acid": [
"Sour tang in candies, drinks and masala snacks",
"Used in fruit-flavoured products"
],
"paprika extract": [
"Natural orange-red colour in snacks and sauces",
"Used in seasoning blends"
],
"palm kernel oil": [
"Hard fat in biscuits, creams and chocolate coatings",
"Used in soaps and cosmetics"
],
"invert sugar": [
"Keeps sweets moist and sweet in bakery and syrups",
"Used in candy and syrup making"
],
"cocoa butter": [
"Fat that gives chocolate its melt",
"Used in skin creams and lotions"
],
"tartaric acid": [
"Sourness and leavening in sweets and baking powder",
"Used in winemaking"
],
"lactic acid": [
"Acidity control in pickles, drinks and dairy",
"Used in cosmetics and cleaners"
],
"sodium nitrite": [
"Cures and colours ham, bacon and sausages",
"Used in meat preservation"
],
"sodium nitrate": [
"Cures meats and cheese",
"Used as fertiliser"
],
"sulphur dioxide": [
"Prevents browning and spoilage in dried fruit and wine",
"Used in winemaking"
],
"sodium metabisulphite": [
"Stops browning and spoilage in dried fruit and potato products",
"Used in winemaking and brewing"
],
"sunset yellow": [
"Orange colour in drinks, sweets and snacks",
"Used in medicine coatings and cosmetics"
],
"allura red": [
"Red colour in drinks, sweets and snacks",
"Used in medicines and cosmetics"
],
"carmoisine": [
"Red colour in sweets, jellies and drinks",
"Used in medicines"
],
"ponceau 4r": [
"Red colour in sweets, sauces and drinks",
"Banned in some countries"
],
"quinoline yellow": [
"Yellow colour in sweets and drinks",
"Used in medicines and cosmetics"
],
"brilliant blue": [
"Blue colour in sweets, ice cream and drinks",
"Used in medicines and cosmetics"
],
"annatto": [
"Natural orange colour in cheese, snacks and butter",
"Home use in colouring rice and oils"
],
"beta carotene": [
"Natural orange colour and vitamin A source in drinks and margarine",
"Used in supplements"
],
"artificial colour": [
"Colours sweets, drinks and snacks",
"Used in cosmetics and medicines"
],
"acesulfame potassium": [
"Zero-calorie sweetener in diet drinks and gums",
"Tabletop sweetener blends"
],
"saccharin": [
"Zero-calorie sweetener in diet drinks and tablets",
"Tabletop sweetener tablets"
],
"stevia": [
"Natural zero-calorie sweetener in drinks and bars",
"Home use in tea and desserts"
],
"carrageenan": [
"Thickens and stabilises dairy desserts, ice cream and plant milk",
"Used in toothpaste and pet food"
],
"polysorbate 80": [
"Mixes oil and water in ice cream and sauces",
"Used in cosmetics and vaccines"
],
"bht": [
"Antioxidant that stops fats going rancid",
"Used in packaging and cosmetics"
],
"tocopherols": [
"Natural antioxidant (vitamin E) in oils and snacks",
"Used in supplements and skin care"
],
"potassium bromate": [
"Strengthens bread dough (banned in India)",
"Used in some industrial baking"
],
"vegetables": [
"Real vegetable content in soups, snacks and ready meals",
"Home use in cooking and salads"
],
"fruit": [
"Natural sweetness and flavour in jams, juices and bars",
"Home use as fresh snacks and desserts"
],
"liquorice": [
"Sweet herbal flavour in sweets and drinks",
"Used in herbal remedies"
],
"alcohol": [
"Solvent for flavours and extracts",
"Used in beverages, medicines and sanitisers"
],
"fatty alcohol": [
"Texture agent in confectionery and cosmetics",
"Used in creams and lotions"
],
"phosphoric acid": [
"Tang in cola drinks",
"Used in rust removers and fertilisers"
],
"red 3": [
"Red colour in candy and decorations",
"Restricted in several countries"
],
"orange juice from concentrate": [
"Fruit flavour and sweetness in juices and sweets",
"Home use as a breakfast drink"
],
"salami": [
"Cured meat in sandwiches and ready meals",
"Home use on pizza and platters"
],
"chicken": [
"Protein in ready meals, soups and snacks",
"Home use in curries and grills"
],
"beef": [
"Protein in burgers, ready meals and sausages",
"Home use in curries and roasts"
],
"pork": [
"Protein in sausages and ready meals",
"Home use in curries and roasts"
],
"fish": [
"Protein in canned foods and ready meals",
"Home use in curries and fry"
],
"shrimp": [
"Protein in seafood snacks and ready meals",
"Home use in curries and fry"
],
"cream": [
"Richness in desserts, sauces and ice cream",
"Home use in gravies and desserts"
],
"casein": [
"Milk protein in cheese and protein products",
"Used in adhesives and supplements"
],
"lactose": [
"Mild sweetener and bulking agent in dairy mixes",
"Used in pharma tablets"
],
"barley": [
"Base for malted drinks, cereals and soups",
"Home use in soups and porridge"
],
"rye": [
"Base for dark breads and crackers",
"Home use in bread and porridge"
],
"semolina": [
"Base for pasta, upma and sweets",
"Home use in upma, halwa and rava dosa"
],
"chickpea": [
"Protein and fibre in snacks and hummus",
"Home use in chana masala and besan"
],
"lentils": [
"Protein and fibre in soups, snacks and ready meals",
"Home use in dal and khichdi"
],
"canola oil": [
"Frying and salad oil in packaged foods",
"Home use in cooking"
],
"corn oil": [
"Frying oil for snacks",
"Home use in frying and baking"
],
"cottonseed oil": [
"Frying oil in snacks and bakery",
"Used in industrial frying"
],
"rice bran oil": [
"Frying oil in snacks and namkeen",
"Home use in everyday cooking"
],
"groundnut oil": [
"Frying oil in snacks and sweets",
"Home use in Indian cooking"
],
"vegetable fat": [
"Solid fat in biscuits, creams and chocolate",
"Used in bakery shortenings"
],
"calcium carbonate": [
"Calcium fortifier and anti-caking agent",
"Used in antacids and chalk"
],
"gum arabic": [
"Stabiliser and glaze in sweets and drinks",
"Used in inks and adhesives"
],
"cellulose gum": [
"Thickener in sauces, ice cream and gluten-free bakery",
"Used in toothpaste and pharma"
],
"locust bean gum": [
"Thickener in ice cream, cheese and desserts",
"Used in pet food and textiles"
],
"gellan gum": [
"Stabiliser in plant milks, jellies and drinks",
"Used in lab media"
],
"sodium acetate": [
"Gives vinegar-like tang in chips and snacks",
"Used in hand warmers and buffers"
],
"sodium erythorbate": [
"Antioxidant that keeps cured meat colour",
"Used in packaged beverages"
],
"propyl gallate": [
"Antioxidant for oils and fatty snacks",
"Used in cosmetics"
],
"fructose": [
"Sweetener in drinks, bars and bakery",
"Used in diabetic-style sweets"
],
"maple syrup": [
"Natural sweetener in cereals and sauces",
"Home use on pancakes"
],
"apple": [
"Natural sweetness in juices, jams and snacks",
"Home use as fresh fruit"
],
"lemon juice": [
"Sourness and preservation in drinks and sauces",
"Home use in drinks, salads and cooking"
],
"soy sauce": [
"Savoury flavour in noodles and sauces",
"Home use in Chinese-style cooking"
],
"cocoa butter equivalent": [
"Cheaper chocolate-style fat in coatings",
"Used in confectionery"
],
"chocolate": [
"Flavour and coating in biscuits and sweets",
"Home use in baking and desserts"
],
"biscuit": [
"Crunch in desserts and ice-cream cones",
"Home use as tea-time snack"
],
"ascorbyl palmitate": [
"Fat-soluble vitamin C antioxidant in oils and spreads",
"Used in supplements"
],
"potassium chloride": [
"Salt substitute and mineral",
"Used in electrolyte drinks"
],
"glycerol": [
"Keeps food moist and sweet",
"Used in cosmetics and medicines"
],
"sodium alginate": [
"Thickens and sets jellies, ice cream and drinks",
"Used in dentistry moulds and wound care"
],
"tea or coffee extract": [
"Flavour and caffeine in drinks and desserts",
"Home use as a daily beverage"
]
};
  if (typeof module !== 'undefined' && module.exports) module.exports = r.INGREDIENT_USES;
})(typeof window !== 'undefined' ? window : globalThis);
