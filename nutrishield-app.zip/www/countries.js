// Country list (ISO 3166-1). Names come from the system, so they follow the chosen language. Not linked to the app language.
(function (root) {
  'use strict';
  const CODES = ('AD AE AF AG AI AL AM AO AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ ' +
    'DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GT GU GW GY HK HN HR HT HU ID IE IL IM IN IQ IR IS IT JE JM JO JP ' +
    'KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ ' +
    'OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TG TH TJ TK TL TM TN TO TR TT TV TW TZ ' +
    'UA UG US UY UZ VA VC VE VG VI VN VU WF WS XK YE YT ZA ZM ZW').split(' ');
  const dn = {};
  function name(code, loc) {
    loc = loc || 'en';
    try { dn[loc] = dn[loc] || new Intl.DisplayNames([loc], { type: 'region' }); return dn[loc].of(code) || code; } catch (e) { return code; }
  }
  const list = loc => CODES.map(c => ({ code: c, name: name(c, loc) })).sort((a, b) => a.name.localeCompare(b.name, loc || 'en'));
  function guess(lang) { const m = /[-_]([A-Za-z]{2})\b/.exec(lang || ''), c = m && m[1].toUpperCase(); return c && CODES.indexOf(c) >= 0 ? c : ''; }
  const api = { CODES, name, list, guess };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Countries = api;
})(typeof window !== 'undefined' ? window : globalThis);
