window.ACCURACY={"pass":25,"total":25,"coverage":100};
