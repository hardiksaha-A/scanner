// Shared scan pipeline helpers: image in -> validation -> preparation -> (OCR in smartscan.js) -> text normalisation -> parsing -> checks -> assessment.
// Every input route (live snap, phone camera, gallery, barcode) goes through these same functions. Original photos are never modified or stored.
// Scoring, thresholds and allergen rules are NOT here: they stay in engine.js / nutrition.js / advice.js (hash-pinned).
(function (root) {
  'use strict';
  const NODE = typeof module !== 'undefined' && module.exports;
  const mkDefault = (w, h) => { const c = root.document.createElement('canvas'); c.width = w; c.height = h; return c; };
  const gray = (d, i) => (d[i] * 299 + d[i + 1] * 587 + d[i + 2] * 114) / 1000;

  // ---- limits: smaller working images on low-memory phones (fewer crashes / freezes) ----
  function limits(nav) {
    nav = nav || root.navigator || {}; const mem = nav.deviceMemory, cores = nav.hardwareConcurrency, low = !!((mem && mem <= 3) || (cores && cores <= 4));
    return { low, maxSide: low ? 2400 : 3200, target: low ? 1800 : 2400, detail: low ? 2400 : 3200 }; // maxSide: stored photo size; target/detail: OCR working size
  }

  // ---- decode + high-quality downscale (never upscales; step-down halving keeps small print crisp) ----
  async function decodeBlob(blob) { // EXIF rotation honoured where the browser supports it; returns a drawable with width/height
    if (root.createImageBitmap) { try { return await root.createImageBitmap(blob, { imageOrientation: 'from-image' }); } catch (e) { /* fall through */ } }
    const url = root.URL.createObjectURL(blob);
    try { return await new Promise((ok, no) => { const i = new root.Image(); i.onload = () => ok(i); i.onerror = () => no(new Error('could not open the photo')); i.src = url; }); }
    finally { root.URL.revokeObjectURL(url); }
  }
  function resizeDown(src, w, h, mk) { // src: drawable; result is exactly w x h (or src size when no reduction is asked for)
    mk = mk || mkDefault; let cw = src.width, ch = src.height, cur = src;
    while (cw / 2 >= w && ch / 2 >= h) { const nw = Math.round(cw / 2), nh = Math.round(ch / 2), c = mk(nw, nh), x = c.getContext('2d', { willReadFrequently: true }); x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high'; x.drawImage(cur, 0, 0, nw, nh); if (cur !== src) { cur.width = 0; } cur = c; cw = nw; ch = nh; }
    const out = mk(w, h), g = out.getContext('2d', { willReadFrequently: true }); g.fillStyle = '#fff'; g.fillRect(0, 0, w, h); g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'high'; g.drawImage(cur, 0, 0, w, h);
    if (cur !== src) cur.width = 0; return out;
  }
  function toCanvas(drawable, max, mk) { const s = Math.min(1, max / Math.max(drawable.width, drawable.height)); return resizeDown(drawable, Math.max(1, Math.round(drawable.width * s)), Math.max(1, Math.round(drawable.height * s)), mk); }

  // ---- lossless geometry: exact 90-degree turns and integer-pixel crops (no interpolation, so no blur or lost detail) ----
  function rotate90(c, turns, mk) { // turns: 1 = 90 deg clockwise, 2 = 180, 3 = 90 deg anticlockwise. Pixels are only moved, never blended.
    turns = ((turns % 4) + 4) % 4; if (!turns) return c; mk = mk || mkDefault;
    const W = c.width, H = c.height, w2 = turns === 2 ? W : H, h2 = turns === 2 ? H : W, sx = c.getContext('2d', { willReadFrequently: true }), si = sx.getImageData(0, 0, W, H);
    const o = mk(w2, h2), ox = o.getContext('2d', { willReadFrequently: true }), oi = ox.createImageData(w2, h2), a = new Uint32Array(si.data.buffer), b = new Uint32Array(oi.data.buffer);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const v = a[y * W + x]; b[turns === 1 ? x * H + (H - 1 - y) : turns === 2 ? (H - 1 - y) * W + (W - 1 - x) : (W - 1 - x) * H + y] = v; }
    ox.putImageData(oi, 0, 0); return o;
  }
  function cropExact(src, r, mk) { // r in src pixels (may be fractional): rounded OUTWARD to whole pixels so no edge character is trimmed, then copied 1:1
    mk = mk || mkDefault; const x0 = Math.max(0, Math.floor(r.x)), y0 = Math.max(0, Math.floor(r.y)), x1 = Math.min(src.width, Math.ceil(r.x + r.w)), y1 = Math.min(src.height, Math.ceil(r.y + r.h));
    const w = Math.max(1, x1 - x0), h = Math.max(1, y1 - y0), o = mk(w, h), g = o.getContext('2d', { willReadFrequently: true }); g.imageSmoothingEnabled = false; g.drawImage(src, x0, y0, w, h, 0, 0, w, h); return o;
  }
  // ---- crop-dialog view (zoom / pan): the box lives in photo coordinates, so zooming never moves it ----
  const VIEW_MAX = 8;
  function viewClamp(v, W, H) { const z = Math.min(VIEW_MAX, Math.max(1, v.z)); return { z, ox: Math.min(0, Math.max(W - W * z, v.ox)), oy: Math.min(0, Math.max(H - H * z, v.oy)) }; } // the photo always covers the preview
  function viewZoomAt(v, factor, cx, cy, W, H) { const z = Math.min(VIEW_MAX, Math.max(1, v.z * factor)), k = z / v.z; return viewClamp({ z, ox: cx - (cx - v.ox) * k, oy: cy - (cy - v.oy) * k }, W, H); } // keeps the point under (cx, cy) fixed
  const viewToBase = (v, px, py) => [(px - v.ox) / v.z, (py - v.oy) / v.z];
  // ---- four-corner perspective correction (corners: top-left, top-right, bottom-right, bottom-left, in photo pixels) ----
  function solveHomography(dst, src) { // 3x3 (h8 = 1) mapping each dst point to the matching src point; Gaussian elimination with pivoting
    const A = []; for (let i = 0; i < 4; i++) { const [x, y] = dst[i], [X, Y] = src[i]; A.push([x, y, 1, 0, 0, 0, -x * X, -y * X, X]); A.push([0, 0, 0, x, y, 1, -x * Y, -y * Y, Y]); }
    for (let c = 0; c < 8; c++) { let m = c; for (let r = c + 1; r < 8; r++) if (Math.abs(A[r][c]) > Math.abs(A[m][c])) m = r; if (Math.abs(A[m][c]) < 1e-12) return null; [A[c], A[m]] = [A[m], A[c]];
      for (let r = 0; r < 8; r++) if (r !== c) { const f = A[r][c] / A[c][c]; for (let k = c; k < 9; k++) A[r][k] -= f * A[c][k]; } }
    return A.map((row, i) => row[8] / row[i]);
  }
  function quadInfo(q, minEdge) { // size of the straightened result + whether the four corners make a usable four-sided shape
    const d = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]), top = d(q[0], q[1]), bot = d(q[3], q[2]), lef = d(q[0], q[3]), rig = d(q[1], q[2]); let sign = 0, convex = true;
    for (let i = 0; i < 4; i++) { const a = q[i], b = q[(i + 1) % 4], c = q[(i + 2) % 4], cr = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]); if (Math.abs(cr) < 1e-6) convex = false; else { const sg = cr > 0 ? 1 : -1; if (!sign) sign = sg; else if (sg !== sign) convex = false; } }
    const w = Math.round(Math.max(top, bot)), h = Math.round(Math.max(lef, rig)); return { w, h, ok: convex && Math.min(top, bot, lef, rig) >= (minEdge || 24), convex };
  }
  function perspectiveWarp(src, q, mk, opts) { // returns { canvas, mode:'exact'|'warp' } or null when the corners are not a usable shape
    mk = mk || mkDefault; const info = quadInfo(q); if (!info.ok) return null;
    const xs = q.map(p => p[0]), ys = q.map(p => p[1]), bx0 = Math.min(...xs), bx1 = Math.max(...xs), by0 = Math.min(...ys), by1 = Math.max(...ys);
    if (q[0][1] === q[1][1] && q[3][1] === q[2][1] && q[0][0] === q[3][0] && q[1][0] === q[2][0]) return { canvas: cropExact(src, { x: bx0, y: by0, w: bx1 - bx0, h: by1 - by0 }, mk), mode: 'exact' }; // already a straight rectangle: copy pixels 1:1
    let w = info.w, h = info.h; const cap = (opts && opts.maxPixels) || 10e6; if (w * h > cap) { const k = Math.sqrt(cap / (w * h)); w = Math.max(1, Math.round(w * k)); h = Math.max(1, Math.round(h * k)); }
    const H = solveHomography([[0, 0], [w, 0], [w, h], [0, h]], q); if (!H) return null;
    const rx0 = Math.max(0, Math.floor(bx0) - 2), ry0 = Math.max(0, Math.floor(by0) - 2), rx1 = Math.min(src.width, Math.ceil(bx1) + 2), ry1 = Math.min(src.height, Math.ceil(by1) + 2), rw = rx1 - rx0, rh = ry1 - ry0;
    const sd = src.getContext('2d', { willReadFrequently: true }).getImageData(rx0, ry0, rw, rh).data; // only the region the corners cover
    const out = mk(w, h), og = out.getContext('2d', { willReadFrequently: true }), oi = og.createImageData(w, h), od = oi.data;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const px = x + 0.5, py = y + 0.5, dn = H[6] * px + H[7] * py + 1, X = (H[0] * px + H[1] * py + H[2]) / dn - 0.5 - rx0, Y = (H[3] * px + H[4] * py + H[5]) / dn - 0.5 - ry0;
      const x0 = Math.max(0, Math.min(rw - 1, Math.floor(X))), y0 = Math.max(0, Math.min(rh - 1, Math.floor(Y))), x1 = Math.min(rw - 1, x0 + 1), y1 = Math.min(rh - 1, y0 + 1), fx = Math.max(0, Math.min(1, X - x0)), fy = Math.max(0, Math.min(1, Y - y0));
      const i00 = (y0 * rw + x0) * 4, i10 = (y0 * rw + x1) * 4, i01 = (y1 * rw + x0) * 4, i11 = (y1 * rw + x1) * 4, o = (y * w + x) * 4;
      for (let c = 0; c < 3; c++) od[o + c] = (sd[i00 + c] * (1 - fx) + sd[i10 + c] * fx) * (1 - fy) + (sd[i01 + c] * (1 - fx) + sd[i11 + c] * fx) * fy + 0.5;
      od[o + 3] = 255;
    }
    og.putImageData(oi, 0, 0); return { canvas: out, mode: 'warp' };
  }
  function unsharp(c, amount, radius) { // unsharp mask with a box blur of the given radius (scale-aware: a 3x3 kernel cannot undo a 2-3 px blur)
    const w = c.width, h = c.height, r = Math.max(1, radius || 2), g = c.getContext('2d', { willReadFrequently: true }), im = g.getImageData(0, 0, w, h), d = im.data, s = new Uint8ClampedArray(d), t = new Uint8ClampedArray(d.length), n = 2 * r + 1; amount = amount == null ? 1 : amount;
    for (let y = 0; y < h; y++) for (let k = 0; k < 3; k++) { const row = y * w * 4 + k; let sum = (r + 1) * s[row]; for (let i = 1; i <= r; i++) sum += s[row + Math.min(w - 1, i) * 4]; for (let x = 0; x < w; x++) { t[row + x * 4] = sum / n + 0.5; sum += s[row + Math.min(w - 1, x + r + 1) * 4] - s[row + Math.max(0, x - r) * 4]; } }
    for (let x = 0; x < w; x++) for (let k = 0; k < 3; k++) { const col = x * 4 + k; let sum = (r + 1) * t[col]; for (let i = 1; i <= r; i++) sum += t[col + Math.min(h - 1, i) * w * 4]; for (let y = 0; y < h; y++) { const o = col + y * w * 4, bl = sum / n; d[o] = s[o] + amount * (s[o] - bl); sum += t[col + Math.min(h - 1, y + r + 1) * w * 4] - t[col + Math.max(0, y - r) * w * 4]; } }
    g.putImageData(im, 0, 0); return c;
  }
  const SHARP = { amount: 1.5, radius: 3 }; // chosen from the synthetic OCR measurements (harness/perspective-ocr.js)
  function straighten(src, q, mk) { // perspective correction, then a mild sharpen ONLY when the result is measurably blurry (on synthetic tests it helped there and never hurt)
    const r = perspectiveWarp(src, q, mk); if (!r) return null; r.sharpened = false;
    if (r.mode === 'warp') { let m = null; try { m = metrics(r.canvas); } catch (e) {} if (m && m.warnings.includes('blurry')) { unsharp(r.canvas, SHARP.amount, SHARP.radius); r.sharpened = true; } }
    return r;
  }
  // ---- image quality advice (advisory only: a read is never blocked) ----
  function smallGray(c, side) { const s = Math.min(1, side / Math.max(c.width, c.height)), w = Math.max(8, Math.round(c.width * s)), h = Math.max(8, Math.round(c.height * s)), t = resizeDown(c, w, h);
    const d = t.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, w, h).data, g = new Float32Array(w * h); for (let i = 0, q = 0; i < g.length; i++, q += 4) g[i] = gray(d, q); t.width = 0; return { g, w, h }; }
  function metrics(c) {
    const o = smallGray(c, 640), { g, w, h } = o, n = w * h; let sum = 0, hi = 0; const hist = new Uint32Array(256);
    for (let i = 0; i < n; i++) { sum += g[i]; if (g[i] >= 250) hi++; hist[g[i] | 0]++; }
    let a = 0, p5 = 0, p95 = 255, med = 0; for (let v = 0; v < 256; v++) { a += hist[v]; if (a >= n * 0.5) { med = v; break; } } a = 0; for (let v = 0; v < 256; v++) { a += hist[v]; if (a >= n * 0.05) { p5 = v; break; } } a = 0; for (let v = 255; v >= 0; v--) { a += hist[v]; if (a >= n * 0.05) { p95 = v; break; } }
    let m = 0, m2 = 0, k = 0; for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) { const i = y * w + x, l = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w]; m += l; m2 += l * l; k++; }
    const blur = k ? m2 / k - (m / k) * (m / k) : 0, mean = sum / n, glare = hi / n, contrast = p95 - p5, longSide = Math.max(c.width, c.height), warnings = [];
    if (longSide < 1000) warnings.push('low-resolution'); if (blur < 40) warnings.push('blurry'); if (mean < 70) warnings.push('dark'); if (glare > 0.04 && glare < 0.6 && med < 200) warnings.push('glare'); // saturated patches on a non-white background (a white label cannot be told from glare) if (contrast < 60) warnings.push('low-contrast');
    return { w: c.width, h: c.height, blur: Math.round(blur), mean: Math.round(mean), glare: Math.round(glare * 1000) / 1000, contrast, warnings };
  }
  const WARN_TEXT = { 'low-resolution': 'the photo is small', blurry: 'the photo looks blurry', dark: 'it is dark', glare: 'there is glare', 'low-contrast': 'contrast is low' };
  const adviceText = m => m && m.warnings.length ? 'Tip: ' + m.warnings.map(x => WARN_TEXT[x]).join(', ') + '. A closer, steadier, evenly lit photo reads better.' : '';

  // ---- ink map + automatic text region (default crop box; generous padding so characters, headings and units are never cut) ----
  function inkMap(c, side) {
    const { g, w, h } = smallGray(c, side), I = new Float64Array((w + 1) * (h + 1)), ink = new Uint8Array(w * h);
    for (let y = 1; y <= h; y++) { let row = 0; for (let x = 1; x <= w; x++) { row += g[(y - 1) * w + x - 1]; I[y * (w + 1) + x] = I[(y - 1) * (w + 1) + x] + row; } }
    const r = Math.max(6, Math.round(Math.min(w, h) / 20));
    for (let y = 0; y < h; y++) { const y0 = Math.max(0, y - r), y1 = Math.min(h, y + r + 1); for (let x = 0; x < w; x++) { const x0 = Math.max(0, x - r), x1 = Math.min(w, x + r + 1), area = (x1 - x0) * (y1 - y0);
      const mean = (I[y1 * (w + 1) + x1] - I[y0 * (w + 1) + x1] - I[y1 * (w + 1) + x0] + I[y0 * (w + 1) + x0]) / area; if (g[y * w + x] < mean * 0.82 && mean - g[y * w + x] > 12) ink[y * w + x] = 1; } }
    return { ink, w, h };
  }
  function textRegion(c) { // {x,y,w,h} in c's pixels, or null when the whole image is the sensible choice
    const { ink, w, h } = inkMap(c, 800), cell = Math.max(6, Math.round(Math.max(w, h) / 70)), cw = Math.ceil(w / cell), ch = Math.ceil(h / cell), dens = new Float32Array(cw * ch);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (ink[y * w + x]) dens[((y / cell) | 0) * cw + ((x / cell) | 0)]++;
    const on = new Uint8Array(cw * ch); for (let i = 0; i < on.length; i++) { const d = dens[i] / (cell * cell); on[i] = d >= 0.04 && d <= 0.7 ? 1 : 0; }
    let x0 = cw, y0 = ch, x1 = -1, y1 = -1;
    for (let y = 0; y < ch; y++) for (let x = 0; x < cw; x++) if (on[y * cw + x]) { let nb = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if ((dx || dy) && y + dy >= 0 && y + dy < ch && x + dx >= 0 && x + dx < cw && on[(y + dy) * cw + x + dx]) nb++;
      if (nb >= 2) { if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y; } }
    if (x1 < 0) return null;
    const padX = Math.max(2, Math.round((x1 - x0 + 1) * 0.06)), padY = Math.max(2, Math.round((y1 - y0 + 1) * 0.06));
    x0 = Math.max(0, x0 - padX); y0 = Math.max(0, y0 - padY); x1 = Math.min(cw - 1, x1 + padX); y1 = Math.min(ch - 1, y1 + padY);
    const sx = c.width / w, sy = c.height / h, box = { x: Math.floor(x0 * cell * sx), y: Math.floor(y0 * cell * sy), w: Math.min(c.width, Math.ceil((x1 - x0 + 1) * cell * sx)), h: Math.min(c.height, Math.ceil((y1 - y0 + 1) * cell * sy)) };
    box.w = Math.min(box.w, c.width - box.x); box.h = Math.min(box.h, c.height - box.y);
    return box.w * box.h > 0.92 * c.width * c.height ? null : box;
  }

  // ---- small-angle skew estimate from text-line projections ----
  function estimateSkew(c) {
    const { ink, w, h } = inkMap(c, 600), pts = []; for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (ink[y * w + x]) pts.push(x, y);
    const n = pts.length / 2; if (n < 200) return { deg: 0, conf: 0 }; const step = Math.max(1, Math.floor(n / 20000)), res = [];
    for (let a = -10; a <= 10.001; a += 0.5) { const t = a * Math.PI / 180, s = Math.sin(t), co = Math.cos(t), bins = new Float32Array(Math.ceil(w * Math.abs(s) + h * co) + 4), off = w * Math.abs(s) / 2 + 1; let cnt = 0;
      for (let i = 0; i < n; i += step) { const y = pts[2 * i + 1] * co - pts[2 * i] * s + off; bins[Math.max(0, Math.min(bins.length - 1, y | 0))]++; cnt++; }
      let m = 0, m2 = 0; for (const v of bins) { m += v; m2 += v * v; } m /= bins.length; res.push([a, m2 / bins.length - m * m]); }
    const best = res.reduce((p, q) => (q[1] > p[1] ? q : p)), sorted = res.map(r => r[1]).sort((p, q) => p - q), med = sorted[sorted.length >> 1] || 1;
    return { deg: best[0], conf: Math.round(((best[1] - med) / med) * 100) / 100 };
  }
  const SKEW_MIN_DEG = 1.5, SKEW_MIN_CONF = 0.25; // only a clear tilt is corrected
  function deskew(c, deg, mk) { mk = mk || mkDefault; const r = deg * Math.PI / 180, W = c.width, H = c.height, w = Math.ceil(Math.abs(W * Math.cos(r)) + Math.abs(H * Math.sin(r))), h = Math.ceil(Math.abs(W * Math.sin(r)) + Math.abs(H * Math.cos(r))), o = mk(w, h), x = o.getContext('2d', { willReadFrequently: true });
    x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); x.imageSmoothingQuality = 'high'; x.translate(w / 2, h / 2); x.rotate(-r); x.drawImage(c, -W / 2, -H / 2); return o; }

  // ---- text normalisation (raw OCR text is always kept; this only removes invisible / lookalike characters) ----
  function normaliseText(raw) {
    const before = String(raw == null ? '' : raw); let t = before; const changes = [];
    const step = (name, f) => { const n = f(t); if (n !== t) { changes.push(name); t = n; } };
    step('unicode-nfkc', s => (s.normalize ? s.normalize('NFKC') : s));
    step('invisible-characters', s => s.replace(/[\u200b-\u200f\u2060\ufeff\u00ad]/g, ''));
    step('spaces', s => s.replace(/[\u00a0\u2007\u202f]/g, ' ').replace(/[ \t]{2,}/g, ' ').replace(/ *\n */g, '\n'));
    return { text: t.trim(), changes };
  }

  // ---- common record: the same shape for photo routes and barcode routes ----
  function recordFromText(raw, o) { // o: { route, engine, passes, metrics }
    const E = root.Engine, R = root.NutritionReader, nt = normaliseText(raw), parts = E.focusParts(nt.text), nutIn = parts.ingredients + '\n' + parts.nutrition, nut = R.parse(nutIn);
    return { source: { route: (o && o.route) || 'unknown', engine: (o && o.engine) || '', passes: (o && o.passes) || [] }, raw: String(raw || ''), normalised: nt.text, normChanges: nt.changes, ingredientsText: parts.ingredients, nutritionText: parts.nutrition,
      nutrition: nut, flags: nut.flags.slice(), corrections: nut.corrections.slice(), metrics: (o && o.metrics) || null };
  }
  function recordFromProduct(p, route) { // a barcode record: database values, shown the same way; nothing is invented
    const N = root.Nutrition; return { source: { route: route || 'barcode', engine: 'database', passes: [] }, raw: p.ingredients || '', normalised: p.ingredients || '', ingredientsText: p.ingredients || '', nutritionText: N.format(p.nutrition), nutrition: p.nutrition, flags: [], corrections: [], metrics: null };
  }
  function compareKnown(text, ing, cand) { // both records, side by side, for the confirmation step (nothing is merged or invented)
    const E = root.Engine, N = root.Nutrition, a = ing.found.map(f => f.name), bb = E.analyze(cand.ingredients, {}).found.map(f => f.name);
    return { scan: { text: String(text || ''), ingredients: a, unknown: ing.unknown.length }, bundled: { name: cand.name, brand: cand.brand, text: cand.ingredients, nutrition: N.format(cand.nutrition), ingredients: bb }, onlyBundled: bb.filter(x => !a.includes(x)), onlyScan: a.filter(x => !bb.includes(x)) };
  }
  const NUT_FLAG_TEXT = { 'sat-fat-above-total-fat': 'saturated fat is higher than total fat', 'sugars-above-carbohydrate': 'sugars are higher than carbohydrate', 'macros-above-100g': 'fat + carbohydrate + protein is above 100 g', 'kcal-vs-macros-mismatch': 'energy does not match the macro numbers', 'per-serve-only': 'the table shows per-serve values only, so they were not used as per-100 g', 'paired-by-order': 'labels and numbers were matched by order', 'ambiguous-row': 'a row had values I could not place in a column', 'no-column-header': 'no column header was found, so the first number was used' };
  const flagText = fl => { const t = (fl || []).filter(f => NUT_FLAG_TEXT[f]).map(f => NUT_FLAG_TEXT[f]); return t.length ? 'Check the nutrition numbers: ' + t.join('; ') + '.' : ''; };

  const api = { solveHomography, quadInfo, perspectiveWarp, unsharp, straighten, viewClamp, viewZoomAt, viewToBase, VIEW_MAX, rotate90, cropExact, limits, decodeBlob, resizeDown, toCanvas, metrics, adviceText, inkMap, textRegion, estimateSkew, deskew, SKEW_MIN_DEG, SKEW_MIN_CONF, normaliseText, recordFromText, recordFromProduct, compareKnown, flagText };
  if (NODE) module.exports = api; else root.Pipeline = api;
})(typeof window !== 'undefined' ? window : globalThis);
