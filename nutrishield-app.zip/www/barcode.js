// Barcode helpers: check-digit validation (EAN-8, UPC-A, EAN-13, GTIN-14, UPC-E), UPC-E expansion,
// and a decoder that tries several scales and rotations (photos) or a full-resolution frame (live camera).
(function (root) {
  'use strict';
  function checkOk(code) { // GS1 check digit
    const d = code.split('').map(Number), check = d.pop();
    let sum = 0;
    for (let i = d.length - 1, w = 3; i >= 0; i--, w = 4 - w) sum += d[i] * w;
    return (10 - (sum % 10)) % 10 === check;
  }
  function expandUpcE(c) { // 8-digit UPC-E (number system 0 or 1) -> 12-digit UPC-A, or null
    if (!/^[01]\d{7}$/.test(c)) return null;
    const n = c[0], d = c.slice(1, 7), chk = c[7], F = d[5]; let m, p;
    if ('012'.includes(F)) { m = d.slice(0, 2) + F + '00'; p = '00' + d.slice(2, 5); }
    else if (F === '3') { m = d.slice(0, 3) + '00'; p = '000' + d.slice(3, 5); }
    else if (F === '4') { m = d.slice(0, 4) + '0'; p = '0000' + d[4]; }
    else { m = d.slice(0, 5); p = '0000' + F; }
    return n + m + p + chk;
  }
  function isValidGtin(code) {
    code = String(code || '').trim();
    if (!/^\d+$/.test(code) || ![8, 12, 13, 14].includes(code.length)) return false;
    if (checkOk(code)) return true;
    if (code.length === 8) { const a = expandUpcE(code); return !!a && checkOk(a); }
    return false;
  }
  function normalize(code) { // a valid UPC-E becomes its UPC-A; everything else is only stripped to digits
    code = String(code || '').replace(/\D/g, '');
    if (code.length === 8 && !checkOk(code)) { const a = expandUpcE(code); if (a && checkOk(a)) return a; }
    return code;
  }

  // ---- decoding (needs the ZXing library: window.ZXing in the app, require('./vendor/zxing.min.js') in tests) ----
  const mkCanvas = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
  function grey(c) {
    const w = c.width, h = c.height, d = c.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, w, h).data, g = new Uint8ClampedArray(w * h);
    for (let i = 0, q = 0; i < g.length; i++, q += 4) g[i] = (d[q] * 299 + d[q + 1] * 587 + d[q + 2] * 114) / 1000;
    return { g, w, h };
  }
  function readGrey(Z, o, hard) {
    const mr = new Z.MultiFormatReader(), hn = new Map();
    hn.set(Z.DecodeHintType.POSSIBLE_FORMATS, [Z.BarcodeFormat.EAN_13, Z.BarcodeFormat.EAN_8, Z.BarcodeFormat.UPC_A, Z.BarcodeFormat.UPC_E]);
    if (hard) hn.set(Z.DecodeHintType.TRY_HARDER, true);
    mr.setHints(hn);
    try { const t = mr.decode(new Z.BinaryBitmap(new Z.HybridBinarizer(new Z.RGBLuminanceSource(o.g, o.w, o.h)))).getText(); return isValidGtin(t) ? normalize(t) : null; }
    catch (e) { return null; }
  }
  function transform(src, k, rot, mk) { // src scaled by k and turned by 0/90/180/270
    const w = Math.max(1, Math.round(src.width * k)), h = Math.max(1, Math.round(src.height * k)), swap = rot === 90 || rot === 270;
    const c = mk(swap ? h : w, swap ? w : h), x = c.getContext('2d', { willReadFrequently: true });
    x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
    x.translate(c.width / 2, c.height / 2); x.rotate(rot * Math.PI / 180); x.drawImage(src, -w / 2, -h / 2, w, h); return c;
  }
  // A photo: whole picture first, then other scales and turns. Returns a valid code or null.
  function decodePhoto(canvas, Z, mk) {
    if (!Z) return null; mk = mk || mkCanvas;
    const big = Math.max(canvas.width, canvas.height), base = Math.min(1, 2600 / big);
    const plan = [[base, 0], [base * 0.6, 0], [Math.min(1.6, 2600 / big) * (big < 1600 ? 1.5 : 1), 0], [base, 90], [base, 270], [base, 180], [base * 0.6, 90], [base * 0.6, 270]];
    const tried = new Set();
    for (const [k, rot] of plan) {
      const key = Math.round(k * 100) + '_' + rot; if (tried.has(key) || k <= 0.05) continue; tried.add(key);
      const t = readGrey(Z, grey(transform(canvas, k, rot, mk)), true); if (t) return t;
    }
    return null;
  }
  // A live video frame: full resolution (max 1280 wide, never squashed), alternating straight and turned reads.
  function decodeFrame(video, Z, tick, mk) {
    if (!Z || !video.videoWidth) return null; mk = mk || mkCanvas;
    const k = Math.min(1, 1280 / video.videoWidth), c = mk(Math.round(video.videoWidth * k), Math.round(video.videoHeight * k));
    c.getContext('2d', { willReadFrequently: true }).drawImage(video, 0, 0, c.width, c.height);
    const rot = tick % 3 === 2 ? 90 : 0, src = rot ? transform(c, 1, rot, mk) : c;
    return readGrey(Z, grey(src), tick % 2 === 1);
  }
  const api = { isValidGtin, normalize, expandUpcE, decodePhoto, decodeFrame };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Barcode = api;
})(typeof window !== 'undefined' ? window : globalThis);
