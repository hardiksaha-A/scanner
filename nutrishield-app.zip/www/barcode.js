// Barcode number validation and normalisation (EAN-8, UPC-A, UPC-E, EAN-13, GTIN-14).
// isValidGtin() keeps its original meaning (8/12/13/14 digits, mod-10 check digit) so existing callers behave the same;
// UPC-E is recognised by normalize(), which also gives every code one canonical key plus the older key forms that may already be stored.
(function (root) {
  'use strict';
  const check = body => { let sum = 0; for (let i = body.length - 1, w = 3; i >= 0; i--, w = 4 - w) sum += +body[i] * w; return (10 - (sum % 10)) % 10; };
  function isValidGtin(code) {
    code = String(code || '').trim();
    if (!/^\d+$/.test(code) || ![8, 12, 13, 14].includes(code.length)) return false;
    return check(code.slice(0, -1)) === +code[code.length - 1];
  }
  // UPC-E (8 digits: number system 0 or 1, 6 digits, check digit) -> the UPC-A it stands for. null if it cannot be one.
  function expandUpcE(code) {
    code = String(code || '').trim();
    if (!/^[01]\d{7}$/.test(code)) return null;
    const ns = code[0], d = code.slice(1, 7), last = d[5], chk = code[7]; let m, p;
    if (last <= '2') { m = d[0] + d[1] + last + '00'; p = '00' + d[2] + d[3] + d[4]; }
    else if (last === '3') { m = d[0] + d[1] + d[2] + '00'; p = '000' + d[3] + d[4]; }
    else if (last === '4') { m = d[0] + d[1] + d[2] + d[3] + '0'; p = '0000' + d[4]; }
    else { m = d.slice(0, 5); p = '0000' + last; }
    const a = ns + m + p;
    return check(a) === +chk ? a + chk : null;
  }
  // UPC-A -> UPC-E when it can be compressed (used by tests and to list every stored form of a code).
  function compressUpcA(code) {
    code = String(code || '').trim();
    if (!/^[01]\d{11}$/.test(code)) return null;
    const ns = code[0], m = code.slice(1, 6), p = code.slice(6, 11), c = code[11]; let e = null;
    if (/^\d\d[012]00$/.test(m) && /^00\d{3}$/.test(p)) e = m[0] + m[1] + p[2] + p[3] + p[4] + m[2];
    else if (/^\d\d\d00$/.test(m) && /^000\d\d$/.test(p)) e = m[0] + m[1] + m[2] + p[3] + p[4] + '3';
    else if (/^\d\d\d\d0$/.test(m) && /^0000\d$/.test(p)) e = m[0] + m[1] + m[2] + m[3] + p[4] + '4';
    else if (/^0000[5-9]$/.test(p)) e = m + p[4];
    return e ? ns + e + c : null;
  }
  // opts.format: the scanner's own format name when known ('upc_e', 'ean_8', ...), used only to settle an 8-digit code that is valid both ways.
  function normalize(raw, opts) {
    const original = String(raw == null ? '' : raw).replace(/\D/g, '');
    const bad = reason => ({ ok: false, reason, original, kind: null, key: null, aliases: [] });
    if (!original) return bad('empty');
    const fmt = String((opts && opts.format) || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    let kind, a13 = null, extra = [];
    if (original.length === 8) {
      const ean8 = isValidGtin(original), upce = expandUpcE(original);
      if (ean8 && upce) kind = fmt === 'upce' ? 'UPC-E' : 'EAN-8'; // ambiguous: the scanner's format wins; without one, EAN-8 (the previous behaviour)
      else kind = ean8 ? 'EAN-8' : upce ? 'UPC-E' : null;
      if (!kind) return bad('check_digit');
      if (kind === 'UPC-E') { const a = expandUpcE(original); a13 = '0' + a; extra = [a, original]; } else a13 = '00000' + original;
    } else if (original.length === 12) { if (!isValidGtin(original)) return bad('check_digit'); kind = 'UPC-A'; a13 = '0' + original; }
    else if (original.length === 13) { if (!isValidGtin(original)) return bad('check_digit'); kind = 'EAN-13'; a13 = original; }
    else if (original.length === 14) {
      if (!isValidGtin(original)) return bad('check_digit'); kind = 'GTIN-14';
      if (original[0] === '0') a13 = original.slice(1); // indicator 0 = the same item as the 13-digit code
      else return { ok: true, original, kind, key: original, gtin13: null, aliases: [original] }; // a packaging level of an item: its own code
    } else return bad('length');
    const out = [], add = v => { if (v && !out.includes(v)) out.push(v); };
    add(a13); add(original); extra.forEach(add);                    // canonical key first, then the code as scanned (older records), UPC-E expansion
    if (kind !== 'EAN-8') { if (a13[0] === '0') add(a13.slice(1)); add('0' + a13); } // UPC-A form (12) and GTIN-14 form
    return { ok: true, original, kind, key: a13, gtin13: a13, aliases: out };
  }
  const api = { isValidGtin, normalize, expandUpcE, compressUpcA, check };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Barcode = api;
})(typeof window !== 'undefined' ? window : globalThis);
