# Real-Chromium end-to-end test (Playwright, Python). Run: python3 scripts/e2e/browser_e2e.py  (needs: node scripts/prep.js first)
# Not part of CI verify (needs a browser); results are reported in INDIA_TEST_REPORT.md.
import http.server, threading, json, os, sys, functools, re
from playwright.sync_api import sync_playwright
ROOT = os.path.join(os.path.dirname(__file__), '..', '..', 'www')
class H(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith('/__sw_test.js'):
            self.send_response(200); self.send_header('Content-Type', 'application/javascript'); self.end_headers(); self.wfile.write(b'self.addEventListener("fetch",()=>{});'); return
        return super().do_GET()
    def log_message(self, *a): pass
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(H, directory=ROOT)); port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = f'http://127.0.0.1:{port}/index.html'
res = []; 
def check(name, cond, detail=''):
    res.append((name, bool(cond), detail)); print(('PASS ' if cond else 'FAIL ') + name + ('' if cond else '  -> ' + str(detail)))
FULL = 'Ingredients: Rice flour, sugar, salt, edible vegetable oil, spices.'
OFF_BODY = {'status': 1, 'code': '8901058852004', 'product': {'product_name': 'Test Biscuit', 'ingredients_text': FULL, 'allergens_tags': [], 'traces_tags': [], 'nutriments': {'energy-kcal_100g': 450, 'fat_100g': 10, 'sugars_100g': 20, 'salt_100g': 0.5}, 'last_modified_t': 1790000000}}
with sync_playwright() as pw:
    b = pw.chromium.launch(); 
    def newpage(init=None, record=None):
        ctx = b.new_context(); pg = ctx.new_page(); errs = []
        pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.accept())
        if record is not None: pg.on('request', lambda r: record.append(r.url))
        if init: ctx.add_init_script(init)
        return ctx, pg, errs
    ls = lambda pg, k: pg.evaluate('k=>localStorage.getItem(k)', k)
    # ---- 1. fresh install as a child / unknown
    reqs = []; ctx, pg, errs = newpage(record=reqs)
    pg.route('https://world.openfoodfacts.org/**', lambda r: r.fulfill(status=200, content_type='application/json', body=json.dumps(OFF_BODY)))
    pg.goto(BASE); pg.wait_for_selector('#viewProfile:not([hidden])', timeout=15000)
    check('fresh install opens onboarding', pg.is_visible('#viewProfile'))
    check('no age option pre-selected, no box pre-ticked', pg.evaluate("document.querySelectorAll('input[name=pAgeStatus]:checked').length===0 && !pConsent.checked && !pHealthConsent.checked && !pHistoryConsent.checked"))
    pg.click('#saveProfileBtn'); check('cannot save without choosing an age status', 'age status' in pg.inner_text('#pErr'))
    pg.check('input[name=pAgeStatus][value=under18]'); pg.check('#pConsent') 
    check('under-18: child notice shown, health/history/nickname hidden', pg.is_visible('#childNotice') and not pg.is_visible('#healthBlock') and not pg.is_visible('#historyBlock') and not pg.is_visible('#pNameWrap'))
    check('under-18: only stricter-child mode selectable', pg.evaluate("Array.from(pMode.options).filter(o=>!o.disabled).map(o=>o.value).join()") == 'kids')
    pg.click('#saveProfileBtn'); pg.wait_for_selector('#viewScan:not([hidden])')
    age = json.loads(ls(pg, 'ns.age.v1')); led = json.loads(ls(pg, 'ns.consent.v1')); prof = json.loads(ls(pg, 'nutrishield.profile'))
    check('age record: under18, self-declared, verified=false', age['status'] == 'under18' and age['verified'] is False and age['source'] == 'self_declared')
    check('ledger: only terms/privacy ack with notice version + timestamp', [r['purpose'] for r in led] == ['terms_privacy_ack'] and led[0]['docVersions'] == {'privacy': 'draft-0.2.0', 'terms': 'draft-0.1.0'} and led[0]['noticeVersion'] and led[0]['ts'] and led[0]['ageVerified'] is False)
    check('child profile: kids mode, no name, no health data', prof['mode'] == 'kids' and prof['name'] == '' and prof['allergies'] == [] and prof['conditions'] == [] and 'age' not in prof)
    # text analysis as child: allergy panel absent, no history saved, no network
    n0 = len(reqs); pg.fill('#labelText', FULL); pg.click('#analyzeTextBtn'); pg.wait_for_selector('#resultArea .verdict-banner')
    check('child scan works without profile', 'OUT OF 100' in pg.inner_text('#resultArea'))
    check('child: nothing saved to history', ls(pg, 'ls.history') in (None, '[]'))
    check('child: no network request during text scan', all(u.startswith(f'http://127.0.0.1:{port}') or u.startswith('data:') or u.startswith('blob:') for u in reqs[n0:]), reqs[n0:])
    # barcode as child: network goes to OFF only, no profile data, no cache write
    pg.fill('#bcInput', '8901058852004'); pg.click('#bcLookupBtn'); pg.wait_for_selector('#resultArea .verdict-banner')
    off = [u for u in reqs if 'openfoodfacts' in u]
    check('barcode lookup contacts only world.openfoodfacts.org with fields param', len(off) >= 1 and all(u.startswith('https://world.openfoodfacts.org/api/v2/product/8901058852004.json?fields=') for u in off) and 'last_modified_t' in off[0], off)
    check('request carries no profile/age/allergy data', not re.search(r'age|under18|consent|allerg(?!ens_tags)|profile', off[0].split('fields=')[1].replace('allergens_tags', '')), off[0])
    check('child: offline cache not written', ls(pg, 'nutrishield.cache') is None)
    # settings privacy card
    pg.click('.bnav [data-tab=settings]'); card = pg.inner_text('#privacyCard')
    check('settings shows self-declared age, unavailable parental authorisation, health off', 'Under 18 (self-declared)' in card and 'not available in this version' in card and 'Health profile: Off' in card and 'cannot be turned on' in card)
    check('no "verified"/"compliant" claim in privacy card', not re.search(r'verified by|is verified|compliant|approved', card, re.I) or 'never verified' in card)
    # legal viewer
    pg.click('#privacyCard [data-legal=privacy]'); pg.wait_for_selector('#legalOverlay:not([hidden])'); lt = pg.inner_text('#legalBody')
    check('legal viewer: draft banner + placeholders highlighted', 'DRAFT' in lt and 'Not approved for production' in lt and pg.locator('#legalBody mark.req').count() >= 8 and '17 required inputs' in lt, pg.locator('#legalBody mark.req').count())
    check('legal viewer: no invented email/phone/company', not re.search(r'@[a-z]+\.|Pvt|Ltd|LLP', lt))
    pg.click('#legalClose'); check('legal viewer closes', not pg.is_visible('#legalOverlay'))
    check('child session: no JS errors', not errs, errs)
    ctx.close()
    # ---- 2. adult with consents
    reqs = []; ctx, pg, errs = newpage(record=reqs); pg.route('https://world.openfoodfacts.org/**', lambda r: r.fulfill(status=200, content_type='application/json', body=json.dumps(OFF_BODY)))
    pg.goto(BASE); pg.wait_for_selector('#viewProfile:not([hidden])')
    pg.check('input[name=pAgeStatus][value=adult]'); check('adult: health & history blocks visible, fields locked until consent', pg.is_visible('#healthBlock') and pg.evaluate("pAllergies.disabled") and pg.evaluate("Array.from(pMode.options).find(o=>o.value==='pregnancy').disabled"))
    pg.check('#pHealthConsent'); check('health consent unlocks fields and pregnancy mode', not pg.evaluate("pAllergies.disabled") and not pg.evaluate("Array.from(pMode.options).find(o=>o.value==='pregnancy').disabled"))
    pg.fill('#pName', 'Asha'); pg.fill('#pAllergies', 'peanut, a'); pg.check('#pConsent'); pg.click('#saveProfileBtn')
    check('1-letter allergy entry rejected with message (not silently dropped)', 'too short' in pg.inner_text('#pErr') and pg.is_visible('#viewProfile'))
    pg.fill('#pAllergies', 'peanut, ow'); pg.check('#pHistoryConsent'); pg.click('#saveProfileBtn'); pg.wait_for_selector('#viewScan:not([hidden])')
    led = json.loads(ls(pg, 'ns.consent.v1')); check('ledger: terms + health + history granted, adult self-declared', sorted(r['purpose'] for r in led) == ['health_profile', 'local_history', 'terms_privacy_ack'] and all(r['ageVerified'] is False for r in led))
    prof = json.loads(ls(pg, 'nutrishield.profile')); check('adult profile holds allergies only with consent', prof['allergies'] == ['peanut', 'ow'] and prof['name'] == 'Asha')
    pg.fill('#labelText', FULL); pg.click('#analyzeTextBtn'); pg.wait_for_selector('#resultArea .alert-info'); rt = pg.inner_text('#resultArea')
    check('clean label -> qualified "No match found in the available information"', 'No match found in the available information' in rt and 'does NOT mean' in rt)
    check('no "Allergy Check Clear" / "Safe Choice" anywhere in result', not re.search(r'Allergy Check Clear|Safe Choice|✅ Allergy', rt))
    check('score band wording shown as range', re.search(r'(Higher|Moderate|Low|Very low) score \(\d+–\d+\)', rt) is not None, rt[:300])
    check('analysis saved to history with consent', json.loads(ls(pg, 'ls.history') or '[]') != [])
    pg.fill('#labelText', 'Ingredients: Wheat flour, peanut oil, sugar, salt, palm oil, spices.'); pg.click('#analyzeTextBtn'); pg.wait_for_selector('#resultArea .alert-red')
    check('peanut label -> ALLERGY WARNING', 'ALLERGY WARNING' in pg.inner_text('#resultArea'))
    pg.fill('#labelText', 'xq zz'); pg.click('#analyzeTextBtn'); pg.wait_for_timeout(600); rt = pg.inner_text('#resultArea')
    check('unreadable text never gives a reassuring allergy message', 'No match found' not in rt and 'cannot rule out' in rt or 'not possible' in rt.lower() or 'uncertain' in rt.lower(), rt[:200])
    pg.fill('#bcInput', '8901058852004'); pg.click('#bcLookupBtn'); pg.wait_for_selector('#resultArea .alert-info'); rt = pg.inner_text('#resultArea')
    check('OFF product -> source and data date shown, still qualified', 'Open Food Facts' in rt and 'last updated 20' in rt)
    cache = json.loads(ls(pg, 'nutrishield.cache') or '{}'); check('offline cache written with cachedAt (consent given)', '8901058852004' in cache and cache['8901058852004'].get('cachedAt'))
    # withdraw health -> deleted
    pg.click('.bnav [data-tab=settings]'); pg.click('#privacyCard [data-act=withdrawHealth]')
    prof = json.loads(ls(pg, 'nutrishield.profile')); led = json.loads(ls(pg, 'ns.consent.v1'))
    check('withdraw health: fields deleted, ledger keeps withdrawn record', prof['allergies'] == [] and prof['mode'] in ('adult', 'kids', 'older') and any(r['purpose'] == 'health_profile' and r['withdrawnAt'] for r in led))
    pg.click('#privacyCard [data-act=withdrawHistory]'); check('withdraw history: history/fav/labels/cache deleted', all(ls(pg, k) is None for k in ['ls.history', 'ls.fav', 'nutrishield.cache']))
    check('adult session: no JS errors', not errs, errs)
    # ---- 2b. Terms and Privacy have separate versions; users re-accept only the document that changed
    acc = lambda: [r for r in json.loads(ls(pg, 'ns.consent.v1')) if r['purpose'] == 'terms_privacy_ack']
    pg.click('[data-tab=settings]'); pg.click('#editProfileBtn'); pg.wait_for_selector('#viewProfile:not([hidden])')
    check('terms box hidden when editing profile after first acceptance', not pg.is_visible('#pConsentWrap'))
    pg.click('#saveProfileBtn'); pg.wait_for_selector('#viewScan:not([hidden])')
    check('saving with unchanged documents adds no acceptance record', len(acc()) == 1)
    pg.reload(); pg.wait_for_selector('#viewScan:not([hidden])'); check('reload with unchanged documents does not ask again', pg.is_visible('#viewScan') and not pg.is_visible('#viewProfile'))
    pg.click('[data-tab=settings]'); check('terms/privacy still viewable from settings', pg.is_visible('#privacyCard [data-legal=terms]') and pg.is_visible('#privacyCard [data-legal=privacy]'))
    pg.evaluate("()=>{const l=JSON.parse(localStorage.getItem('ns.consent.v1'));l.forEach(r=>{if(r.purpose==='terms_privacy_ack')r.docVersions.privacy='draft-0.1.0'});localStorage.setItem('ns.consent.v1',JSON.stringify(l))}")
    pg.reload(); pg.wait_for_selector('#viewProfile:not([hidden])')
    check('older accepted Privacy version blocks the app until re-accepted', pg.is_visible('#pConsentWrap') and not pg.is_checked('#pConsent') and not pg.is_visible('#viewScan') and not pg.is_visible('#cancelProfileBtn'))
    txt = pg.inner_text('#pConsentWrap'); check('prompt names only the changed document (Privacy), not Terms', 'Privacy Policy' in txt and 'Terms of Use' not in txt)
    pg.click('[data-tab=scan]'); check('navigation cannot bypass the re-acceptance screen', pg.is_visible('#viewProfile') and not pg.is_visible('#viewScan'))
    pg.click('#saveProfileBtn'); check('save blocked until the box is ticked', 'tick the confirmation' in pg.inner_text('#pErr'))
    pg.check('#pConsent'); pg.click('#saveProfileBtn'); pg.wait_for_selector('#viewScan:not([hidden])')
    a = acc(); cur = pg.evaluate("({privacy: Legal.docs.privacy.version, terms: Legal.docs.terms.version})")
    check('re-acceptance appended with both current versions; earlier record kept unchanged', len(a) == 2 and a[0]['docVersions']['privacy'] == 'draft-0.1.0' and a[-1]['docVersions'] == cur)
    check('Terms and Privacy carry different version numbers', cur['privacy'] != cur['terms'])
    pg.reload(); pg.wait_for_selector('#viewScan:not([hidden])'); check('after re-acceptance the app opens normally', pg.is_visible('#viewScan'))
    # ---- 2c. voice on/off is respected everywhere; no country selector
    pg.click('[data-tab=scan]')
    check('top bar has the voice button and no country selector exists anywhere', pg.is_visible('#topVoiceBtn') and not any(pg.query_selector(s) for s in ('#topCountry', '#sCountry', '#pCountry')))
    check('voice defaults to off', 'Off' in pg.inner_text('#topVoiceBtn') and not pg.is_checked('#autoVoiceToggle') and ls(pg, 'nutrishield.speak') in (None, '0'))
    pg.click('#topVoiceBtn'); check('top voice button turns voice on (setting stored)', 'On' in pg.inner_text('#topVoiceBtn') and pg.is_checked('#autoVoiceToggle') and ls(pg, 'nutrishield.speak') == '1' and pg.get_attribute('#topVoiceBtn', 'aria-pressed') == 'true')
    pg.reload(); pg.wait_for_selector('#viewScan:not([hidden])'); check('voice setting survives reload', 'On' in pg.inner_text('#topVoiceBtn'))
    pg.evaluate("()=>{window.__spoke=0;window.__cancel=0;const s=speechSynthesis.speak.bind(speechSynthesis),c=speechSynthesis.cancel.bind(speechSynthesis);speechSynthesis.speak=u=>{window.__spoke++;return s(u)};speechSynthesis.cancel=()=>{window.__cancel++;return c()}}")
    pg.click('[data-demo=oats]'); pg.wait_for_selector('#resSpeakBtn')
    check('voice on: automatic speech after a scan and manual button enabled', pg.evaluate('window.__spoke') >= 1 and pg.is_enabled('#resSpeakBtn'))
    n = pg.evaluate('window.__spoke'); pg.click('#resSpeakBtn'); check('voice on: Speak Result Aloud speaks', pg.evaluate('window.__spoke') > n)
    pg.click('#topVoiceBtn')
    check('turning voice off stops speech, stores 0 and disables Speak Result Aloud', 'Off' in pg.inner_text('#topVoiceBtn') and ls(pg, 'nutrishield.speak') == '0' and pg.evaluate('window.__cancel') >= 1 and pg.is_disabled('#resSpeakBtn') and pg.is_enabled('#resStopSpeakBtn'))
    n = pg.evaluate('window.__spoke'); pg.click('[data-demo=cola]'); pg.wait_for_selector('#resSpeakBtn')
    check('voice off: no automatic speech and manual button stays disabled on a new result', pg.evaluate('window.__spoke') == n and pg.is_disabled('#resSpeakBtn'))
    pg.evaluate("document.getElementById('resSpeakBtn').click()"); check('voice off: forcing the manual button speaks nothing', pg.evaluate('window.__spoke') == n)
    pg.click('[data-tab=settings]'); check('voice off: Test Voice disabled in Settings, Stop Voice still enabled', pg.is_disabled('#testVoiceBtn') and pg.is_enabled('#stopVoiceBtn'))
    pg.check('#autoVoiceToggle'); check('Settings toggle turns voice on everywhere', 'On' in pg.inner_text('#topVoiceBtn') and pg.is_enabled('#testVoiceBtn') and pg.is_enabled('#resSpeakBtn'))
    pg.uncheck('#autoVoiceToggle'); check('Settings toggle turns voice off everywhere', 'Off' in pg.inner_text('#topVoiceBtn') and pg.is_disabled('#testVoiceBtn') and pg.is_disabled('#resSpeakBtn'))
    # ---- 2d. contact/country data are purged; default mode follows the age choice
    pg.evaluate("()=>{const p=JSON.parse(localStorage.getItem('nutrishield.profile'));p.email='a@b.in';p.mobile='9876543210';p.country='IN';p.countrySource='user';localStorage.setItem('nutrishield.profile',JSON.stringify(p))}")
    pg.reload(); pg.wait_for_selector('#viewScan:not([hidden])'); pf = json.loads(ls(pg, 'nutrishield.profile'))
    check('email/mobile/country saved by an earlier build are purged on load', not any(k in pf for k in ('email', 'mobile', 'country', 'countrySource')))
    modes = lambda p: p.evaluate("Array.from(pMode.options).filter(o=>!o.disabled).map(o=>o.value).join()")
    c2, p2, e2 = newpage(); p2.goto(BASE); p2.wait_for_selector('#viewProfile:not([hidden])', timeout=15000)
    check('before an age is chosen the child-safe mode is shown', p2.input_value('#pMode') == 'kids')
    p2.check('input[name=pAgeStatus][value=adult]')
    check('self-declared 18+ starts in Adult mode', p2.input_value('#pMode') == 'adult' and 'adult' in modes(p2) and 'kids' in modes(p2))
    check('pregnancy mode still needs the optional health consent', 'pregnancy' not in modes(p2))
    p2.select_option('#pMode', 'kids'); p2.check('input[name=pAgeStatus][value=under18]'); p2.check('input[name=pAgeStatus][value=adult]')
    check('an adult can deliberately keep Stricter Child Checks', p2.input_value('#pMode') == 'kids')
    p2.select_option('#pMode', 'adult'); p2.check('input[name=pAgeStatus][value=unknown]')
    check('age not stated: child-safe mode only', p2.input_value('#pMode') == 'kids' and modes(p2) == 'kids')
    p2.check('input[name=pAgeStatus][value=adult]'); check('back to 18+: Adult mode again', p2.input_value('#pMode') == 'adult')
    p2.check('#pConsent'); p2.click('#saveProfileBtn'); p2.wait_for_selector('#viewScan:not([hidden])')
    pr = json.loads(ls(p2, 'nutrishield.profile'))
    check('saved adult profile: Adult mode, no email/mobile/country keys', pr['mode'] == 'adult' and not any(k in pr for k in ('email', 'mobile', 'country', 'countrySource')))
    check('header shows Adult Mode and no country', 'Adult Mode' in p2.inner_text('#hdrProfileTag'))
    score = lambda p: re.search(r'(\d{1,3})\s*/\s*100', p.inner_text('#resultArea')).group(1)
    p2.click('[data-demo=cola]'); p2.wait_for_selector('#resSpeakBtn'); s_adult = score(p2)
    p2.click('[data-tab=settings]'); p2.click('#editProfileBtn'); p2.wait_for_selector('#viewProfile:not([hidden])'); p2.select_option('#pMode', 'kids'); p2.click('#saveProfileBtn'); p2.wait_for_selector('#viewScan:not([hidden])')
    p2.click('[data-demo=cola]'); p2.wait_for_selector('#resSpeakBtn'); s_kids = score(p2)
    check('scoring formula unchanged by the mode default (same product, same score)', s_adult == s_kids, (s_adult, s_kids))
    pg.click('[data-tab=settings]')
    # ---- 3. full wipe across every storage
    pg.evaluate("""async () => { sessionStorage.setItem('t','1'); document.cookie='ck=1; path=/';
      await new Promise((res,rej)=>{const r=indexedDB.open('e2e-db',1); r.onupgradeneeded=()=>r.result.createObjectStore('s'); r.onsuccess=()=>{r.result.close();res()}; r.onerror=rej});
      const c=await caches.open('e2e-cache'); await c.put('/x', new Response('x'));
      await navigator.serviceWorker.register('/__sw_test.js'); await navigator.serviceWorker.ready; }""")
    pre = pg.evaluate("async()=>({ls:localStorage.length,ss:sessionStorage.length,idb:(await indexedDB.databases()).length,cs:(await caches.keys()).length,sw:(await navigator.serviceWorker.getRegistrations()).length,ck:document.cookie.length>0})")
    check('pre-wipe: all six stores populated', pre['ls'] > 0 and pre['ss'] > 0 and pre['idb'] >= 1 and pre['cs'] >= 1 and pre['sw'] >= 1 and pre['ck'], pre)
    pg.click('#wipeDataBtn'); pg.wait_for_selector('#restartAfterWipe'); wr = pg.inner_text('#wipeReport')
    post = pg.evaluate("async()=>({ls:localStorage.length,ss:sessionStorage.length,idb:(await indexedDB.databases()).length,cs:(await caches.keys()).length,sw:(await navigator.serviceWorker.getRegistrations()).length,ck:document.cookie})")
    check('post-wipe: every store empty (verified in the browser)', post == {'ls': 0, 'ss': 0, 'idb': 0, 'cs': 0, 'sw': 0, 'ck': ''}, post)
    check('wipe report lists each store and the not-deletable items', all(k in wr for k in ['localStorage', 'sessionStorage', 'indexedDB', 'CacheStorage', 'serviceWorkers', 'cookies']) and 'Not deleted by this app' in wr and 'WebView' in wr and 'Open Food Facts' in wr, wr[:300])
    pg.click('#restartAfterWipe'); pg.wait_for_selector('#viewProfile:not([hidden])'); check('after wipe + restart: onboarding again, no age/consent remembered', ls(pg, 'ns.age.v1') is None and json.loads(ls(pg, 'ns.consent.v1') or '[]') == [])
    ctx.close()
    # ---- 4. legacy data migration in the real app
    legacy_adult = "if(!localStorage.getItem('nutrishield.profile')&&!localStorage.getItem('ns.schema')){localStorage.setItem('nutrishield.profile',JSON.stringify({name:'Ravi',age:34,mode:'pregnancy',allergies:['peanut'],conditions:['diabetes'],country:'IN'}));localStorage.setItem('ls.history',JSON.stringify([{key:'a',time:1}]));}"
    ctx, pg, errs = newpage(init=legacy_adult); pg.goto(BASE); pg.wait_for_selector('#viewProfile:not([hidden])')
    check('legacy adult: forced through new consent screen with explanatory notice', pg.is_visible('#noticeBar') and 'NOT used' in pg.inner_text('#noticeBar'))
    p = json.loads(ls(pg, 'nutrishield.profile')); sus = json.loads(ls(pg, 'ns.suspended.v1'))
    check('legacy adult: health data suspended (unused), mode reset, age field removed, prefilled for re-consent', p['allergies'] == [] and p['mode'] == 'adult' and 'age' not in p and sus['allergies'] == ['peanut'] and pg.input_value('#pAllergies') == 'peanut')
    check('legacy adult: adult radio pre-set from legacy field (user can change)', pg.evaluate("document.querySelector('input[name=pAgeStatus]:checked').value") == 'adult')
    check('legacy adult: health consent NOT pre-ticked', not pg.is_checked('#pHealthConsent'))
    ctx.close()
    legacy_child = legacy_adult.replace("age:34", "age:12").replace("mode:'pregnancy'", "mode:'adult'")
    ctx, pg, errs = newpage(init=legacy_child); pg.goto(BASE); pg.wait_for_selector('#viewProfile:not([hidden])')
    p = json.loads(ls(pg, 'nutrishield.profile')); check('legacy child: health, name and history deleted; kids mode; notice shown', p['allergies'] == [] and p['name'] == '' and p['mode'] == 'kids' and ls(pg, 'ls.history') is None and ls(pg, 'ns.suspended.v1') is None and 'deleted' in pg.inner_text('#noticeBar'))
    check('migration sessions: no JS errors', not errs, errs); ctx.close()
    b.close()
srv.shutdown()
fails = [r for r in res if not r[1]]
print(f"\nbrowser e2e: {len(res)-len(fails)}/{len(res)} passed")
json.dump(res, open(os.path.join(os.path.dirname(__file__), '..', '..', 'docs', 'test-results', 'e2e-results.json'), 'w'), indent=1)
sys.exit(1 if fails else 0)
