// India compliance regression tests (Node). Fails the build on any failure. No network.
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const W = f => path.join(__dirname, '..', 'www', f), C = f => require(W('compliance/' + f));
const Age = C('age.js'), Rules = C('rules.js'), Consent = C('consent.js'), Retention = C('retention.js'), Registry = C('registry.js'), Gate = C('gate.js'),
  Migrate = C('migrate.js'), Wipe = C('wipe.js'), Verifier = C('verifier.js'), Allergen = C('allergen.js'), Legal = C('legal.js'), Engine = require(W('engine.js'));
const results = []; let failed = 0;
function t(name, fn) { return Promise.resolve().then(fn).then(() => results.push([name, true]), e => { failed++; results.push([name, false, e && e.stack ? e.stack.split('\n').slice(0, 3).join(' | ') : String(e)]); }); }
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error((m || 'eq') + ': got ' + JSON.stringify(a) + ' want ' + JSON.stringify(b)); };
const ok = (c, m) => { if (!c) throw new Error(m || 'assertion failed'); };
const throwsCode = (fn, code) => { try { fn(); } catch (e) { if (e.code === code) return; throw new Error('wrong code ' + e.code); } throw new Error('did not throw ' + code); };
class MS { constructor() { this.m = new Map(); } get length() { return this.m.size; } key(i) { return Array.from(this.m.keys())[i] ?? null; } getItem(k) { return this.m.has(k) ? this.m.get(k) : null; } setItem(k, v) { this.m.set(k, String(v)); } removeItem(k) { this.m.delete(k); } clear() { this.m.clear(); } }
const NOW = Date.parse('2026-11-25T10:00:00Z'), DAY = 86400000;
const seedAll = st => { Registry.ENTRIES.forEach(e => st.setItem(e.match.key || e.match.prefix + '8901234567890', '{"x":1}')); };
const analyze = (text, al) => Engine.analyze(text, { allergies: al || [] });
const asses = (al, text, extra) => Allergen.assess(Object.assign({ allergies: al, ing: analyze(text, al), text, source: 'label_text', now: NOW }, extra || {}));
const FULL = 'Ingredients: Rice flour, sugar, salt, edible vegetable oil, spices.';

(async () => {
// ---------- Age ----------
await t('age: declare maps choices, never verified', () => {
  eq(Age.declare('adult', NOW).status, 'adult_self_declared'); eq(Age.declare('under18', NOW).status, 'under18');
  eq(Age.declare('unknown', NOW).status, 'unknown'); eq(Age.declare(undefined, NOW).status, 'unknown'); eq(Age.declare('18+ verified', NOW).status, 'unknown');
  ['adult', 'under18', 'unknown'].forEach(c => eq(Age.declare(c, NOW).verified, false));
  ok(!Object.keys(Age).some(k => /verif/i.test(k)), 'Age exposes a verification function');
});
await t('age: unknown/under18/missing are child-safe; only self-declared adult is not', () => {
  ok(Age.isChildSafe(null)); ok(Age.isChildSafe(Age.declare('unknown'))); ok(Age.isChildSafe(Age.declare('under18'))); ok(!Age.isChildSafe(Age.declare('adult')));
});
await t('age: stored record cannot be tampered into verified', () => {
  const st = new MS(); st.setItem(Age.KEY, JSON.stringify({ status: 'adult_self_declared', verified: true })); eq(Age.load(st).verified, false);
  st.setItem(Age.KEY, '{bad'); eq(Age.load(st), null); st.setItem(Age.KEY, JSON.stringify({ status: 'verified_adult' })); eq(Age.load(st), null);
});
await t('age: legacy integer conversion incl. boundaries and junk', () => {
  eq(Age.fromLegacyAge(17).status, 'under18'); eq(Age.fromLegacyAge(18).status, 'adult_self_declared'); eq(Age.fromLegacyAge('26').status, 'adult_self_declared');
  [0, 121, -3, 'abc', null, undefined, NaN].forEach(v => eq(Age.fromLegacyAge(v).status, 'unknown', String(v)));
});
await t('age: exact 18th birthday arithmetic (17y364d, 18y0d, 18y+, leap day, invalid)', () => {
  const n = Date.parse('2026-11-25T12:00:00Z');
  eq(Age.completedYears('2008-11-26', n), 17, '17y364d'); eq(Age.isAdultByDob('2008-11-26', n), false);
  eq(Age.completedYears('2008-11-25', n), 18, '18th birthday'); eq(Age.isAdultByDob('2008-11-25', n), true);
  eq(Age.completedYears('2008-11-24', n), 18); eq(Age.isAdultByDob('2000-01-01', n), true);
  eq(Age.isAdultByDob('2008-02-29', Date.parse('2026-02-28T00:00:00Z')), false, 'Feb29 born, day before 1 Mar');
  eq(Age.isAdultByDob('2008-02-29', Date.parse('2026-03-01T00:00:00Z')), true, 'Feb29 born on 1 Mar');
  eq(Age.isAdultByDob('2008-02-29', Date.parse('2028-02-29T00:00:00Z')), true, 'leap year exact day');
  ['', null, 'abc', '2008-13-01', '2009-02-29', '2030-01-01'].forEach(v => eq(Age.isAdultByDob(v, n), false, String(v)));
});
// ---------- Rules ----------
await t('rules: no universal consent-age constant; 18 child age; behaviour not date-gated; Gazette flag present', () => {
  const r = Rules.IN; eq(r.ages.dpdpChild.value, 18); eq(r.ages.digitalConsent.value, null); ok(!('minConsentAge' in r) && !('consentAge' in r));
  ok(r.regimes.every(g => /Gazette|UNVERIFIED/i.test(g.verification)), 'every regime flagged unverified');
  ok(r.regimes.some(g => g.id === 'IN-S.O.5458E' && /UNVERIFIED/.test(g.verification)));
  eq(r.controls.selfDeclaredAgeIsVerified, false); eq(r.controls.rule8_3, 'UNRESOLVED_COUNSEL_GATE'); eq(r.controls.parentVerification, 'NOT_CONFIGURED');
  const early = Rules.dpdpChildStatus(Date.parse('2020-01-01')); eq(early, Rules.dpdpChildStatus(Date.parse('2026-11-25')), 'rolled-back clock must not change status');
  ok(/UNVERIFIED/.test(early) || /UNVERIFIED/i.test(Rules.dpdpChildStatus(Date.parse('2028-01-01'))));
  eq(Rules.forCountry('US').researched, false); eq(Rules.forCountry('in').researched, true); eq(Rules.forCountry('US').strictestApplied, true);
});
// ---------- Consent ----------
const P = Consent.PURPOSES, ctxA = { ageStatus: 'adult_self_declared', noticeVersion: 'draft-0.1.0', docVersions: { privacy: 'draft-0.1.0' } };
await t('consent: grant records version, timestamp, tz, unverified age; append-only withdrawal', () => {
  const st = new MS(), l = Consent.createLedger(st, { clock: () => NOW, tz: () => 330 });
  const r = l.grant(P.HEALTH_PROFILE, ctxA); eq(r.noticeVersion, 'draft-0.1.0'); eq(r.ts, '2026-11-25T10:00:00.000Z'); eq(r.tzOffsetMinutes, 330); eq(r.ageVerified, false);
  ok(l.isActive(P.HEALTH_PROFILE)); ok(l.withdraw(P.HEALTH_PROFILE)); ok(!l.isActive(P.HEALTH_PROFILE)); ok(l.latest(P.HEALTH_PROFILE).withdrawnAt);
  l.grant(P.HEALTH_PROFILE, ctxA); eq(l.records().length, 2, 'withdrawn record kept as history'); ok(l.isActive(P.HEALTH_PROFILE));
  eq(l.withdraw(P.LOCAL_HISTORY), false);
});
await t('consent: adult-only purposes refused for under18/unknown/missing age; others need notice version', () => {
  const l = Consent.createLedger(new MS());
  for (const a of ['under18', 'unknown', undefined]) { throwsCode(() => l.grant(P.HEALTH_PROFILE, { ageStatus: a, noticeVersion: 'v' }), 'AGE_NOT_PERMITTED'); throwsCode(() => l.grant(P.LOCAL_HISTORY, { ageStatus: a, noticeVersion: 'v' }), 'AGE_NOT_PERMITTED'); }
  l.grant(P.TERMS_PRIVACY, { ageStatus: 'under18', noticeVersion: 'v' });
  throwsCode(() => l.grant(P.TERMS_PRIVACY, { ageStatus: 'adult_self_declared' }), 'NOTICE_VERSION_REQUIRED'); throwsCode(() => l.grant('marketing', ctxA), 'UNKNOWN_PURPOSE');
});
await t('consent: corrupt or hostile storage is tolerated', () => {
  const st = new MS(); st.setItem(Consent.KEY, '{{'); eq(Consent.createLedger(st).records(), []); st.setItem(Consent.KEY, '"x"'); eq(Consent.createLedger(st).records(), []);
  st.setItem(Consent.KEY, JSON.stringify([null, 5, { purpose: 'health_profile', granted: true, withdrawnAt: null }])); ok(Consent.createLedger(st).isActive(P.HEALTH_PROFILE));
  const full = { getItem: () => null, setItem() { throw new Error('quota'); } }; throwsCode(() => Consent.createLedger(full).grant(P.TERMS_PRIVACY, ctxA), 'STORAGE_FAILED');
});
// ---------- Retention ----------
await t('retention: shipped config valid; every period unset; no blanket period; Rule 8(3) not coded', () => {
  const cfg = Retention.config(); eq(Retention.validate(cfg), []); ok(cfg.categories.every(c => c.maxAgeDays === null));
  ok(!/oneYear|365|blanket/i.test(JSON.stringify(cfg)), 'no one-year figure'); const r83 = cfg.categories.find(c => c.id === 'rule8_3_seventh_schedule'); eq(r83.status, 'COUNSEL_PENDING');
  ['consent_records', 'parent_verification_evidence', 'rule8_3_seventh_schedule', 'security_logs_rule6_1_e', 'cert_in_ict_logs'].forEach(id => ok(cfg.categories.find(c => c.id === id).maxAgeDays === null, id));
});
await t('retention: validator rejects hard-coded unresolved or blanket periods', () => {
  let c = Retention.config(); c.categories.find(x => x.id === 'rule8_3_seventh_schedule').maxAgeDays = 365; ok(Retention.validate(c).length);
  c = Retention.config(); c.categories.find(x => x.id === 'consent_records').maxAgeDays = 30; ok(Retention.validate(c).length);
  c = Retention.config(); c.defaultPeriodDays = 365; ok(Retention.validate(c).some(e => /blanket/.test(e)));
  c = Retention.config(); c.categories.find(x => x.id === 'scan_history').maxAgeDays = 90; ok(Retention.validate(c).some(e => /PRODUCT_DECISION/.test(e)));
  c.categories.find(x => x.id === 'scan_history').source = 'PRODUCT_DECISION'; eq(Retention.validate(c), []);
  eq(Retention.expired(NOW - 91 * DAY, c.categories.find(x => x.id === 'scan_history'), NOW), true); eq(Retention.expired(NOW - 10 * DAY, c.categories.find(x => x.id === 'scan_history'), NOW), false);
  eq(Retention.expired(0, Retention.config().categories[0], NOW), false, 'null period never expires');
});
// ---------- Gate ----------
const ledgerWith = (st, ...ps) => { const l = Consent.createLedger(st); ps.forEach(p => l.grant(p, ctxA)); return l; };
await t('gate: permissions by age status and consent', () => {
  const st = new MS(), none = Consent.createLedger(st);
  const pc = Gate.permissions(null, none); eq([pc.adult, pc.healthActive, pc.historyActive, pc.collectName, pc.modes], [false, false, false, false, ['kids']]);
  eq(Gate.permissions(Age.declare('unknown'), none).modes, ['kids']); eq(Gate.permissions(Age.declare('under18'), none).canOfferHealth, false);
  const ad = Gate.permissions(Age.declare('adult'), none); eq([ad.adult, ad.healthActive, ad.modes], [true, false, ['adult', 'kids', 'older']]);
  const full = Gate.permissions(Age.declare('adult'), ledgerWith(new MS(), P.HEALTH_PROFILE, P.LOCAL_HISTORY)); eq([full.healthActive, full.historyActive, full.modes.includes('pregnancy')], [true, true, true]);
  // consent records alone cannot unlock a child, even if one was somehow written into the ledger
  const st2 = new MS(); st2.setItem(Consent.KEY, JSON.stringify([{ purpose: 'health_profile', granted: true, withdrawnAt: null }])); eq(Gate.permissions(Age.declare('under18'), Consent.createLedger(st2)).healthActive, false);
  eq(Gate.permissions(Age.declare('unknown'), Consent.createLedger(st2)).healthActive, false);
});
await t('gate: sanitizeProfile strips health fields, child name, pregnancy mode, legacy age', () => {
  const prof = { name: 'Asha', age: 12, mode: 'pregnancy', allergies: ['peanut'], conditions: ['diabetes'], country: 'IN' };
  const child = Gate.sanitizeProfile(prof, Gate.permissions(Age.declare('under18'), Consent.createLedger(new MS())));
  eq(child.profile, { name: '', mode: 'kids', allergies: [], conditions: [] }); ok(child.changed);
  // Email, mobile and country are not collected: values saved by an earlier build are purged for every age status.
  const legacy = { name: 'Asha', email: 'a@b.in', mobile: '+919876543210', country: 'IN', countrySource: 'user', mode: 'adult', allergies: [], conditions: [] };
  for (const a of ['adult', 'under18', 'unknown']) { const r = Gate.sanitizeProfile(legacy, Gate.permissions(Age.declare(a), Consent.createLedger(new MS()))); eq([r.profile.email, r.profile.mobile, r.profile.country, r.profile.countrySource], [undefined, undefined, undefined, undefined], 'purged for ' + a); ok(r.changed); }
  eq(Gate.sanitizeProfile(legacy, Gate.permissions(Age.declare('adult'), Consent.createLedger(new MS()))).profile.name, 'Asha');
  const adultNoConsent = Gate.sanitizeProfile(prof, Gate.permissions(Age.declare('adult'), Consent.createLedger(new MS()))); eq([adultNoConsent.profile.mode, adultNoConsent.profile.allergies, adultNoConsent.profile.name], ['adult', [], 'Asha']);
  const okp = Gate.sanitizeProfile(prof, Gate.permissions(Age.declare('adult'), ledgerWith(new MS(), P.HEALTH_PROFILE))); eq([okp.profile.mode, okp.profile.allergies, okp.profile.conditions], ['pregnancy', ['peanut'], ['diabetes']]);
  eq(Gate.sanitizeProfile(null, {}).profile, null);
});
await t('gate: withdrawal cascades (health fields + suspended; history/fav/labels/cache)', () => {
  const st = new MS(); seedAll(st); const l = ledgerWith(st, P.HEALTH_PROFILE, P.LOCAL_HISTORY);
  st.setItem('nutrishield.profile', JSON.stringify({ name: 'A', mode: 'pregnancy', allergies: ['milk'], conditions: ['bp'] }));
  const r = Gate.withdraw({ storage: st, ledger: l }, P.HEALTH_PROFILE); ok(r.withdrawn); const pr = JSON.parse(st.getItem('nutrishield.profile'));
  eq([pr.allergies, pr.conditions, pr.mode], [[], [], 'adult']); eq(st.getItem('ns.suspended.v1'), null); ok(l.latest(P.HEALTH_PROFILE).withdrawnAt);
  Gate.withdraw({ storage: st, ledger: l }, P.LOCAL_HISTORY);
  ['ls.history', 'ls.fav', 'ns_lbl_8901234567890', 'nutrishield.cache'].forEach(k => eq(st.getItem(k), null, k)); ok(st.getItem('ls.feedback') !== null, 'feedback untouched'); ok(st.getItem('ns.consent.v1') !== null, 'ledger kept on withdrawal');
});
// ---------- Migration ----------
await t('migrate: legacy adult with health data -> suspended, profile stripped, notices, age record self-declared', () => {
  const st = new MS(); st.setItem('nutrishield.profile', JSON.stringify({ name: 'Ravi', age: 34, mode: 'pregnancy', allergies: ['peanut'], conditions: ['diabetes'], country: 'IN' })); st.setItem('ls.history', '[{"key":"a"}]');
  const r = Migrate.run(st, NOW); ok(r.ran); const p = JSON.parse(st.getItem('nutrishield.profile'));
  eq([p.age, p.allergies, p.conditions, p.mode, p.name], [undefined, [], [], 'adult', 'Ravi']); eq(JSON.parse(st.getItem('ns.suspended.v1')), { allergies: ['peanut'], conditions: ['diabetes'], mode: 'pregnancy' });
  eq(Age.load(st).status, 'adult_self_declared'); eq(Age.load(st).source, 'legacy_age_field'); ok(r.notices.includes('health_reconsent') && r.notices.includes('history_reconsent'));
  eq(st.getItem('ls.history'), '[{"key":"a"}]', 'adult history kept');
  eq(Gate.permissions(Age.load(st), Consent.createLedger(st)).healthActive, false, 'no consent => health unused');
});
await t('migrate: legacy child / junk age -> health, name, history, cache deleted; kids mode', () => {
  for (const age of [12, 17, 'x', 0]) {
    const st = new MS(); seedAll(st); st.setItem('nutrishield.profile', JSON.stringify({ name: 'Kid', age, mode: 'adult', allergies: ['egg'], conditions: [] }));
    const r = Migrate.run(st, NOW); const p = JSON.parse(st.getItem('nutrishield.profile'));
    eq([p.name, p.mode, p.allergies, p.age], ['', 'kids', [], undefined], 'age ' + age); eq(st.getItem('ns.suspended.v1'), null);
    ['ls.history', 'ls.fav', 'nutrishield.cache', 'ns_lbl_8901234567890'].forEach(k => eq(st.getItem(k), null, k)); ok(r.notices.includes('child_health_removed'), 'age ' + age);
    ok(['under18', 'unknown'].includes(Age.load(st).status));
  }
});
await t('migrate: idempotent, fresh install, corrupt profile, notices dismissible', () => {
  const st = new MS(); st.setItem('nutrishield.profile', JSON.stringify({ name: 'R', age: 40, mode: 'adult', allergies: ['soy'] })); Migrate.run(st, NOW);
  const again = Migrate.run(st, NOW + DAY); eq(again.ran, false); eq(JSON.parse(st.getItem('ns.suspended.v1')).allergies, ['soy']);
  Migrate.dismissNotices(st); eq(JSON.parse(st.getItem('ns.schema')).notices, []);
  const fresh = new MS(); eq(Migrate.run(fresh, NOW).ran, true); eq(fresh.getItem('nutrishield.profile'), null); eq(Age.load(fresh), null);
  const bad = new MS(); bad.setItem('nutrishield.profile', '[1,2]'); Migrate.run(bad, NOW); const bad2 = new MS(); bad2.setItem('nutrishield.profile', '{oops'); Migrate.run(bad2, NOW);
});
// ---------- Registry / deletion ----------
await t('registry: every storage key literal used by the app source is registered', () => {
  const files = fs.readdirSync(W('.')).filter(f => /\.(js|html)$/.test(f)).map(f => W(f)).concat(fs.readdirSync(W('compliance')).map(f => W('compliance/' + f)));
  const keys = new Set(); for (const f of files) for (const m of fs.readFileSync(f, 'utf8').matchAll(/['"`]((?:nutrishield|ls|ns)[._][A-Za-z0-9._]+|ns_lbl_)['"`]/g)) keys.add(m[1]);
  const missing = Array.from(keys).filter(k => !Registry.find(k) && !Registry.find(k + 'x')); eq(missing, [], 'unregistered storage keys');
  ok(keys.size >= 10, 'found ' + keys.size);
  for (const f of files) { const s = fs.readFileSync(f, 'utf8'); if (/vendor/.test(f)) continue; ok(!/indexedDB\.open|caches\.open|navigator\.serviceWorker\.register|sessionStorage\.setItem/.test(s.replace(/wipe\.js/, '')) || /wipe\.js$/.test(f), 'unlisted storage API in ' + f); }
});
await t('registry: deleteCategories removes only the named categories; unregistered() detects strays', () => {
  const st = new MS(); seedAll(st); st.setItem('stray.key', '1'); eq(Registry.unregistered(st), ['stray.key']);
  eq(Registry.deleteCategories(st, ['feedback']).sort(), ['ls.feedback']); ok(st.getItem('ls.history') !== null);
  Registry.deleteCategories(st, ['scan_history', 'favourites', 'saved_labels', 'barcode_cache']); ok(Registry.listKeys(st).every(k => !/ls\.history|ls\.fav|ns_lbl_|nutrishield\.cache/.test(k)));
});
const mkEnv = (over) => {
  const idb = { dbs: ['tesseract-core', 'keyval-store'], async databases() { return this.dbs.map(name => ({ name })); }, deleteDatabase(n) { const r = {}; setTimeout(() => { this.dbs = this.dbs.filter(x => x !== n); r.onsuccess && r.onsuccess(); }, 0); return r; } };
  const cacheMap = new Map([['workbox-1', 1], ['api', 1]]);
  let regs = [{ unregister: async () => { regs = regs.filter((_, i) => i); } }, { unregister: async () => { regs = []; } }]; regs = [{ u: 1 }, { u: 2 }].map(o => ({ unregister: async function () { regs = regs.filter(r => r !== this); } }));
  const doc = { _c: 'a=1; b=2', get cookie() { return this._c; }, set cookie(v) { const n = v.split('=')[0]; this._c = this._c.split(';').map(s => s.trim()).filter(s => s && s.split('=')[0] !== n).join('; '); } };
  const env = { localStorage: new MS(), sessionStorage: new MS(), indexedDB: idb, caches: { keys: async () => Array.from(cacheMap.keys()), delete: async k => cacheMap.delete(k) }, navigator: { serviceWorker: { getRegistrations: async () => regs.slice() } }, document: doc };
  return Object.assign(env, over || {});
};
await t('wipe: clears localStorage, sessionStorage, IndexedDB, CacheStorage, service workers, cookies; verifies and reports', async () => {
  const env = mkEnv(); seedAll(env.localStorage); env.sessionStorage.setItem('tmp', '1');
  const r = await Wipe.deleteAll(env); ok(r.ok, JSON.stringify(r.report)); eq(env.localStorage.length, 0); eq(env.sessionStorage.length, 0); eq((await env.indexedDB.databases()).length, 0); eq((await env.caches.keys()).length, 0); eq((await env.navigator.serviceWorker.getRegistrations()).length, 0); eq(env.document.cookie, '');
  const by = Object.fromEntries(r.report.map(x => [x.store, x.status])); eq(by, { localStorage: 'cleared', sessionStorage: 'cleared', indexedDB: 'cleared', CacheStorage: 'cleared', serviceWorkers: 'cleared', cookies: 'cleared' });
  ok(r.notDeletable.length >= 5 && r.notDeletable.some(n => /WebView/.test(n.text)) && r.notDeletable.some(n => /Open Food Facts/.test(n.text)));
});
await t('wipe: reports partial/blocked, unsupported and errors instead of claiming success', async () => {
  const env = mkEnv(); env.indexedDB.deleteDatabase = () => { const r = {}; setTimeout(() => r.onblocked && r.onblocked(), 0); return r; };
  let r = await Wipe.deleteAll(env); eq(r.ok, false); eq(r.report.find(x => x.store === 'indexedDB').status, 'partial');
  r = await Wipe.deleteAll({ localStorage: new MS() }); ok(r.report.filter(x => x.status === 'unsupported').length >= 4); eq(r.report.find(x => x.store === 'localStorage').status, 'empty');
  const e2 = mkEnv(); e2.caches.keys = async () => { throw new Error('boom'); }; r = await Wipe.deleteAll(e2); eq(r.ok, false); eq(r.report.find(x => x.store === 'CacheStorage').status, 'error'); eq(e2.localStorage.length, 0, 'other stores still cleared');
  const e3 = mkEnv(); e3.indexedDB.databases = undefined; r = await Wipe.deleteAll(e3); ok(/known names/.test(r.report.find(x => x.store === 'indexedDB').detail));
  const e4 = mkEnv(); e4.localStorage.clear = () => {}; e4.localStorage.setItem('k', 'v'); r = await Wipe.deleteAll(e4); eq(r.report.find(x => x.store === 'localStorage').status, 'partial'); eq(r.ok, false);
});
// ---------- Verifier ----------
await t('verifier: not operational, cannot verify, install needs approval, never unlocks child health', async () => {
  Verifier._resetForTests(); const s = Verifier.status(); eq([s.configured, s.operational, s.code], [false, false, 'NOT_CONFIGURED']); ok(/not available/i.test(s.label));
  const v = await Verifier.verify(); eq([v.ok, v.verified], [false, false]);
  throwsCode(() => Verifier.install({}, { counselApprovalRef: 'x', methodId: 'y' }), 'BAD_PROVIDER');
  const prov = { startVerification() {}, checkResult() {}, withdraw() {} }; throwsCode(() => Verifier.install(prov, {}), 'APPROVAL_REQUIRED'); throwsCode(() => Verifier.install(prov), 'APPROVAL_REQUIRED');
  Verifier.install(prov, { counselApprovalRef: 'TEST', methodId: 'TEST' }); eq(Verifier.status().operational, false); eq((await Verifier.verify()).ok, false);
  eq(Gate.permissions(Age.declare('under18'), ledgerWith(new MS(), P.TERMS_PRIVACY)).canOfferHealth, false, 'child health stays blocked with provider installed'); Verifier._resetForTests();
  ok(!/operational|verified|compliant/i.test(Verifier.status().label.replace(/not available/i, '')), 'label must not claim verification');
});
// ---------- Allergen ----------
const S = Allergen.STATES;
await t('allergen: no allergies set -> NONE, no panel', () => { const r = asses([], FULL); eq(r.state, S.NONE); eq(r.items, []); });
await t('allergen: contains / may contain detected', () => {
  let r = asses(['milk'], 'Ingredients: Wheat flour, milk solids, sugar, salt, palm oil, spices.'); eq(r.state, S.MATCH); ok(r.items[0].tone === 'red' && /ALLERGY WARNING/.test(r.items[0].title)); ok(!r.reassuring);
  r = asses(['peanut'], 'Ingredients: Wheat flour, sugar, salt, palm oil, spices. May contain traces of peanuts.'); eq(r.state, S.MAY);
});
await t('allergen: best case is NO_MATCH_IN_AVAILABLE_INFO, qualified, never "clear"/"safe"', () => {
  const r = asses(['peanut'], FULL); eq(r.state, S.NO_MATCH); ok(r.reassuring); const txt = r.items.map(i => i.title + ' ' + i.body).join(' ');
  ok(/does NOT mean/.test(txt) && /printed pack/.test(txt) && /Source:/.test(txt)); ok(!/allergy check clear|safe choice|\bsafe\b|allergen-free|\bclear\b/i.test(txt), txt);
});
await t('allergen: unreadable OCR / unrecognised text / rescued -> never reassuring', () => {
  let r = asses(['peanut'], 'xq zz'); eq(r.state, S.OCR_UNCERTAIN); ok(!r.reassuring);
  const ing = { coverage: 1, rescued: true, warnings: [] }; r = Allergen.assess({ allergies: ['peanut'], ing, text: FULL, source: 'label_text', now: NOW }); eq(r.state, S.OCR_UNCERTAIN);
  const partial = 'Ingredients: Rice flour, sugar, salt, palm oil, xqzv, plmq, spices.'; const g = analyze(partial, ['peanut']); ok(g.coverage >= 0.6 && g.coverage < 0.8, 'fixture coverage ' + g.coverage);
  r = asses(['peanut'], partial); eq(r.state, S.INCOMPLETE); ok(!r.reassuring);
});
await t('allergen: missing text / empty product record -> NOT_POSSIBLE / INCOMPLETE', () => {
  let r = Allergen.assess({ allergies: ['peanut'], ing: null, text: '', source: 'label_text', now: NOW }); eq(r.state, S.NOT_POSSIBLE);
  r = Allergen.assess({ allergies: ['peanut'], ing: null, product: { name: 'X', ingredients: '', allergens: [], traces: [] }, source: 'off', now: NOW }); eq(r.state, S.INCOMPLETE); ok(!r.reassuring);
});
await t('allergen: OFF data date: old/cached-old -> OUTDATED; unknown date still caveated; fresh ok', () => {
  const mk = (extra, src) => asses(['peanut'], FULL, { product: Object.assign({ name: 'P', ingredients: FULL, allergens: [], traces: [] }, extra), source: src || 'off' });
  let r = mk({ lastModified: (NOW - 3 * 365 * DAY) / 1000 }); eq(r.state, S.OUTDATED); ok(!r.reassuring);
  r = mk({ cachedAt: NOW - 800 * DAY }, 'cache'); eq(r.state, S.OUTDATED);
  r = mk({}); eq(r.state, S.NO_MATCH); ok(/update date unknown/.test(r.items[0].body));
  r = mk({ lastModified: (NOW - 30 * DAY) / 1000 }); eq(r.state, S.NO_MATCH); ok(/last updated 20/.test(r.items[0].body)); ok(/Open Food Facts/.test(r.items[0].body));
  r = asses(['peanut'], FULL, { product: { name: 'P', ingredients: FULL, allergens: [], traces: [] }, source: 'bundled' }); ok(/not confirmed against the pack/.test(r.items[0].body));
});
await t('allergen: declared allergen tags matched even if ingredient text silent', () => {
  const r = asses(['milk'], FULL, { product: { name: 'P', ingredients: FULL, allergens: ['en:milk'.replace(/^en:/, '')], traces: [] }, source: 'off' }); eq(r.state, S.MATCH);
  const r2 = asses(['peanut'], FULL, { product: { name: 'P', ingredients: FULL, allergens: [], traces: ['peanuts'] }, source: 'off' }); eq(r2.state, S.MAY);
});
await t('allergen: terms shorter than 3 characters are handled, never silently dropped', () => {
  const n = Allergen.normalise(['a', 'ow', 'Peanut', ' peanut ', '', 'आलू', '12']); eq(n.checkable, [{ term: 'ow', mode: 'word' }, { term: 'peanut', mode: 'engine' }]);
  eq(n.unchecked.map(u => u.term + ':' + u.reason), ['a:too_short', 'आलू:non_latin', '12:too_short']);
  let r = asses(['ow'], 'Ingredients: rice, brown sugar, salt, palm oil, spices, flour.'); eq(r.matches, [], 'brown must not match ow'); eq(r.state, S.NO_MATCH);
  r = asses(['ow'], 'Ingredients: rice, ow flour, salt, palm oil, spices, sugar.'); eq(r.state, S.MATCH);
  r = asses(['ow'], 'Ingredients: rice, sugar, salt, palm oil, spices. May contain ow.'); eq(r.state, S.MAY);
  r = asses(['a'], FULL); eq(r.state, S.NOT_POSSIBLE); ok(!r.reassuring); ok(r.items.some(i => /cannot be checked/.test(i.title)));
  r = asses(['peanut', 'a'], FULL); eq(r.state, S.NOT_POSSIBLE); ok(!r.reassuring, 'one unchecked term blocks reassurance'); ok(r.items.length === 2);
  r = asses(['आलू'], FULL); eq(r.state, S.NOT_POSSIBLE);
});
await t('allergen: one allergy matched + another not -> warning plus qualified status for the other', () => {
  const r = asses(['milk', 'sesame'], 'Ingredients: Wheat flour, milk solids, sugar, salt, palm oil, spices.'); eq(r.state, S.MATCH); ok(r.items.length === 2 && /sesame/.test(r.items[1].body) && !/milk/.test(r.items[1].body.split('Source')[0]));
});
await t('allergen: custom allergen outside dictionary is matched literally', () => { eq(asses(['mango'], 'Ingredients: rice, sugar, mango pulp, salt, palm oil, spices.').state, S.MATCH); });
// ---------- UI wording / markup / scoring unchanged ----------
const html = fs.readFileSync(W('index.html'), 'utf8');
await t('ui: misleading absolute wording removed from app source', () => {
  for (const bad of ['Allergy Check Clear', 'Good / Safe Choice', 'Safe Choice', 'Avoid / High Risk', 'Under 13', '(60+']) ok(!html.includes(bad), 'still contains: ' + bad);
  ok(!/alert-green">✅ <b>Allergy/.test(html));
});
await t('ui: score wording matches the actual score bands exactly (75/50/25)', () => {
  const m = html.match(/const vWord = ([^\n]+)/)[1]; ok(m.includes('score >= 75') && m.includes('(75–100)') && m.includes('score >= 50') && m.includes('(50–74)') && m.includes('score >= 25') && m.includes('(25–49)') && m.includes('(0–24)'));
  ok(/const vClass = score >= 70 \? 'v-good' : score >= 45 \? 'v-mod' : 'v-bad'/.test(html), 'colour thresholds untouched');
});
await t('ui: onboarding markup — no pre-selected age, nothing pre-ticked, legal links, new storage-gated controls', () => {
  ok(!/<input[^>]*name="pAgeStatus"[^>]*checked/.test(html)); for (const id of ['pConsent', 'pHealthConsent', 'pHistoryConsent']) ok(!new RegExp('id="' + id + '"[^>]*checked').test(html), id);
  ok(/data-legal="privacy"/.test(html) && /data-legal="terms"/.test(html) && /id="legalOverlay"/.test(html) && /id="privacyCard"/.test(html));
  ok(!/id="(p|s)(Email|Mobile|Country)"|id="topCountry"|data-country-select|pContactWrap|sContactWrap/.test(html), 'email, mobile and country controls are removed');
  ok(!/Zero AI|No AI/i.test(html), 'no "Zero AI" / "No AI" wording on any page');
  ok(!/id="pAge"/.test(html), 'free-text age field removed');
});
await t('ui: CSP no longer allows Open Food Facts images; connect-src only OFF', () => {
  const csp = html.match(/Content-Security-Policy" content="([^"]+)"/)[1]; ok(/img-src 'self' data: blob:;/.test(csp)); ok(!/img-src[^;]*openfoodfacts/.test(csp)); ok(/connect-src 'self' data: blob: https:\/\/world\.openfoodfacts\.org$/.test(csp));
});
await t('ui: history/favourites/labels/cache writes are consent-gated in source', () => {
  ok(/if \(historyOK\(\)\) Store\.addHistory\(snap\)/.test(html)); ok(/function labelSet\(c, t\) \{ if \(!historyOK\(\)\) return;/.test(html)); ok(/function cacheSet\(p\) \{\n\s+if \(!historyOK\(\)\) return;/.test(html)); ok(/if \(!historyOK\(\)\) \{ setStatus\('Favourites/.test(html));
  ok(/window\.Wipe\.deleteAll\(window\)/.test(html) && !/localStorage\.clear\(\)/.test(html), 'wipe uses Wipe module');
});
await t('scoring: engine/nutrition/advice/ingredients files byte-identical to the supplied baseline', () => {
  const H = { 'engine.js': 'ef93cbc4808798064278cf20929bb033568cecaedba20a2572bf287e2955081c', 'nutrition.js': '62f5d5b5c269f3593f2c119dfeb0b011290a432db79f97d70c78636fc65b944f', 'advice.js': 'ed666c16917b9e3f721797f1d644fe9f9bc0bef8c6580b2d792aba80479df76d', 'ingredients.js': 'e8dddc46a50beecf081a39627156364829ed7aeee6da3ec0d9d9370575f73468' };
  for (const [f, h] of Object.entries(H)) eq(crypto.createHash('sha256').update(fs.readFileSync(W(f))).digest('hex'), h, f);
});
await t('lookup: OFF request adds only last_modified_t (a response field); data date parsed; no profile data in request', async () => {
  const vm = require('vm'), ctx = { window: {}, fetch: () => { throw new Error('no network in tests'); }, AbortController, setTimeout, clearTimeout, console, Promise }; vm.createContext(ctx);
  // lookup-web.js is a browser script: load it in a sandbox. It needs isValidGtin from barcode.js
  vm.runInContext(fs.readFileSync(W('barcode.js'), 'utf8'), ctx); vm.runInContext(fs.readFileSync(W('lookup-web.js'), 'utf8'), ctx); const L = ctx.window.__lookup; let url = '';
  const body = { status: 1, code: '8901058852004', product: { product_name: 'T', ingredients_text: 'rice', allergens_tags: [], traces_tags: [], nutriments: {}, last_modified_t: 1700000000 } };
  const r = await L.fetchProduct('8901058852004', async u => { url = u; return { ok: true, status: 200, json: async () => body }; });
  ok(r.ok && r.product.lastModified === 1700000000, JSON.stringify(r)); ok(/last_modified_t/.test(url) && !/allerg|profile|age|name=/.test(url.replace(/allergens_tags/, ''))); ok(/^https:\/\/world\.openfoodfacts\.org\/api\/v2\/product\/\d+\.json\?fields=/.test(url));
  const r2 = await L.fetchProduct('8901058852004', async () => ({ ok: true, status: 200, json: async () => ({ status: 1, code: '8901058852004', product: { product_name: 'T', last_modified_t: 'junk' } }) })); eq(r2.product.lastModified, null);
});
// ---------- Legal docs ----------
await t('legal: drafts carry REQUIRED INPUT placeholders, never production-ready, no invented identity', () => {
  ok(Legal.placeholderCount() >= 10 && Legal.placeholders().length >= 8); eq(Legal.isProductionReady(), false); eq(Legal.STATUS.approved, false); eq(Legal.STATUS.reviewer, null);
  const all = Object.values(Legal.docs).map(d => Legal.toMarkdown(d)).join('\n'); ok(!/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[a-z]{2,}/.test(all), 'email address invented'); ok(!/\+?\d[\d\s-]{8,}/.test(all), 'phone-like number invented');
  ok(!/Pvt|Ltd|LLP|Inc\.|Private Limited/.test(all), 'company form invented'); ok(!/\[your |\[Your |TODO/.test(all));
  for (const k of ['Publisher', 'Address', 'Grievance', 'Governing law', 'retention periods']) ok(new RegExp(k + '[^\\n]*\\[REQUIRED INPUT', 'i').test(all), k);
  ok(/DRAFT/.test(all) && /Not approved for production/.test(all));
});
await t('legal: privacy draft discloses category search to Open Food Facts and ML Kit uncertainty; states health/child limits', () => {
  const p = Legal.toMarkdown(Legal.docs.privacy); ok(/product category name to Open Food Facts/.test(p)); ok(/Google ML Kit[^\n]*REQUIRED INPUT/.test(p)); ok(/cannot verify/i.test(p)); ok(/Parental authorisation is not available/.test(p));
  ok(!/guarantee(s|d)? (that )?(the )?product is safe|is safe for you\./i.test(Legal.toMarkdown(Legal.docs.terms).replace(/never a guarantee that a product is safe for you/, '')));
});
await t('legal: HTML rendering escapes and highlights placeholders', () => {
  const h = Legal.toHtml(Legal.docs.privacy, s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))); ok(/<mark class="req">\[REQUIRED INPUT:/.test(h)); ok(!/<script/i.test(h));
});
await t('docs: docs/PRIVACY_POLICY.md and TERMS.md are generated from legal.js (in sync)', () => {
  for (const [f, id] of [['PRIVACY_POLICY.md', 'privacy'], ['TERMS.md', 'terms']]) eq(fs.readFileSync(path.join(__dirname, '..', 'docs', f), 'utf8'), Legal.toMarkdown(Legal.docs[id]), f + ' out of sync: run node scripts/build-legal-docs.js');
});
await t('versions: Terms and Privacy are versioned separately; re-acceptance is per document; records and history preserved', () => {
  const V = Legal.VERSIONS; ok(V.privacy && V.terms && V.privacy !== V.terms, 'two independent version numbers'); ok(!('VERSION' in Legal), 'no single shared version');
  eq(Legal.docs.privacy.version, V.privacy); eq(Legal.docs.terms.version, V.terms);
  eq(V.terms, 'draft-0.1.0', 'Terms unchanged, so Terms are not re-asked'); eq(V.privacy, 'draft-0.2.0', 'Privacy bumped for its material change');
  for (const id of ['privacy', 'terms']) ok(Legal.HISTORY[id][0].version === 'draft-0.1.0' && Legal.HISTORY[id].some(h => h.version === V[id]), id + ' history keeps v0.1.0 and lists the current version');
  const md = Legal.toMarkdown(Legal.docs.privacy); ok(/## Version history/.test(md) && /draft-0\.1\.0: First draft/.test(md) && /# NutriShield Privacy Policy \(draft-0\.2\.0\)/.test(md)); ok(/# NutriShield Terms of Use \(draft-0\.1\.0\)/.test(Legal.toMarkdown(Legal.docs.terms)));
  const cx = v => ({ ageStatus: 'adult_self_declared', noticeVersion: 'x', docVersions: v }), cur = { privacy: 'p2', terms: 't1' };
  const l = Consent.createLedger(new MS());
  eq(l.acceptance(P.TERMS_PRIVACY, cur).stale, ['privacy', 'terms'], 'never accepted: both needed'); ok(!l.acceptance(P.TERMS_PRIVACY, cur).everAccepted);
  l.grant(P.TERMS_PRIVACY, cx({ privacy: 'p1', terms: 't1' }));
  let s = l.acceptance(P.TERMS_PRIVACY, cur); eq(s.stale, ['privacy'], 'only the changed document is stale'); ok(!s.current && s.everAccepted);
  eq(l.acceptance(P.TERMS_PRIVACY, { privacy: 'p1', terms: 't1' }).stale, [], 'unchanged documents are not asked again');
  eq(l.acceptance(P.TERMS_PRIVACY, { privacy: 'p1', terms: 't2' }).stale, ['terms'], 'a Terms-only change asks for Terms only');
  l.grant(P.TERMS_PRIVACY, cx(cur)); s = l.acceptance(P.TERMS_PRIVACY, cur); ok(s.current); eq(s.stale, []);
  eq(l.records().length, 2, 'earlier record kept'); eq(l.records()[0].docVersions, { privacy: 'p1', terms: 't1' }, 'earlier record not rewritten');
  const old = Consent.createLedger(new MS()); old.grant(P.TERMS_PRIVACY, { ageStatus: 'under18', noticeVersion: 'draft-0.1.0' });
  eq(old.acceptance(P.TERMS_PRIVACY, cur).stale, ['privacy', 'terms'], 'record without docVersions accepts nothing');
  const w = Consent.createLedger(new MS()); w.grant(P.TERMS_PRIVACY, cx(cur)); w.withdraw(P.TERMS_PRIVACY); eq(w.acceptance(P.TERMS_PRIVACY, cur).stale, ['privacy', 'terms'], 'withdrawn acceptance is not current');
});
await t('privacy text: no email/mobile/country collection; plaintext storage disclosed; no encryption claim', () => {
  const p = Legal.toMarkdown(Legal.docs.privacy);
  ok(/does not ask for or store your email address, mobile number or country/.test(p));
  ok(/does not add its own encryption/.test(p) && /Security of data on your device/.test(p));
  ok(!/encrypted (at rest|on your device)|we encrypt|AES|end-to-end/i.test(p), 'must not claim encryption');
  ok(!/optional nickname, email/i.test(p) && !/your selected mode, and country/i.test(p));
  eq(Legal.placeholderCount(), 17, 'no new placeholders introduced');
});
// ---------- report ----------
const out = results.map(([n, p, e]) => (p ? 'PASS ' : 'FAIL ') + n + (e ? '\n      ' + e : '')).join('\n');
console.log(out); console.log('\ncompliance tests: ' + (results.length - failed) + '/' + results.length + ' passed');
if (process.argv.includes('--json')) fs.writeFileSync(path.join(__dirname, '..', 'docs', 'test-results', 'compliance-test-results.json'), JSON.stringify(results, null, 1));
if (failed) process.exit(1);
})();
