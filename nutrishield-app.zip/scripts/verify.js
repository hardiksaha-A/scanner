// Pre-build sanity check: fails the build early (with a clear message) if anything the app needs is missing.
const fs = require('fs'), path = require('path'), errs = [];
const must = f => { if (!fs.existsSync(f)) errs.push('missing ' + f); return fs.existsSync(f); };
must('www/ocr-worker.js');
if (must('www/logo.png')) { const b = fs.readFileSync('www/logo.png'); if (b.length < 5000 || b.readUInt32BE(0) !== 0x89504e47) errs.push('www/logo.png is not a valid PNG'); }
for (const d of ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']) for (const n of ['ic_launcher', 'ic_launcher_round', 'ic_launcher_foreground']) must(`android-icons/mipmap-${d}/${n}.png`);
if (!fs.existsSync('android-icons/splash') || !fs.readdirSync('android-icons/splash').length) errs.push('missing android-icons/splash');
const html = fs.readFileSync('www/index.html', 'utf8');
for (const m of html.matchAll(/<script src="([^"]+)"/g)) must('www/' + m[1]);
for (const id of ['splash', 'fileIn', 'camIn', 'labelText', 'scanStatus', 'rawBox', 'rawText', 'useRawBtn']) if (!html.includes('id="' + id + '"')) errs.push('index.html lacks #' + id);
if (!/@keyframes nsPop/.test(html)) errs.push('index.html lacks the splash animation');
if (!/appName":\s*"NutriShield"/.test(fs.readFileSync('capacitor.config.json', 'utf8'))) errs.push('capacitor.config.json appName is not NutriShield');
if (errs.length) { console.error('VERIFY FAILED:\n - ' + errs.join('\n - ')); process.exit(1); }
const lb = require('./build-localdb.js').build(); if (lb.errs.length) { console.error('LOCALDB FAILED:\n' + lb.errs.join('\n')); process.exit(1); }
require('./selftest.js');
require('./modes-test.js');
const acc = require('./accuracy.js'); if (acc.pass < acc.total) { console.error('ACCURACY FAILED: ' + acc.pass + '/' + acc.total); process.exit(1); }
require('child_process').execFileSync(process.execPath, [require('path').join(__dirname, 'e2e.js')], { stdio: 'inherit', cwd: require('path').join(__dirname, '..') }); // real photos: barcode, camera and upload must agree
console.log('verify ok');
