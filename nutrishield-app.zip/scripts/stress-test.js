// Stress and fuzz test: hostile or huge input must never crash, hang or produce out-of-range numbers.
// Run: node scripts/stress-test.js        (about 10-30 seconds)
const E = require('../www/engine.js'), N = require('../www/nutrition.js'), A = require('../www/advice.js'), C = require('../www/crop.js');
const rows = require('../www/ingredients.js'), L = require('./labels.json');
const fails = [], ms = f => { const t = process.hrtime.bigint(); let r, err; try { r = f(); } catch (e) { err = e; } return { r, err, ms: Number(process.hrtime.bigint() - t) / 1e6 }; };
const must = (name, f, maxMs) => { if (process.env.V) require('fs').writeSync(2, name + '\n'); const x = ms(f); if (x.err) fails.push(name + ' THREW ' + String(x.err.message).slice(0, 80)); else if (x.ms > maxMs) fails.push(name + ' SLOW ' + Math.round(x.ms) + 'ms (limit ' + maxMs + ')'); return x; };
const rnd = (n, set) => Array.from({ length: n }, () => set[Math.floor(Math.random() * set.length)]).join('');
const names = rows.map(r => r.split('|')[0]);

// 1. Hostile and odd inputs: no exceptions, finite numbers
const odd = [null, undefined, '', ' ', 0, 12345, {}, [], true, '\u0000\u0001\u0002', '😀'.repeat(500), '\u202e'.repeat(300) + 'sugar', '<script>alert(1)</script>', '"><img src=x onerror=alert(1)>', "'; DROP TABLE x;--", '${7*7}', '{{constructor.constructor("alert(1)")()}}', '__proto__', 'constructor', '0'.repeat(5000), '9'.repeat(400) + ' kcal', 'Ingredients:', 'Ingredients: ,,,,,,,,', '((((((((((', ')))))))))', '%'.repeat(5000), ('a, ').repeat(20000)];
odd.forEach((t, i) => {
  must('analyze odd#' + i, () => E.analyze(t, {}), 1500);
  must('analyzeRobust odd#' + i, () => E.analyzeRobust(t, { allergies: ['milk'] }), 3000);
  must('focusParts odd#' + i, () => E.focusParts(t), 1500);
  must('parseNutrition odd#' + i, () => N.parseNutrition(t), 1500);
});

// 2. Pathological patterns that expose slow regexes (ReDoS)
const big = {
  'spaces 200k': ' '.repeat(200000) + 'x', 'commas 100k': ','.repeat(100000), 'open brackets 50k': 'Ingredients: ' + '('.repeat(50000),
  'ingredients header spam': 'ingredients:'.repeat(20000), 'digits 300k': '1'.repeat(300000), 'E-numbers 30k': 'E100, '.repeat(30000),
  'one 1MB word': 'a'.repeat(1000000), 'mixed junk 500k': rnd(500000, 'abcdefghij ,()%.:;0123456789\n'), 'all names x20': ('Ingredients: ' + names.join(', ') + ', ').repeat(20)
};
Object.entries(big).forEach(([k, t]) => { must('analyze ' + k, () => E.analyze(t, {}), 4000); must('analyzeRobust ' + k, () => E.analyzeRobust(t, {}), 6000); must('parseNutrition ' + k, () => N.parseNutrition(t), 3000); });

// 3. Range and sanity of numbers
const fin = (name, v, lo, hi) => { if (v !== null && (typeof v !== 'number' || !isFinite(v) || v < lo || v > hi)) fails.push(name + ' out of range: ' + v); };
['1e999 kcal', '-5 g fat', 'Fat NaN g', 'Energy 99999999 kcal Fat 99999 g Sugars 99999 g Salt 99999 g Protein 99999 g'].forEach(t => {
  const p = N.parseNutrition(t); const a = p && N.assess(p, { drink: false }); if (a) { fin('nutrition score', a.score, 0, 100); }
});
L.forEach(l => { const r = E.analyze(l.t, {}); fin('score ' + l.n, r.score, 0, 100); });

// 4. Determinism and consistency across 2000 shuffled lists
let diff = 0;
for (let i = 0; i < 2000; i++) { const t = 'Ingredients: ' + Array.from({ length: 8 }, () => names[Math.floor(Math.random() * names.length)]).join(', '); const a = E.analyze(t, {}), b = E.analyze(t, {}); if (a.fp !== b.fp || a.score !== b.score) diff++; }
if (diff) fails.push('non-deterministic results: ' + diff);

// 5. Throughput and memory: 20,000 analyses
const t0 = Date.now(), h0 = process.memoryUsage().heapUsed;
for (let i = 0; i < 20000; i++) E.analyze(L[i % L.length].t, { allergies: ['milk', 'peanut'] });
const dt = Date.now() - t0; global.gc && global.gc(); const growth = (process.memoryUsage().heapUsed - h0) / 1048576;
if (dt > 60000) fails.push('throughput too low: 20000 analyses took ' + dt + 'ms'); if (growth > 80) fails.push('memory growth ' + growth.toFixed(0) + 'MB');

// 6. Hostile profiles, crop geometry
[{ allergies: Array.from({ length: 5000 }, (_, i) => 'a' + i) }, { allergies: [null, 5, {}, ['x'], '__proto__'] }, { allergies: 'milk' }, null, undefined, { mode: '<img>' }].forEach((p, i) => must('analyze profile#' + i, () => E.analyze('Ingredients: milk, sugar', p), 2000));
[[NaN, 0], [-1e9, 1e9], [Infinity, 0]].forEach(([dx, dy], i) => must('crop#' + i, () => C.move({ x: 10, y: 10, w: 100, h: 100 }, 'br', dx, dy, 500, 400), 50));
['xyz', null, ''].forEach((m, i) => must('crop mode#' + i, () => C.move({ x: 10, y: 10, w: 100, h: 100 }, m, 5, 5, 500, 400), 50));

// 7. Damaged or tampered storage must not crash the history and favourites lists
const F = require('../www/features.js'); const mem = {};
const fake = { getItem: k => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: k => { delete mem[k]; } };
['{"a":1}', '"text"', '123', 'null', 'true', '[[[[', '{"__proto__":{"x":1}}'].forEach((bad, i) => { mem['ls.history'] = bad; mem['ls.fav'] = bad; const st = F.createStore(fake); must('store#' + i, () => { if (!Array.isArray(st.history()) || !Array.isArray(st.favorites())) throw new Error('not an array'); }, 200); });
console.log('stress test: ' + (fails.length ? fails.length + ' PROBLEM(S)' : 'all passed') + ' | 20,000 analyses in ' + dt + ' ms (' + Math.round(20000 / (dt / 1000)) + ' per second) | heap growth ' + growth.toFixed(1) + ' MB');
fails.forEach(f => console.log(' - ' + f));
if (fails.length) process.exit(1);
