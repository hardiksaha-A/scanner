// Regenerates docs/PRIVACY_POLICY.md and docs/TERMS.md from www/compliance/legal.js (the single source of truth).
const fs = require('fs'), path = require('path'), L = require('../www/compliance/legal.js');
fs.writeFileSync(path.join(__dirname, '../docs/PRIVACY_POLICY.md'), L.toMarkdown(L.docs.privacy));
fs.writeFileSync(path.join(__dirname, '../docs/TERMS.md'), L.toMarkdown(L.docs.terms));
console.log('legal docs regenerated; required inputs outstanding:', L.placeholderCount());
