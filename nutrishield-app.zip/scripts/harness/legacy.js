// EXACT copies of the original (pre-change) ingest code from www/index.html, so baselines measure the shipped behaviour.
const { C, decorate } = require('./env');
async function legacyBlobToCanvas(buf, max) { // blobToCanvas(): default smoothing, no imageSmoothingQuality
  const im = await C.loadImage(buf), scale = Math.min(1, max / Math.max(im.width, im.height));
  const c = decorate(C.createCanvas(Math.max(1, Math.round(im.width * scale)), Math.max(1, Math.round(im.height * scale))));
  const cx = c.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, c.width, c.height); cx.drawImage(im, 0, 0, c.width, c.height); return c;
}
function legacyLiveFallback(src) { // snapLensBtn fallback: video frame cropped 6% / 12% / 88% x 76%, then the crop dialog
  const sx = Math.round(src.width * 0.06), sy = Math.round(src.height * 0.12), sw = Math.round(src.width * 0.88), sh = Math.round(src.height * 0.76);
  const c = decorate(C.createCanvas(sw, sh)); c.getContext('2d').drawImage(src, sx, sy, sw, sh, 0, 0, sw, sh); return c;
}
function legacyDialogDefault(src) { // crop dialog "Read selected area" untouched: initial box 6% / 10% / 88% x 80%
  const x = src.width * 0.06, y = src.height * 0.1, w = src.width * 0.88, h = src.height * 0.8, c = decorate(C.createCanvas(Math.round(w), Math.round(h)));
  c.getContext('2d').drawImage(src, x, y, w, h, 0, 0, c.width, c.height); return c;
}
module.exports = { legacyBlobToCanvas, legacyLiveFallback, legacyDialogDefault };
