// Usage: node scripts/harness/baseline.js <image> [repeats=10] [--route camera,gallery,live,dialog] [--variants orig,jpeg40,...] [--out file.json] [--engine legacy|pipeline]
// Runs Tesseract-only (ML Kit exists only on a device). Desktop/Node numbers are NOT Android verification.
require('./env'); const fs = require('fs'), path = require('path'), { trace, firstDiff, ORDER } = require('./trace'), ocr = require('./ocr-node'), V = require('./variants');
const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i > 0 ? process.argv[i + 1] : d; };
const img = process.argv[2], reps = +(process.argv[3] && !process.argv[3].startsWith('--') ? process.argv[3] : 10);
const routes = arg('route', 'camera,gallery,live').split(','), variants = arg('variants', 'orig').split(','), engine = arg('engine', 'legacy');
const reference = arg('ref', '') && fs.readFileSync(arg('ref'), 'utf8');
function cer(a, b) { a = norm(a); b = norm(b); const m = a.length, n = b.length; let p = Array.from({ length: n + 1 }, (_, i) => i); for (let i = 1; i <= m; i++) { const c = [i]; for (let j = 1; j <= n; j++) c[j] = Math.min(p[j] + 1, c[j - 1] + 1, p[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); p = c; } return m ? p[n] / m : 0; }
const norm = s => String(s).toLowerCase().replace(/[^a-z0-9%.,()]+/g, ' ').trim();
(async () => {
  const L = require('./legacy'), P = engine === 'pipeline' ? require('./newpath') : null;
  const SS = require(path.join(__dirname, '..', '..', 'www', 'smartscan.js')); const out = [], t00 = Date.now();
  for (const v of variants) {
    const buf = await V.make(fs.readFileSync(img), v);
    for (const route of routes) {
      const runs = [];
      for (let i = 0; i < reps; i++) {
        const t0 = Date.now();
        let r;
        if (engine === 'legacy') {
          let c = await L.legacyBlobToCanvas(buf, 3200);
          if (route === 'live') c = L.legacyLiveFallback(c); if (route === 'dialog') c = L.legacyDialogDefault(c);
          r = await SS.read(c, { ocr: b => ocr.scan(b) });
        } else r = await P.runFromBuffer(buf, { route, ocr: b => ocr.scan(b) });
        const st = trace(r.text); st.ms = Date.now() - t0; st.pass = r.label + (r.rot ? ' rot' + r.rot : ''); runs.push(st);
      }
      const base = runs[0], stable = runs.every(s => ORDER.every(k => s[k].h === base[k].h));
      const div = runs.map(s => firstDiff(base, s)).filter(Boolean);
      const o = { variant: v, route, reps, stable, firstDivergence: div[0] || null, hashes: Object.fromEntries(ORDER.map(k => [k, base[k].h])), pass: base.pass, medianMs: runs.map(s => s.ms).sort((a, b) => a - b)[reps >> 1],
        ingredients: JSON.parse(base.ingredients.v), nutritionCount: JSON.parse(base.nutrition.v).count, allergenStatus: JSON.parse(base.allergens.v).s, score: JSON.parse(base.score.v), rawChars: base.raw.v.length };
      if (reference) o.cerRaw = Math.round(cer(reference, base.raw.v) * 1000) / 1000;
      out.push(o); console.log(`${v}/${route}: stable=${stable} ${base.pass} found=${o.ingredients.f.length} unk=${o.ingredients.u.length} nut=${o.nutritionCount} alg=${o.allergenStatus} score=${JSON.stringify(o.score)} ${o.medianMs}ms` + (o.cerRaw !== undefined ? ' cer=' + o.cerRaw : ''));
      fs.writeFileSync(arg('out', '/tmp/harness-out.json'), JSON.stringify({ image: path.basename(img), engine, reps, results: out }, null, 1));
    }
  }
  await ocr.close(); console.log('total s', Math.round((Date.now() - t00) / 1000));
})().catch(e => { console.error(e); process.exit(1); });
