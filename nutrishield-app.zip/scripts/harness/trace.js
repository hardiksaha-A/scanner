// Six-stage trace: raw text -> normalised text -> ingredients -> nutrition -> allergens -> score. Reports where two runs first differ.
const crypto = require('crypto'), E = () => global.Engine, N = () => global.Nutrition;
const h = s => crypto.createHash('sha1').update(String(s)).digest('hex').slice(0, 10);
const ALLERGENS = ['milk', 'soy', 'peanut', 'gluten', 'egg', 'nut', 'sesame', 'wheat', 'sulphite', 'mustard', 'celery', 'fish', 'shellfish', 'lupin'];
function trace(rawText) {
  const raw = String(rawText || ''), parts = E().focusParts(raw.trim()), norm = parts.ingredients + '\n--\n' + parts.nutrition;
  const ing = E().analyzeRobust(parts.ingredients, { allergies: ALLERGENS }), nut = N().parseNutrition(parts.ingredients + '\n' + parts.nutrition);
  const a = nut && nut.count >= 2 ? N().assess(nut, {}) : null;
  const st = {
    raw: { v: raw }, norm: { v: norm },
    ingredients: { v: JSON.stringify({ f: ing.found.map(x => x.name), u: ing.unknown }) },
    nutrition: { v: JSON.stringify(nut) },
    allergens: { v: JSON.stringify({ s: ing.allergyStatus, h: ing.warnings.map(x => x.allergy + ':' + x.kind + ':' + x.ingredient).sort() }) },
    score: { v: JSON.stringify({ i: ing.score, iv: ing.verdict, n: a && a.score, o: N().overall(ing.score, a && a.score) }) }
  };
  for (const k in st) st[k].h = h(st[k].v);
  return st;
}
const ORDER = ['raw', 'norm', 'ingredients', 'nutrition', 'allergens', 'score'];
const firstDiff = (a, b) => ORDER.find(k => a[k].h !== b[k].h) || null;
module.exports = { trace, firstDiff, ORDER, ALLERGENS };
