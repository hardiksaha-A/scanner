// Test-only DOM shim: lets the app's own canvas code (smartscan.js, etc.) run in Node.
// Needs @napi-rs/canvas, installed with `npm i --no-save @napi-rs/canvas` (NOT a project dependency).
const path = require('path'), root = path.join(__dirname, '..', '..');
let C = null; try { C = require('@napi-rs/canvas'); } catch (e) { try { C = require(require.resolve('@napi-rs/canvas', { paths: [root] })); } catch (e2) { C = null; } } // optional: only the image tests need it
function decorate(c) { c.toBlob = (cb, type, q) => { const b = c.toBuffer(type === 'image/jpeg' ? 'image/jpeg' : 'image/png', q); cb({ buf: b, size: b.length, type }); }; c.toDataURL = (type, q) => 'data:' + type + ';base64,' + c.toBuffer(type === 'image/jpeg' ? 'image/jpeg' : 'image/png', q && type === 'image/jpeg' ? Math.round(q * 100) : undefined).toString('base64'); return c; }
global.window = global; global.document = { createElement: t => { if (t !== 'canvas' || !C) throw new Error('shim: ' + t); return decorate(C.createCanvas(1, 1)); } };
const w = global; w.INGREDIENT_ROWS = require(root + '/www/ingredients.js'); w.INGREDIENT_USES = require(root + '/www/uses.js');
w.Engine = require(root + '/www/engine.js'); w.Nutrition = require(root + '/www/nutrition.js'); w.Barcode = require(root + '/www/barcode.js');
module.exports = { C, decorate, root };
