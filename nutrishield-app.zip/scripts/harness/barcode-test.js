// Barcode normalisation tests. Run: node scripts/harness/barcode-test.js
const B = require('../../www/barcode.js'); let pass = 0, fail = 0;
const ok = (n, c, d) => { c ? pass++ : (fail++, console.log('FAIL ' + n + (d ? ' -> ' + d : ''))); };
// Published UPC-E <-> UPC-A pair, and the old EAN-8 behaviour kept
ok('upce expand', B.expandUpcE('04252614') === '042100005264');
ok('upce via normalize', B.normalize('04252614').kind === 'UPC-E' && B.normalize('04252614').key === '0042100005264');
ok('upce bad check', B.normalize('04252615').ok === false);
ok('upce ns 2 rejected', B.expandUpcE('24252614') === null);
ok('isValidGtin unchanged for EAN-8', B.isValidGtin('96385074') && !B.isValidGtin('96385075'));
ok('isValidGtin still rejects UPC-E (legacy contract)', !B.isValidGtin('04252614'));
ok('ean8 key', B.normalize('96385074').key === '0000096385074' && B.normalize('96385074').kind === 'EAN-8');
ok('upc-a == ean13 0-prefixed', B.normalize('042100005264').key === B.normalize('0042100005264').key);
ok('gtin14 indicator 0 == ean13', B.normalize('08901491367219').key === '8901491367219');
ok('gtin14 indicator 1 own key', (() => { const b = '1890149136721', c = b + B.check(b); const r = B.normalize(c); return r.ok && r.kind === 'GTIN-14' && r.key === c && r.gtin13 === null; })());
ok('ean13 aliases include 14 and (when 0-prefixed) 12', B.normalize('0042100005264').aliases.includes('042100005264') && B.normalize('8901491367219').aliases.includes('08901491367219'));
ok('legacy cache key reachable: scanned 12-digit', B.normalize('042100005264').aliases.includes('042100005264'));
ok('legacy cache key reachable: scanned UPC-E', B.normalize('04252614').aliases.includes('04252614'));
ok('ambiguous 8-digit: default EAN-8, scanner format wins', B.normalize('01234565').kind === 'EAN-8' && B.normalize('01234565', { format: 'upc_e' }).kind === 'UPC-E');
ok('garbage', !B.normalize('abc').ok && !B.normalize('123').ok && !B.normalize('').ok && !B.normalize(null).ok);
ok('non-digits stripped', B.normalize('8 901491 367219').key === '8901491367219');
// Round trip: 5000 random valid UPC-A with number system 0/1 that can be compressed
let seed = 12345; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff; let rt = 0, rtBad = 0;
for (let i = 0; i < 5000; i++) { let b = String(rnd() < .5 ? 0 : 1); for (let j = 0; j < 10; j++) b += Math.floor(rnd() * 10); if (rnd() < .5) b = b.slice(0, 6) + '0000' + b.slice(10, 11), b = b.slice(0, 11);
  const a = b + B.check(b), e = B.compressUpcA(a); if (!e) continue; rt++; if (B.expandUpcE(e) !== a) rtBad++; }
ok('round trip UPC-A -> UPC-E -> UPC-A (' + rt + ' compressible)', rt > 500 && rtBad === 0, rtBad + ' mismatches');
console.log(`barcode tests: ${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
