// Regression gate: the new text path (normalise -> focusParts -> reader) must not change ANY assessment on the existing corpus. Run: node scripts/harness/golden-test.js
require('./env'); const fs = require('fs'), path = require('path'), E = global.Engine, N = global.Nutrition, P = require('../../www/pipeline.js'), R = require('../../www/nutrition-reader.js'), L = require('../labels.json');
global.NutritionReader = R; global.Pipeline = P;
const html = fs.readFileSync(path.join(__dirname, '../../www/index.html'), 'utf8'), demos = [...html.matchAll(/text: '((?:[^'\\]|\\.)*)'/g)].map(m => m[1].replace(/\\n/g, '\n'));
const texts = L.map(l => l.t).concat(demos), AL = ['milk', 'soy', 'peanut', 'gluten', 'egg', 'nut', 'sesame', 'wheat', 'sulphite'];
const sig = (t, legacy) => { const parts = E.focusParts(t.trim()), r = E.analyzeRobust(parts.ingredients, { allergies: AL }), pn = (legacy ? N.parseNutrition : R.parse)(parts.ingredients + '\n' + parts.nutrition), a = pn && pn.count >= 2 ? N.assess(pn, {}) : null;
  return JSON.stringify([parts.ingredients, parts.nutrition, r.fp, r.score, r.verdict, r.found.map(f => f.name), r.unknown, r.warnings, r.allergyStatus, a && a.score, N.overall(r.score, a && a.score)]); };
let same = 0, bad = []; for (const t of texts) { const n = P.normaliseText(t).text; (sig(t, true) === sig(n, false)) ? same++ : bad.push(t.slice(0, 60)); }
console.log(`golden: ${same}/${texts.length} texts give identical ingredients, nutrition, Match ID, allergens, score and verdict through the new path`); if (bad.length) console.log('DIFFERENT:', bad);
// analyze vs analyzeRobust: identical whenever analyze already scores (the barcode route keeps using analyze)
let eq = 0, tot = 0, differ = []; for (const t of texts) { const x = E.analyze(E.focusParts(t.trim()).ingredients, {}), y = E.analyzeRobust(E.focusParts(t.trim()).ingredients, {}); if (x.score !== null) { tot++; JSON.stringify([x.score, x.verdict, x.fp]) === JSON.stringify([y.score, y.verdict, y.fp]) ? eq++ : differ.push(t.slice(0, 40)); } }
console.log(`analyze vs analyzeRobust where analyze scores: ${eq}/${tot} identical`); process.exit(bad.length || differ.length ? 1 : 0);
