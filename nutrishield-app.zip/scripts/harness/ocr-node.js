// Tesseract (same tesseract.js + eng best_int data as the app) running in Node. Test-only.
// tesseract.js picks its browser build when it sees window/document, so the shim globals are hidden during each OCR call.
const path = require('path'), { root } = require('./env');
let worker = null;
async function hidden(fn) { const w = global.window, d = global.document; delete global.window; delete global.document; try { return await fn(); } finally { global.window = w; global.document = d; } }
async function get() { if (worker) return worker; const { createWorker } = require(root + '/node_modules/tesseract.js');
  worker = await createWorker('eng', 1, { langPath: path.join(root, 'node_modules/@tesseract.js-data/eng/4.0.0_best_int'), gzip: true, cacheMethod: 'none' }); return worker; }
async function scan(blob) { return hidden(async () => { const w = await get(); const { data } = await w.recognize(blob.buf || blob, {}, { text: true }); return data.text; }); }
async function configure(params) { return hidden(async () => { const w = await get(); await w.setParameters(params); }); }
async function close() { if (worker) await hidden(() => worker.terminate()); worker = null; }
module.exports = { scan, close, configure };
