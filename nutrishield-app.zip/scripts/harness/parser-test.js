// Nutrition parser: (1) equivalence with the ORIGINAL parser on single-column text (no unintended assessment change),
// (2) each intended correction identified and tested. Run: node scripts/harness/parser-test.js
const fs = require('fs'), path = require('path'), N0 = require('../../www/nutrition.js'), R = require('../../www/nutrition-reader.js'), L = require('../labels.json');
const N = Object.assign({}, N0, { parseNutritionLegacy: N0.parseNutrition, parseNutrition: R.parse });
const K = ['kcal', 'fat', 'sat', 'carbs', 'sugars', 'fibre', 'protein', 'salt'], pick = o => K.map(k => o[k]);
let pass = 0, fail = 0; const ok = (n, c, d) => { c ? pass++ : (fail++, console.log('FAIL ' + n + (d ? ' -> ' + d : ''))); };
const html = fs.readFileSync(path.join(__dirname, '../../www/index.html'), 'utf8');
const demos = [...html.matchAll(/text: '((?:[^'\\]|\\.)*)'/g)].map(m => m[1].replace(/\\n/g, '\n'));
const lp = require('vm').runInNewContext(fs.readFileSync(path.join(__dirname, '../../www/localdb.js'), 'utf8').replace('window.', 'this.') + ';this.LOCAL_PRODUCTS', {});
const formatted = Object.values(lp).map(p => N.format(p.nutrition));
const synth = [];
for (const [k, v] of [[554, 33.4], [120, 3.1], [455, 18.5]]) synth.push(`Energy ${k} kcal\nTotal Fat ${v} g\nSaturated Fat ${(v / 3).toFixed(1)} g\nCarbohydrate 61 g\nTotal Sugars 5.2 g\nDietary Fibre 2.1 g\nProtein 7.8 g\nSalt 1.2 g`,
  `Energy ${k * 4.184 | 0} kJ / ${k} kcal\nFat ${v}g\nof which saturates ${(v / 3).toFixed(1)}g\nCarbohydrate 61g\nof which sugars 5.2g\nProtein 7.8g\nSodium 480 mg`, `Calories ${k}\nFat ${v},0 g\nProtein 7,8 g`);
const corpus = [].concat(L.map(l => l.t), demos, formatted, synth);
let same = 0, diff = [];
for (const t of corpus) { const a = N.parseNutritionLegacy(t), b = N.parseNutrition(t); const eq = JSON.stringify(pick(a)) === JSON.stringify(pick(b)) && a.count === b.count; eq ? same++ : diff.push(t.slice(0, 50)); }
ok(`single-column corpus identical to original (${corpus.length} texts: ${L.length} labels, ${demos.length} demos, ${formatted.length} bundled products, ${synth.length} synthetic)`, diff.length === 0, diff.join(' | '));
// assessment unchanged for every corpus text (scores come from Nutrition.assess on the parsed numbers)
let asDiff = 0; for (const t of corpus) { const a = N.parseNutritionLegacy(t), b = N.parseNutrition(t); const sa = a.count >= 2 ? N.assess(a, {}) : null, sb = b.count >= 2 ? N.assess(b, {}) : null; if (JSON.stringify(sa && sa.score) !== JSON.stringify(sb && sb.score)) asDiff++; }
ok('nutrition assessment score identical on corpus', asDiff === 0, asDiff + ' differ');
// format() -> parse round trip equals the structured numbers (the route a barcode record takes into the text boxes)
for (const p of Object.values(lp)) { const r = N.parseNutrition(N.format(p.nutrition)); ok('format/parse round trip ' + p.name, JSON.stringify(pick(r)) === JSON.stringify(pick(Object.assign({ kcal: null, fat: null, sat: null, carbs: null, sugars: null, fibre: null, protein: null, salt: null }, p.nutrition))), JSON.stringify(pick(r))); }
// ---- intended corrections (each is a difference from the original parser) ----
const P = N.parseNutrition, Lg = N.parseNutritionLegacy;
let r = P('Per serve | Per 100 g\nEnergy 111 kcal 554 kcal\nProtein 1.2 g 6 g\nTotal Fat 3.3 g 16.7 g');
ok('C1 per-100 column chosen when per-serve comes first', r.kcal === 554 && r.protein === 6 && r.fat === 16.7 && r.basis === 'per_100', JSON.stringify(r)); ok('C1 original took per-serve', Lg('Per serve | Per 100 g\nEnergy 111 kcal 554 kcal').kcal === 111);
r = P('Nutrients | Per 100 g | %RDA Per Serve\nEnergy 537 kcal 27%\nProtein 6.7 g 13%\nTotal Fat 33.2 g 50%');
ok('C2 %RDA column skipped', r.kcal === 537 && r.protein === 6.7 && r.fat === 33.2, JSON.stringify(r));
r = P('Protein 14% 7.2 g'); ok('C3 percent before value skipped', r.protein === 7.2 && Lg('Protein 14% 7.2 g').protein === 14);
r = P('Total Fat 3O.4 g\nProtein 6 g'); ok('C4 letter O read as 0, logged', r.fat === 30.4 && r.corrections.length === 1 && Lg('Total Fat 3O.4 g').fat === 3);
r = P('Total Fat 3O.4g'); ok('C4b unit attached', r.fat === 30.4, JSON.stringify(r));
r = P('Per serve\nEnergy 111 kcal\nProtein 1.2 g'); ok('C5 per-serve-only label is not used as per 100 g', r.count === 0 && r.flags.includes('per-serve-only') && Lg('Per serve\nEnergy 111 kcal\nProtein 1.2 g').count === 2);
r = P('Energy\nTotal Fat\nProtein\nSalt\n554 kcal\n33.4 g\n6 g\n1.74 g'); ok('C6 label block then value block paired in order, flagged', r.count === 4 && r.kcal === 554 && r.salt === 1.74 && r.flags.includes('paired-by-order'));
r = P('Energy\nTotal Fat\nProtein\n554 kcal\n33.4 g'); ok('C6b unequal blocks are NOT paired', !r.paired && r.count <= 1, JSON.stringify(r));
r = P('Total Fat 3.3 g\nSaturated Fat 15.1 g\nSugars 60 g\nCarbohydrate 57.5 g'); ok('C7 implausible values flagged, numbers kept as read', r.sat === 15.1 && r.flags.includes('sat-fat-above-total-fat') && r.flags.includes('sugars-above-carbohydrate'));
r = P('Energy 900 kcal\nTotal Fat 3 g\nCarbohydrate 10 g\nProtein 5 g'); ok('C8 energy/macro mismatch flagged', r.flags.includes('kcal-vs-macros-mismatch'));
r = P('Total Fat 334 g\nProtein 6 g'); ok('C9 dropped decimal is out-of-range: not stored, flagged', r.fat === null && r.flags.includes('fat-out-of-range') && r.protein === 6);
r = P('Nutritional Information  Serve size 30 g\nPer 100 g\nEnergy 537 kcal'); ok('C10 serving size read', r.serving === '30 g');
r = P('Energy 2318 kJ (554 kcal)'); ok('kJ + kcal in brackets still 554', r.kcal === 554);
r = P('Energy 2318 kJ'); ok('kJ only converted', r.kcal === Math.round(2318 / 4.184));
r = P('Sodium 480 mg'); ok('sodium mg -> salt g', Math.abs(r.salt - 1.2) < 1e-9, JSON.stringify(r));
r = P('Ingredients: Sugar, Salt, Palm Oil, Fat, Protein Isolate\nProtein 6 g'); ok('ingredient line ignored', r.protein === 6 && r.sugars === null);
console.log(`parser tests: ${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
