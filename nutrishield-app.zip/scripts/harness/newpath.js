// The new input path as the app runs it (Node, Tesseract only): decode -> high-quality downscale -> (auto crop for the dialog route) -> SmartScan.
const { C, decorate } = require('./env'), P = require('../../www/pipeline.js'), SS = require('../../www/smartscan.js');
async function runFromBuffer(buf, o) {
  const im = await C.loadImage(buf), lim = P.limits({ deviceMemory: o.low ? 2 : 8, hardwareConcurrency: 8 });
  let c = P.toCanvas(im, lim.maxSide);
  if (o.route === 'dialog') { const b = P.textRegion(c); if (b) { const d = decorate(C.createCanvas(b.w, b.h)); d.getContext('2d').drawImage(c, b.x, b.y, b.w, b.h, 0, 0, b.w, b.h); c = d; } }
  const r = await SS.read(c, { ocr: o.ocr, target: lim.target, detail: lim.detail }); r.metrics = P.metrics(c); return r;
}
module.exports = { runFromBuffer };
