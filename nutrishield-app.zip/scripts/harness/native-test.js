// ML Kit result assembly (mock results shaped like the plugin's TextDetectionResult). Real device output is NOT verified here.
const NO = require('../../www/native-ocr.js'); let pass = 0, fail = 0; const ok = (n, c, d) => { c ? pass++ : (fail++, console.log('FAIL ' + n + (d ? ' -> ' + d : ''))); };
const L = (text, l, t, r, b) => ({ text, boundingBox: { left: l, top: t, right: r, bottom: b }, elements: [] }), B = (...lines) => ({ text: lines.map(x => x.text).join('\n'), boundingBox: lines[0].boundingBox, lines });
const tbl = { text: '', blocks: [B(L('Energy', 10, 100, 90, 120), L('Protein', 10, 130, 90, 150), L('Total Fat', 10, 160, 100, 180), L('Salt', 10, 190, 60, 210)), B(L('537 kcal', 200, 101, 280, 121), L('6.7 g', 200, 131, 260, 151), L('33.2 g', 200, 161, 270, 181), L('1.1 g', 200, 191, 260, 211))] };
const t = NO.textFrom(tbl); ok('rows rebuilt from separate label/value blocks', t.split('\n').length === 4 && /^Energy 537 kcal$/m.test(t) && /^Total Fat 33.2 g$/m.test(t), t);
const noBox = JSON.parse(JSON.stringify(tbl)); noBox.blocks.forEach(b => { delete b.boundingBox; b.lines.forEach(l => delete l.boundingBox); });
ok('no boxes -> original output (labels then values)', NO.textFrom(noBox) === 'Energy\nProtein\nTotal Fat\nSalt\n537 kcal\n6.7 g\n33.2 g\n1.1 g');
const two = { blocks: [B(L('Ingredients: Potato, Edible Vegetable Oil,', 10, 10, 300, 30), L('Seasoning (Sugar, Salt)', 10, 32, 200, 52)), B(L('Contains Soy, Milk', 320, 10, 500, 30))] };
ok('ingredient columns are never merged', NO.textFrom(two) === 'Ingredients: Potato, Edible Vegetable Oil,\nSeasoning (Sugar, Salt)\nContains Soy, Milk');
const per = { blocks: [B(L('Energy', 10, 100, 90, 120), L('537 kcal', 150, 100, 230, 120), L('27 %', 260, 100, 300, 120))] };
ok('two value columns kept in order', NO.textFrom(per) === 'Energy 537 kcal 27 %', NO.textFrom(per));
ok('plain text fallback', NO.textFrom({ text: ' hello ' }) === 'hello');
const R = require('../../www/nutrition-reader.js'); const r = R.parse(t); ok('rebuilt text parses to 4 values', r.kcal === 537 && r.protein === 6.7 && r.fat === 33.2 && r.salt === 1.1, JSON.stringify(r));
console.log(`native assembly tests: ${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
