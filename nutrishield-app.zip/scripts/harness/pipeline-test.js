// Pipeline helpers on synthetic images (no real-label accuracy claims). Run: node scripts/harness/pipeline-test.js
const { C, decorate } = require('./env'); if (!C) { console.log('pipeline tests: SKIPPED (install the optional test canvas: npm i --no-save @napi-rs/canvas)'); process.exit(0); }
const P = require('../../www/pipeline.js');
let pass = 0, fail = 0; const ok = (n, c, d) => { c ? pass++ : (fail++, console.log('FAIL ' + n + (d ? ' -> ' + d : ''))); };
let seed = 7; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
const WORDS = 'Ingredients Potato Edible Vegetable Oil Seasoning Sugar Iodised Salt Milk Solids Spices Condiments Maltodextrin Flavour Cheese Powder Nutrition Information Energy Protein Carbohydrate Total Fat Per 100 g kcal'.split(' ');
function page(W, H, lay, angle) { // text block at lay={x,y,w,h}; returns canvas and true ink bbox
  const c = decorate(C.createCanvas(W, H)), x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, W, H); x.fillStyle = '#111'; const fs = Math.max(14, Math.round(lay.h / 14)); x.font = fs + 'px sans-serif';
  x.save(); if (angle) { x.translate(lay.x + lay.w / 2, lay.y + lay.h / 2); x.rotate(angle * Math.PI / 180); x.translate(-(lay.x + lay.w / 2), -(lay.y + lay.h / 2)); }
  for (let y = lay.y + fs; y < lay.y + lay.h; y += Math.round(fs * 1.5)) { let s = '', ww = 0; while (ww < lay.w * 0.9) { const w = WORDS[(rnd() * WORDS.length) | 0]; s += w + ' '; ww = x.measureText(s).width; } x.fillText(s, lay.x, y); }
  x.restore(); const d = x.getImageData(0, 0, W, H).data; let x0 = W, y0 = H, x1 = -1, y1 = -1;
  for (let y = 0; y < H; y++) for (let xx = 0; xx < W; xx++) if (d[(y * W + xx) * 4] < 140) { if (xx < x0) x0 = xx; if (xx > x1) x1 = xx; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  return { c, ink: { x0, y0, x1, y1 } };
}
// 1) auto text region never cuts ink (12 layouts incl. text near the edges)
let contained = 0, total = 0, tooBig = 0;
for (let i = 0; i < 12; i++) { const W = 1000 + ((rnd() * 600) | 0), H = 800 + ((rnd() * 600) | 0), w = 250 + rnd() * (W - 300), h = 180 + rnd() * (H - 250), lay = { x: rnd() * (W - w) * (i % 3 === 0 ? 0.05 : 1), y: rnd() * (H - h), w, h }, { c, ink } = page(W, H, lay, 0);
  const b = P.textRegion(c); total++; if (!b) { contained++; continue; } // null = whole image kept: nothing cut
  if (b.x <= ink.x0 && b.y <= ink.y0 && b.x + b.w >= ink.x1 && b.y + b.h >= ink.y1) contained++; else console.log('cut:', JSON.stringify(b), JSON.stringify(ink)); if (b.w * b.h > 0.9 * W * H) tooBig++; }
ok(`auto text region contains 100% of ink (${contained}/${total})`, contained === total);
// 2) quality metrics rank blur / dark / glare correctly
const { c: sharp } = page(1400, 1000, { x: 80, y: 80, w: 1200, h: 800 }, 0), blurred = decorate(C.createCanvas(1400, 1000)); { const x = blurred.getContext('2d'); x.filter = 'blur(6px)'; x.drawImage(sharp, 0, 0); }
const dark = decorate(C.createCanvas(1400, 1000)); { const x = dark.getContext('2d'); x.drawImage(sharp, 0, 0); x.fillStyle = 'rgba(0,0,0,.8)'; x.fillRect(0, 0, 1400, 1000); }
const glare = decorate(C.createCanvas(1400, 1000)); { const x = glare.getContext('2d'); x.drawImage(sharp, 0, 0); x.fillStyle = 'rgba(120,120,120,.6)'; x.fillRect(0, 0, 1400, 1000); x.fillStyle = '#fff'; x.fillRect(100, 100, 700, 500); }
const ms = P.metrics(sharp), mb = P.metrics(blurred), md = P.metrics(dark), mg = P.metrics(glare);
ok('sharp image has no warnings', ms.warnings.length === 0, JSON.stringify(ms)); ok('blurred flagged and blur score lower', mb.warnings.includes('blurry') && mb.blur < ms.blur, JSON.stringify([ms.blur, mb.blur]));
ok('dark flagged', md.warnings.includes('dark'), JSON.stringify(md)); ok('glare flagged', mg.warnings.includes('glare'), JSON.stringify(mg));
ok('small image flagged', P.metrics(decorate(C.createCanvas(220, 350))).warnings.includes('low-resolution'));
// 3) skew estimate within 1 degree for +-3, +-6, and not triggered at 0
for (const a of [-6, -3, 0, 3, 6]) { const { c } = page(1200, 900, { x: 100, y: 100, w: 1000, h: 700 }, a), s = P.estimateSkew(c); ok(`skew ${a}: estimated ${s.deg} (conf ${s.conf})`, a === 0 ? Math.abs(s.deg) < 1 : Math.abs(Math.abs(s.deg) - Math.abs(a)) <= 1 && Math.sign(s.deg) === Math.sign(a) || Math.abs(s.deg + a) <= 1); }
// 4) resize: exact size, no upscale, original canvas untouched
const big = page(3000, 2000, { x: 100, y: 100, w: 2500, h: 1500 }, 0).c, before = big.width + 'x' + big.height, r = P.toCanvas(big, 1000); ok('downscale to long side 1000', r.width === 1000 && r.height === 667, r.width + 'x' + r.height); ok('source canvas untouched', big.width + 'x' + big.height === before);
ok('never upscales', P.toCanvas(sharp, 5000).width === 1400);
// 5) normalisation keeps content, records changes
const n = P.normaliseText('Ingre\u200bdients:  Sugar,\u00a0Salt\n  Palm  Oil '); ok('normalise', n.text === 'Ingredients: Sugar, Salt\nPalm Oil' && n.changes.length >= 2, JSON.stringify(n));
ok('limits low/high', P.limits({ deviceMemory: 2 }).maxSide === 2400 && P.limits({ deviceMemory: 8, hardwareConcurrency: 8 }).maxSide === 3200);
// 6) lossless rotate + exact crop (pixel-for-pixel)
{ const W = 7, H = 5, a = decorate(C.createCanvas(W, H)), g = a.getContext('2d'), im = g.createImageData(W, H); for (let i = 0; i < W * H; i++) { im.data[i * 4] = i * 5; im.data[i * 4 + 1] = 255 - i * 3; im.data[i * 4 + 2] = (i * 37) & 255; im.data[i * 4 + 3] = 255; } g.putImageData(im, 0, 0);
  const px = (c, x, y) => Array.from(c.getContext('2d').getImageData(x, y, 1, 1).data).join(','), same = (p, q) => p.width === q.width && p.height === q.height && Buffer.compare(Buffer.from(p.getContext('2d').getImageData(0, 0, p.width, p.height).data), Buffer.from(q.getContext('2d').getImageData(0, 0, q.width, q.height).data)) === 0;
  const r1 = P.rotate90(a, 1), r2 = P.rotate90(a, 2), r3 = P.rotate90(a, 3); let okMap = r1.width === H && r1.height === W && r3.width === H && r2.width === W;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const v = px(a, x, y); okMap = okMap && px(r1, H - 1 - y, x) === v && px(r2, W - 1 - x, H - 1 - y) === v && px(r3, y, W - 1 - x) === v; }
  ok('rotate90: every pixel lands where a clockwise / 180 / anticlockwise turn puts it', okMap);
  ok('rotate: 4 x 90 = original, 1 then 3 = original, 0 turns returns the same canvas', same(P.rotate90(P.rotate90(P.rotate90(P.rotate90(a, 1), 1), 1), 1), a) && same(P.rotate90(r1, 3), a) && P.rotate90(a, 0) === a && P.rotate90(a, 4) === a);
  const e = P.cropExact(a, { x: 1, y: 1, w: 4, h: 3 }); let okC = e.width === 4 && e.height === 3; for (let y = 0; y < 3; y++) for (let x = 0; x < 4; x++) okC = okC && px(e, x, y) === px(a, x + 1, y + 1);
  ok('cropExact whole-pixel crop is a 1:1 copy', okC);
  const f = P.cropExact(a, { x: 1.4, y: 0.6, w: 2.3, h: 2.2 }); ok('cropExact rounds outward (never trims an edge pixel): 1.4..3.7 -> 1..4, 0.6..2.8 -> 0..3', f.width === 3 && f.height === 3 && px(f, 0, 0) === px(a, 1, 0));
  const k = P.cropExact(a, { x: -3, y: -3, w: 50, h: 50 }); ok('cropExact clamps to the image', k.width === W && k.height === H && same(k, a));
  // text survives a rotate-back and an exact crop unchanged (real rendered text, not a pattern)
  const t = page(900, 700, { x: 60, y: 60, w: 760, h: 520 }, 0), rt = P.rotate90(P.rotate90(t.c, 1), 3); ok('rendered text page: rotate + rotate back is identical', same(rt, t.c));
}
// 7) zoom / pan maths
{ const W = 600, H = 400; let v = { z: 1, ox: 0, oy: 0 };
  const v2 = P.viewZoomAt(v, 2, 300, 200, W, H), b = P.viewToBase(v2, 300, 200); ok('zoom about a point keeps that point fixed', v2.z === 2 && Math.abs(b[0] - 300) < 1e-9 && Math.abs(b[1] - 200) < 1e-9, JSON.stringify(v2));
  const v3 = P.viewZoomAt(v, 3, 0, 0, W, H); ok('zoom at the top-left corner keeps the corner', v3.ox === 0 && v3.oy === 0 && v3.z === 3);
  const v4 = P.viewZoomAt(v2, 100, 599, 399, W, H); ok('zoom is capped at ' + P.VIEW_MAX + 'x', v4.z === P.VIEW_MAX);
  ok('zooming back out returns to the fitted view', (() => { const o = P.viewZoomAt(P.viewZoomAt(v, 4, 123, 77, W, H), 0.0001, 123, 77, W, H); return o.z === 1 && o.ox === 0 && o.oy === 0; })());
  let bad = 0; for (let i = 0; i < 2000; i++) { const z = 1 + rnd() * 9, o = P.viewClamp({ z, ox: (rnd() - 0.5) * 8000, oy: (rnd() - 0.5) * 8000 }, W, H); if (o.ox > 0 || o.oy > 0 || o.ox < W - W * o.z - 1e-9 || o.oy < H - H * o.z - 1e-9 || o.z > P.VIEW_MAX) bad++; }
  ok('pan is clamped so the photo always covers the preview (2000 random views)', bad === 0, bad + ' outside');
  const pt = P.viewToBase({ z: 4, ox: -900, oy: -500 }, 450, 300); ok('screen -> photo coordinates', pt[0] === 337.5 && pt[1] === 200, JSON.stringify(pt)); }
// 8) perspective correction: geometry checked with an independently coded forward projection (Heckbert square-to-quad)
function fwdMatrix(q) { const [x0, y0] = q[0], [x1, y1] = q[1], [x2, y2] = q[2], [x3, y3] = q[3], dx1 = x1 - x2, dx2 = x3 - x2, dx3 = x0 - x1 + x2 - x3, dy1 = y1 - y2, dy2 = y3 - y2, dy3 = y0 - y1 + y2 - y3, den = dx1 * dy2 - dx2 * dy1, g = (dx3 * dy2 - dx2 * dy3) / den, h = (dx1 * dy3 - dx3 * dy1) / den; return [x1 - x0 + g * x1, x3 - x0 + h * x3, x0, y1 - y0 + g * y1, y3 - y0 + h * y3, y0, g, h, 1]; }
const mapUV = (M, u, v) => { const d = M[6] * u + M[7] * v + 1; return [(M[0] * u + M[1] * v + M[2]) / d, (M[3] * u + M[4] * v + M[5]) / d]; };
function distort(pg, W, H, q) { const M = fwdMatrix(q), [a, b, c, d, e, f, g, h] = M, det = a * (e - f * h) - b * (d - f * g) + c * (d * h - e * g), inv = [(e - f * h), (c * h - b), (b * f - c * e), (f * g - d), (a - c * g), (c * d - a * f), (d * h - e * g), (b * g - a * h), (a * e - b * d)].map(v => v / det);
  const o = decorate(C.createCanvas(W, H)), og = o.getContext('2d'), oi = og.createImageData(W, H), pw = pg.width, ph = pg.height, pd = pg.getContext('2d').getImageData(0, 0, pw, ph).data;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const dn = inv[6] * (x + 0.5) + inv[7] * (y + 0.5) + inv[8], u = (inv[0] * (x + 0.5) + inv[1] * (y + 0.5) + inv[2]) / dn, v = (inv[3] * (x + 0.5) + inv[4] * (y + 0.5) + inv[5]) / dn, i = (y * W + x) * 4;
    if (u >= 0 && u < 1 && v >= 0 && v < 1) { const sx = Math.min(pw - 1, Math.floor(u * pw)), sy = Math.min(ph - 1, Math.floor(v * ph)), j = (sy * pw + sx) * 4; oi.data[i] = pd[j]; oi.data[i + 1] = pd[j + 1]; oi.data[i + 2] = pd[j + 2]; } else { oi.data[i] = oi.data[i + 1] = oi.data[i + 2] = 255; } oi.data[i + 3] = 255; }
  og.putImageData(oi, 0, 0); return o; }
{ const Wp = 900, Hp = 600, pg = decorate(C.createCanvas(Wp, Hp)), g = pg.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, Wp, Hp); g.fillStyle = '#000'; const dots = []; for (let i = 1; i <= 3; i++) for (let j = 1; j <= 3; j++) { g.beginPath(); g.arc(i * Wp / 4, j * Hp / 4, 7, 0, 7); g.fill(); dots.push([i / 4, j / 4]); }
  const Q = [[180, 120], [1020, 200], [960, 780], [120, 700]], D = distort(pg, 1200, 900, Q), res = P.perspectiveWarp(D, Q);
  ok('perspective: warp used', res && res.mode === 'warp'); const R = res.canvas, rd = R.getContext('2d').getImageData(0, 0, R.width, R.height).data; let worst = 0;
  for (const [u, v] of dots) { const cx = u * R.width, cy = v * R.height; let sx = 0, sy = 0, n = 0; for (let y = Math.max(0, Math.floor(cy - 16)); y < Math.min(R.height, cy + 16); y++) for (let x = Math.max(0, Math.floor(cx - 16)); x < Math.min(R.width, cx + 16); x++) if (rd[(y * R.width + x) * 4] < 128) { sx += x + 0.5; sy += y + 0.5; n++; } worst = n ? Math.max(worst, Math.hypot(sx / n - cx, sy / n - cy)) : 99; }
  ok('perspective: 9 dots return to their grid positions within 1.5 px (worst ' + worst.toFixed(2) + ' px) on a ' + R.width + 'x' + R.height + ' result', worst <= 1.5);
  ok('perspective: result is not smaller than the source edges (no downscale)', R.width >= Math.round(Math.max(Math.hypot(1020 - 180, 200 - 120), Math.hypot(960 - 120, 780 - 700))) - 1);
  const ex = P.perspectiveWarp(D, [[100, 100], [500, 100], [500, 400], [100, 400]]); ok('axis-aligned corners take the exact 1:1 copy path', ex && ex.mode === 'exact' && ex.canvas.width === 400 && ex.canvas.height === 300);
  ok('bow-tie (crossed) corners rejected', P.perspectiveWarp(D, [[100, 100], [500, 400], [500, 100], [100, 400]]) === null); ok('collapsed corners rejected', P.perspectiveWarp(D, [[100, 100], [110, 100], [110, 110], [100, 110]]) === null);
  ok('concave corners rejected', P.perspectiveWarp(D, [[100, 100], [500, 100], [300, 250], [100, 400]]) === null);
  const big = P.perspectiveWarp(D, Q, null, { maxPixels: 100000 }); ok('maxPixels cap respected', big.canvas.width * big.canvas.height <= 100000 * 1.02);
  const hh = P.solveHomography([[0, 0], [10, 0], [10, 10], [0, 10]], [[0, 0], [10, 0], [10, 10], [0, 10]]); ok('identity homography', hh && Math.abs(hh[0] - 1) < 1e-9 && Math.abs(hh[4] - 1) < 1e-9 && Math.abs(hh[2]) < 1e-9);
  const flat = decorate(C.createCanvas(64, 64)); { const x = flat.getContext('2d'); x.fillStyle = '#808080'; x.fillRect(0, 0, 64, 64); } const us = P.unsharp(flat, 0.8), ud = us.getContext('2d').getImageData(10, 10, 1, 1).data; ok('unsharp leaves flat areas unchanged', ud[0] === 128 && ud[1] === 128);
}
{ const Wp = 900, Hp = 500, pg = decorate(C.createCanvas(Wp, Hp)), g = pg.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, Wp, Hp); g.fillStyle = '#111'; g.font = '30px sans-serif'; for (let i = 0; i < 8; i++) g.fillText('Ingredients Potato Edible Vegetable Oil Seasoning Sugar Salt', 30, 50 + i * 55);
  const Q = [[150, 80], [1050, 150], [980, 650], [90, 600]], D = distort(pg, 1200, 800, Q), sharp = P.straighten(D, Q); ok('straighten: sharp input is NOT sharpened', sharp && sharp.mode === 'warp' && sharp.sharpened === false);
  const bl = decorate(C.createCanvas(1200, 800)); { const x = bl.getContext('2d'); x.filter = 'blur(3px)'; x.drawImage(D, 0, 0); } const rb = P.straighten(bl, Q), rn = P.perspectiveWarp(bl, Q);
  const lapVar = c => { const w = c.width, h = c.height, d = c.getContext('2d').getImageData(0, 0, w, h).data; let m = 0, m2 = 0, k = 0; for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) { const i = (y * w + x) * 4, l = 4 * d[i] - d[i - 4] - d[i + 4] - d[i - 4 * w] - d[i + 4 * w]; m += l; m2 += l * l; k++; } return m2 / k - (m / k) * (m / k); };
  ok('straighten: blurry input is sharpened and full-resolution edge energy rises', rb.sharpened === true && lapVar(rb.canvas) > lapVar(rn.canvas) * 1.2, lapVar(rn.canvas).toFixed(2) + ' -> ' + lapVar(rb.canvas).toFixed(2));
  ok('straighten: bad corners give null', P.straighten(D, [[1, 1], [2, 2], [3, 3], [4, 4]]) === null); }
console.log(`pipeline tests: ${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
