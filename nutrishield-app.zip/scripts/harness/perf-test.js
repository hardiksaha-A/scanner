// Desktop PROXY for performance / memory of the image helpers (NOT a low-end Android measurement). Run: node --expose-gc scripts/harness/perf-test.js
require('./env'); const { C, decorate } = require('./env'), P = require('../../www/pipeline.js');
const mb = b => Math.round(b / 1048576), t = f => { const t0 = process.hrtime.bigint(); const r = f(); return [r, Number(process.hrtime.bigint() - t0) / 1e6]; };
const src = decorate(C.createCanvas(4000, 3000)), x = src.getContext('2d'); x.fillStyle = '#ccc'; x.fillRect(0, 0, 4000, 3000); x.fillStyle = '#111'; x.font = '40px sans-serif'; for (let y = 200; y < 2800; y += 70) x.fillText('Ingredients Potato Edible Vegetable Oil Seasoning Sugar Iodised Salt Milk Solids Spices', 300, y);
console.log('source 12 MP canvas ~', mb(4000 * 3000 * 4), 'MB in memory');
for (const [name, side] of [['normal phone', 3200], ['low-memory profile', 2400]]) {
  global.gc && global.gc(); const r0 = process.memoryUsage().rss; let peak = r0, ms = {};
  const [c, a] = t(() => P.toCanvas(src, side)); ms.resize = a; peak = Math.max(peak, process.memoryUsage().rss);
  const [m, b] = t(() => P.metrics(c)); ms.metrics = b; const [bx, d] = t(() => P.textRegion(c)); ms.region = d; const [sk, e] = t(() => P.estimateSkew(c)); ms.skew = e; peak = Math.max(peak, process.memoryUsage().rss);
  console.log(name.padEnd(20), `canvas ${c.width}x${c.height} (${mb(c.width * c.height * 4)} MB)`, Object.entries(ms).map(([k, v]) => k + ' ' + Math.round(v) + 'ms').join(', '), `| rss growth ${mb(peak - r0)} MB`);
}
