// Degraded / transformed versions of one source image (Buffer) for robustness runs. Source file is never modified.
const { C, decorate } = require('./env');
async function make(buf, kind) {
  const im = await C.loadImage(buf), W = im.width, H = im.height;
  const draw = (w, h, f) => { const c = decorate(C.createCanvas(w, h)), x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); f(x, w, h); return c; };
  if (kind === 'orig') return buf;
  if (kind === 'jpeg40') return decorate(draw(W, H, x => x.drawImage(im, 0, 0))).toBuffer('image/jpeg', 40);
  if (kind === 'half') return draw(Math.round(W / 2), Math.round(H / 2), (x, w, h) => { x.imageSmoothingQuality = 'high'; x.drawImage(im, 0, 0, w, h); }).toBuffer('image/png');
  if (kind === 'dark') return draw(W, H, x => { x.drawImage(im, 0, 0); x.fillStyle = 'rgba(0,0,0,.55)'; x.fillRect(0, 0, W, H); }).toBuffer('image/png');
  if (kind === 'rot90') return draw(H, W, (x, w, h) => { x.translate(w / 2, h / 2); x.rotate(Math.PI / 2); x.drawImage(im, -W / 2, -H / 2); }).toBuffer('image/png');
  if (kind === 'rot180') return draw(W, H, (x, w, h) => { x.translate(w / 2, h / 2); x.rotate(Math.PI); x.drawImage(im, -W / 2, -H / 2); }).toBuffer('image/png');
  if (kind === 'skew5') return draw(W, H, (x, w, h) => { x.translate(w / 2, h / 2); x.rotate(5 * Math.PI / 180); x.drawImage(im, -W / 2, -H / 2); }).toBuffer('image/png');
  throw new Error('variant ' + kind);
}
module.exports = { make, KINDS: ['orig', 'jpeg40', 'half', 'dark', 'rot90', 'rot180', 'skew5'] };
