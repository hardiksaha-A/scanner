// Parameter experiment: one pass (normal) per configuration on one image; reports recognised ingredients, quality score and CER against a reference.
require('./env'); const fs = require('fs'), ocr = require('./ocr-node'), L = require('./legacy'), SS = require('../../www/smartscan.js'), { trace } = require('./trace');
const img = process.argv[2], ref = fs.readFileSync(process.argv[3], 'utf8'), variant = process.argv[4] || 'orig';
const norm = s => String(s).toLowerCase().replace(/[^a-z0-9%.,()]+/g, ' ').trim();
function cer(a, b) { a = norm(a); b = norm(b); const m = a.length, n = b.length; let p = Array.from({ length: n + 1 }, (_, i) => i); for (let i = 1; i <= m; i++) { const c = [i]; for (let j = 1; j <= n; j++) c[j] = Math.min(p[j] + 1, c[j - 1] + 1, p[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); p = c; } return m ? p[n] / m : 0; }
const CONFIGS = JSON.parse(process.argv[5] || '[]');
(async () => {
  const V = require('./variants'); const buf = await V.make(fs.readFileSync(img), variant), src = await L.legacyBlobToCanvas(buf, 3200);
  for (const cfg of CONFIGS) {
    await ocr.configure(Object.assign({ tessedit_pageseg_mode: '3', user_defined_dpi: '' }, cfg.tess || {}));
    const t0 = Date.now(), r = await SS.read(src, { ocr: b => ocr.scan(b), maxPasses: 1, maxUp: cfg.maxUp, target: cfg.target, noDeskew: true }), a = SS.assess(r.text), tr = trace(r.text);
    console.log(JSON.stringify(cfg).padEnd(60), 'q=' + a.q, 'found=' + a.found, 'cov=' + Math.round(a.cov * 100), 'cer=' + cer(ref, r.text).toFixed(3), 'chars=' + r.text.length, Math.round((Date.now() - t0) / 100) / 10 + 's');
  }
  await ocr.close();
})();
