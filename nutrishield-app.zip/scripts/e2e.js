// End-to-end checks of the REAL app modules on real photos (no browser needed):
// barcode decoding, OCR + extraction, and the main promise: barcode, camera and upload give the SAME result.
const fs = require('fs'), path = require('path'), vm = require('vm');
const { L, loadCanvas, makeOcr, FakeCanvas } = require('./e2e-lib.js');
const FX = f => path.join(__dirname, '..', 'test-fixtures', f), W = f => path.join(__dirname, '..', 'www', f);
const Z = require('../www/vendor/zxing.min.js'), B = L.barcode, mk = (w, h) => new FakeCanvas(w, h);
const fails = []; const ok = (c, m) => { if (!c) fails.push(m); console.log((c ? '  ok    ' : '  FAIL  ') + m); };
const LOCAL = vm.runInNewContext('var window={};' + fs.readFileSync(W('localdb.js'), 'utf8') + ';window.LOCAL_PRODUCTS');
const CODE = '8901491367219', P = LOCAL[CODE], prods = Object.values(LOCAL);
const result = (ingText, nutr, drink) => { const ing = Engine.analyze(ingText, {}), nut = Nutrition.assess(nutr, { drink: !!drink }); return { fp: ing.fp, ing: ing.score, nut: nut && nut.score, overall: Nutrition.overall(ing.score, nut && nut.score) }; };
const viaBarcode = () => result(P.ingredients, P.nutrition);
const viaExtract = ex => result(ex.verified ? ex.identified.product.ingredients : ex.text, ex.verified ? ex.identified.product.nutrition : ex.nutrition);

(async () => {
  console.log('Barcode numbers');
  ok(B.isValidGtin(CODE) && !B.isValidGtin('8901491367218'), 'EAN-13 check digit');
  ok(B.isValidGtin('04252614') && B.normalize('04252614') === '042100005264', 'UPC-E is accepted and expanded to UPC-A');

  console.log('Barcode images');
  const real = await loadCanvas(FX('kurkure-barcode.png'));
  ok(B.decodePhoto(real, Z, mk) === CODE, 'real tilted photo with glare decodes');
  const rot = new FakeCanvas(real.height, real.width), rx = rot.getContext('2d'); rx.translate(rot.width / 2, rot.height / 2); rx.rotate(Math.PI / 2); rx.drawImage(real._c, -real.width / 2, -real.height / 2);
  ok(B.decodePhoto(rot, Z, mk) === CODE, 'same photo turned sideways decodes');
  const sm = await loadCanvas(FX('barcode-small-frame.png')); ok(B.decodePhoto(sm, Z, mk) === CODE, 'small barcode in a large photo decodes');
  const vid = new FakeCanvas(sm.width, sm.height); vid.getContext('2d').drawImage(sm._c, 0, 0); vid.videoWidth = sm.width; vid.videoHeight = sm.height;
  const live = [0, 1, 3].map(t => B.decodeFrame(vid, Z, t, mk)); ok(live.every(c => c === CODE), 'live camera frames (full resolution) decode the small barcode');

  console.log('Text extraction (noisy OCR of the whole pack)');
  const noisy = fs.readFileSync(FX('noisy-ocr.txt'), 'utf8'), X = L.extract;
  const own = X.process([noisy], []), ver = X.process([noisy], prods);
  ok(own.found >= 8 && !/lic|mrp|pvt|fssai|marketed|gurugram/i.test(own.text), 'only ingredients are kept; licence, address and MRP lines are dropped');
  ok(ver.verified && ver.identified.product.barcode === CODE, 'noisy text is recognised as the known product');
  const base = viaBarcode(), nv = viaExtract(ver);
  ok(JSON.stringify(base) === JSON.stringify(nv), 'noisy text scores the same as the barcode: ' + JSON.stringify(base));
  ok(X.nutrition('Energy 445 kcal\nProtein 7.8 g\nCarbohydrate 61 g\nTotal Fat 5.19\nSaturated Fat 96\nSodium 0') === null, 'impossible nutrition numbers are rejected');
  ok(X.sanitize({ kcal: 554, fat: 33.4, sat: 15.1, carbs: 57.5, sugars: 1.4, protein: 6, salt: 1.74 }) !== null, 'a correct nutrition table is accepted');
  ok(X.gtinsIn('foo\n8 901491 367219\nLic. No. 10012063000110', B.isValidGtin).join() === CODE, 'printed barcode digits are read, licence numbers are not');

  console.log('Photos through the real scanner (OCR)');
  const ocr = await makeOcr(); const run = async c => { const r = await SmartScan.read(c, { ocr: b => ocr.scan(b), layout: b => ocr.layout(b) }); return { r, ex: X.process([r.ing, r.nut, r.text], prods), own: X.process([r.ing, r.nut, r.text], []) }; };
  const back = await loadCanvas(FX('kurkure-back.png')), a = await run(back);
  ok(a.own.found >= 9 && !/lic|mrp|pvt|fssai/i.test(a.own.text), 'back-of-pack photo: ingredients only, ' + a.own.found + ' recognised, ' + Math.round(a.own.coverage * 100) + '% coverage');
  ok(a.ex.verified, 'back-of-pack photo is recognised as the known product (' + (a.ex.identified ? Math.round(a.ex.identified.sim * 100) + '%' : 'no match') + ')');
  ok(!a.own.nutrition || X.sanitize(a.own.nutrition), 'nutrition from the photo is either valid or left out');
  ok(JSON.stringify(viaExtract(a.ex)) === JSON.stringify(base), 'photo scan == barcode scan');
  const small = new FakeCanvas(Math.round(back.width * 0.7), Math.round(back.height * 0.7)); small.getContext('2d').drawImage(back._c, 0, 0, small.width, small.height);
  const b = await run(small);
  ok(b.ex.verified && JSON.stringify(viaExtract(b.ex)) === JSON.stringify(base), 'smaller / lower-quality camera-style copy gives the same result as the barcode');
  const bc = B.decodePhoto(real, Z, mk); ok(bc === CODE && JSON.stringify(result(LOCAL[bc].ingredients, LOCAL[bc].nutrition)) === JSON.stringify(base), 'barcode photo upload == barcode scan');
  await ocr.close();

  if (fails.length) { console.error('\nE2E FAILED (' + fails.length + '):\n - ' + fails.join('\n - ')); process.exit(1); }
  console.log('\ne2e ok: barcode, camera, upload and text paths agree');
})().catch(e => { console.error('E2E CRASHED', e); process.exit(1); });
