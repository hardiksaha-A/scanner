// Test harness: runs the real app modules in Node with a canvas + OCR stand-in (no browser needed).
const path = require('path'), fs = require('fs'), cv = require('@napi-rs/canvas');
const T = require('tesseract.js'); // load before the fake browser globals exist, so it runs in Node mode
const WWW = path.join(__dirname, '..', 'www');
class FakeCanvas { constructor(w, h) { this._c = cv.createCanvas(w || 1, h || 1); }
  get width() { return this._c.width; } set width(v) { this._c.width = v; }
  get height() { return this._c.height; } set height(v) { this._c.height = v; }
  getContext(t) { const x = this._c.getContext(t), un = a => (a instanceof FakeCanvas ? a._c : a);
    return new Proxy(x, { get(o, k) { const v = o[k]; if (k === 'drawImage') return (im, ...r) => o.drawImage(un(im), ...r); return typeof v === 'function' ? v.bind(o) : v; }, set(o, k, v) { o[k] = v; return true; } }); }
  toBlob(cb, type) { this._c.encode('png').then(buf => cb({ _buf: buf, size: buf.length }), () => cb(null)); } }
globalThis.document = { createElement: t => new FakeCanvas() };
globalThis.window = globalThis;
function load(rel) { delete require.cache[require.resolve(path.join(WWW, rel))]; return require(path.join(WWW, rel)); }
const L = {};
for (const m of ['barcode', 'nutrition', 'engine']) { L[m] = load(m + '.js'); }
globalThis.Barcode = L.barcode; globalThis.Nutrition = L.nutrition; globalThis.Engine = L.engine;
for (const m of ['extract', 'smartscan']) { try { L[m] = load(m + '.js'); } catch (e) { if (e.code !== 'MODULE_NOT_FOUND') throw e; } }
globalThis.SmartScan = L.smartscan; if (L.extract) globalThis.Extract = L.extract;
async function loadCanvas(file) { const img = await cv.loadImage(file), c = new FakeCanvas(img.width, img.height); c.getContext('2d').drawImage(img, 0, 0); return c; }
async function makeOcr() {
  const w = await T.createWorker('eng', 1, { langPath: path.join(WWW, 'vendor/tess/lang'), gzip: true, cacheMethod: 'none' });
  const lines = d => { const o = []; (d.blocks || []).forEach(b => b.paragraphs.forEach(p => p.lines.forEach(l => o.push({ text: l.text.trim(), bbox: l.bbox, baseline: l.baseline, conf: l.confidence, words: l.words.map(x => ({ text: x.text, bbox: x.bbox, conf: x.confidence })) })))); return o; };
  return { scan: async blob => (await w.recognize(blob._buf || blob)).data.text,
    layout: async blob => { const { data } = await w.recognize(blob._buf || blob, {}, { text: true, blocks: true }); return { text: data.text, lines: lines(data) }; }, close: () => w.terminate() };
}
module.exports = { L, loadCanvas, makeOcr, FakeCanvas, cv, WWW };
