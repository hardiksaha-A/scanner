// Consistency self-test: the same product read three ways must give the same Match ID and score.
const E = require('../www/engine.js');
const clean = 'INGREDIENTS: Cereal Products (67%) (Rice Meal (44%), Corn Meal (23%)), Edible Vegetable Oil*, *Seasoning (Spices and Condiments, Iodised Salt, Sugar, Flavour (Natural and Nature Identical Flavouring Substances), Black Salt, Tomato Powder, Acidity Regulators (330, 296, 334), Colour (160c), Maltodextrin), Gram Meal (0.5%). *As flavouring agent. To know the specific type of oil used match the symbol with batch number where denotes Palmolein and # denotes Rice Bran Oil. Nutrition Information Per 100 g Energy 554 kcal';
const noisy = clean.replace('INGREDIENTS:', 'INGR EDIENTS:').replace('Iodised', 'lodised').replace('Maltodextrin', 'Maltodextrn');
const off = 'Cereal products (rice meal 44%, corn meal 23%), edible vegetable oil, seasoning (spices & condiments, iodized salt, sugar, flavour, black salt, tomato powder, acidity regulators (330, 296, 334), colour (160c), maltodextrin), gram meal (0.5%)';
const R = [clean, noisy, off].map(t => E.analyze(t, {}));
const ok = R.every(r => r.fp && r.fp === R[0].fp && r.score === R[0].score);
if (!ok) { console.error('SELFTEST FAILED', R.map(r => [r.fp, r.score, r.unknown])); process.exit(1); }
console.log('selftest ok', R[0].fp, R[0].score, R[0].verdict, 'unknown:', R[0].unknown.join(',') || '-');
// Phase 2: new database entries are recognised and carry two real uses.
const t = E.analyze('Ingredients: Maida, Vanaspati, Sodium Tripolyphosphate (E451), Potassium Benzoate (E212), INS 330, Besan, Jeera, Hing, Sunset Yellow (E110), Yeast Extract', {});
const need = ['hydrogenated palm oil', 'benzoic acid', 'citric acid', 'asafoetida', 'sunset yellow', 'yeast extract'];
const miss = need.filter(n => !t.found.some(x => x.name === n));
if (t.unknown.length) miss.push('UNKNOWN:' + t.unknown.join(','));
if (miss.length) { console.error('SELFTEST FAILED: not recognised', miss, 'unknown', t.unknown); process.exit(1); }
const noUse = t.found.filter(x => !x.uses || x.uses.length < 2).map(x => x.name);
if (noUse.length) { console.error('SELFTEST FAILED: no uses for', noUse); process.exit(1); }
console.log('phase2 selftest ok, DB', E.DB_SIZE);
// Phase 4: the bundled offline product gives the same Match ID as the label read three ways.
const w = {}; new Function('window', require('fs').readFileSync(require('path').join(__dirname, '../www/localdb.js'), 'utf8'))(w);
const lp = w.LOCAL_PRODUCTS['8901491367219'];
const lr = lp && E.analyze(lp.ingredients, {});
if (!lp || !lr || lr.fp !== R[0].fp || lr.score !== R[0].score) { console.error('SELFTEST FAILED: offline product differs from label scan', lp && lr && [lr.fp, lr.score, R[0].fp, R[0].score]); process.exit(1); }
console.log('phase4 selftest ok: offline barcode and label scan agree', lr.fp, lr.score);
// Phase 6: a whole-pack OCR dump is reduced to ingredients + nutrition; a partly unreadable photo snaps to the known pack.
const dump = 'MARKETED BY: PepsiCo India Holdings. Kurkure is a Registered Trade Mark\nN1 - PepsiCo India Holdings Pvt. Ltd., Lic. No. 10012063000110.\nPROPRIETARY FOOD - NAMKEEN (15.1)\nINGREDIENTS: Cereal Products (67%) (Rice Meal (44%), Corn Meal (23%)), Edible Vegetable Oil*, *Seasoning (Spices and Condiments, Iodised Salt, Sugar), Gram Meal (0.5%).\n*As flavouring agent.\nNutrition Information Per 100 g\nEnergy 554 kcal\nProtein 6 g\nTotal Fat 33.4 g\nMRP Rs. 5/- (INCL. OF ALL TAXES)\nUNIT SALE PRICE';
const ft = E.focusText(dump);
if (/Lic\. No|MRP|MARKETED|UNIT SALE/i.test(ft) || !/Energy 554/.test(ft) || !/Rice Meal/.test(ft)) { console.error('SELFTEST FAILED: focusText', ft); process.exit(1); }
const garbled = 'As compared to previous Kurkure M, Fh\nINGREDIENTS: Cereal Products (6756) (Rice Meal py tog 3%), Edible Vegetable Oit Rarer ea aise Sal Sua, Favour (Natural Nay Ga, 2 32 lou (160) Makosestah ees';
const gr = E.analyze(garbled, {}), sn = E.snapKnown(garbled, gr, Object.values(w.LOCAL_PRODUCTS));
if (!sn || sn.barcode !== '8901491367219') { console.error('SELFTEST FAILED: snapKnown did not recognise the garbled pack'); process.exit(1); }
const other = E.analyze('INGREDIENTS: Wheat flour, sugar, palm oil, cocoa.', {});
if (E.snapKnown('Kurkure biscuit', other, Object.values(w.LOCAL_PRODUCTS))) { console.error('SELFTEST FAILED: false snap'); process.exit(1); }
console.log('phase6 selftest ok: whole-pack text trimmed, garbled pack recognised, no false snap');
// Phase 7: list rescue reads a badly garbled multi-column pack, flags it low-confidence, and never reports the allergy check as clear.
const gar = require('fs').readFileSync(require('path').join(__dirname, 'fixtures/maggi-garbled.txt'), 'utf8');
const rr = E.analyzeRobust(gar, { allergies: ['milk'] });
const has = n => rr.found.some(x => x.name === n);
if (!rr.rescued || rr.score === null || rr.confidence !== 'low' || rr.score > 69 || !has('spices') || !has('palm oil') || !has('citric acid') || rr.allergyStatus === 'clear') { console.error('SELFTEST FAILED: list rescue', rr.rescued, rr.score, rr.confidence, rr.found.map(x => x.name), rr.allergyStatus); process.exit(1); }
if (E.analyzeRobust(clean, {}).rescued) { console.error('SELFTEST FAILED: rescue ran on a clean label'); process.exit(1); }
console.log('phase7 selftest ok: garbled pack rescued (' + rr.found.length + ' known ingredients, low confidence, allergy not clear)');
// Phase 8: crop box geometry and the 'looks like a known pack' suggestion.
const Cr = require('../www/crop.js'), box = { x: 100, y: 100, w: 300, h: 200 };
const okC = Cr.hit(box, 102, 98, 30) === 'tl' && Cr.hit(box, 398, 302, 30) === 'br' && Cr.hit(box, 250, 101, 30) === 't' && Cr.hit(box, 250, 200, 30) === 'move' && Cr.hit(box, 20, 20, 30) === null;
const mv = Cr.move(box, 'move', 9999, 9999, 500, 400), rs = Cr.move(box, 'br', -9999, -9999, 500, 400), rl = Cr.move(box, 'tl', 20, 10, 500, 400);
if (!okC || mv.x + mv.w !== 500 || mv.y + mv.h !== 400 || rs.w !== 40 || rs.h !== 40 || rl.x !== 120 || rl.y !== 110 || rl.w !== 280 || rl.h !== 190) { console.error('SELFTEST FAILED: crop geometry', okC, mv, rs, rl); process.exit(1); }
const pool = Object.values(w.LOCAL_PRODUCTS);
const sug = n => E.suggestKnown({ found: n.map(x => ({ name: x })) }, pool);
if (!sug(['rice flour', 'corn', 'palm oil']) || !sug(['palm oil', 'salt', 'sugar']) || sug(['wheat flour', 'palm oil', 'salt']) || sug(['palm oil', 'rice flour', 'corn']) || sug(['rice flour', 'corn'])) { console.error('SELFTEST FAILED: suggestKnown'); process.exit(1); }
console.log('phase8 selftest ok: crop box geometry and known-pack suggestion');
// Phase 9: global names. Additives by E-number, and a French name, are recognised; new entries carry two uses.
const gl = E.analyze('Ingredients: acide citrique, E 952, E 492, E 927a, E 1520, E 941', {});
const sc = x => { const f = gl.found.find(y => y.name === x); return f ? f.score : null; };
const names = gl.found.map(x => x.name);
if (gl.unknown.length || !names.includes('citric acid') || !gl.found.some(x => x.score === 35 && /cyclamic/.test(x.name)) || !gl.found.some(x => x.score === 25 && x.hazard === 'high') || !gl.found.every(x => x.uses && x.uses.length === 2)) { console.error('SELFTEST FAILED: global names', names, gl.unknown); process.exit(1); }
console.log('phase9 selftest ok: global additive names recognised (' + names.length + ' of 6, DB ' + E.DB_SIZE + ')');
// Phase 10: the on-device reader's blocks become one text, line by line; Tesseract remains the fallback.
const NO = require('../www/native-ocr.js');
const nt = NO.textFrom({ text: 'x', blocks: [{ text: 'a', lines: [{ text: 'INGREDIENTS: Rice flour,' }, { text: 'Palm oil, Salt.' }] }, { text: 'Nutrition Information', lines: [] }, { text: '', lines: [] }] });
if (nt !== 'INGREDIENTS: Rice flour,\nPalm oil, Salt.\nNutrition Information' || NO.textFrom({ text: ' plain ' }) !== 'plain' || NO.textFrom(null) !== '' || NO.available()) { console.error('SELFTEST FAILED: native reader text', JSON.stringify(nt)); process.exit(1); }
const SS = require('../www/smartscan.js');
(async () => {
  global.Engine = E; // smartscan reads root.Engine
  const good = 'INGREDIENTS: Cereal Products (Rice Meal, Corn Meal), Edible Vegetable Oil, Salt, Sugar, Tomato Powder, Citric Acid, Maltodextrin, Spices.';
  const calls = []; const im = { width: 100, height: 100 };
  const r = await SS.read(im, { native: async (c, d) => { calls.push('n' + d); return good; }, ocr: async () => { calls.push('t'); return 'x'; }, progress: () => {} });
  if (calls[0] !== 'n0' || calls.includes('t') || r.label !== 'On-device text reader' || calls.length !== 1) { console.error('SELFTEST FAILED: reader order', calls, r.label); process.exit(1); }
  console.log('phase10 selftest ok: on-device reader is tried first and accepted when clean');
})();
// Phase 11: legal and safety wording in the app.
const page = require('fs').readFileSync(require('path').join(__dirname, '../www/index.html'), 'utf8');
const bad = [];
if (/Google Lens/.test(page)) bad.push('Google Lens wording');
if (/™/.test(page)) bad.push('trademark sign');
if (/id="pConsent"[^>]*checked/.test(page)) bad.push('consent box is pre-ticked');
if (!/About, Licences/.test(page) || !/Open Database Licence/.test(page) || !/not medical advice/i.test(page) || !/wipeDataBtn/.test(page)) bad.push('missing About, disclaimer or delete-data');
if (bad.length) { console.error('SELFTEST FAILED: ' + bad.join('; ')); process.exit(1); }
console.log('phase11 selftest ok: disclaimer, licences, delete-data present; consent not pre-ticked');
