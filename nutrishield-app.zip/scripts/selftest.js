// Consistency self-test: the same product read three ways must give the same Match ID and score.
const E = require('../www/engine.js');
const clean = 'INGREDIENTS: Cereal Products (67%) (Rice Meal (44%), Corn Meal (23%)), Edible Vegetable Oil*, *Seasoning (Spices and Condiments, Iodised Salt, Sugar, Flavour (Natural and Nature Identical Flavouring Substances), Black Salt, Tomato Powder, Acidity Regulators (330, 296, 334), Colour (160c), Maltodextrin), Gram Meal (0.5%). *As flavouring agent. To know the specific type of oil used match the symbol with batch number where denotes Palmolein and # denotes Rice Bran Oil. Nutrition Information Per 100 g Energy 554 kcal';
const noisy = clean.replace('INGREDIENTS:', 'INGR EDIENTS:').replace('Iodised', 'lodised').replace('Maltodextrin', 'Maltodextrn');
const off = 'Cereal products (rice meal 44%, corn meal 23%), edible vegetable oil, seasoning (spices & condiments, iodized salt, sugar, flavour, black salt, tomato powder, acidity regulators (330, 296, 334), colour (160c), maltodextrin), gram meal (0.5%)';
const R = [clean, noisy, off].map(t => E.analyze(t, {}));
const ok = R.every(r => r.fp && r.fp === R[0].fp && r.score === R[0].score);
if (!ok) { console.error('SELFTEST FAILED', R.map(r => [r.fp, r.score, r.unknown])); process.exit(1); }
console.log('selftest ok', R[0].fp, R[0].score, R[0].verdict, 'unknown:', R[0].unknown.join(',') || '-');
// Phase 2: new database entries are recognised and carry two real uses.
const t = E.analyze('Ingredients: Maida, Vanaspati, Sodium Tripolyphosphate (E451), Potassium Benzoate (E212), INS 330, Besan, Jeera, Hing, Sunset Yellow (E110), Yeast Extract', {});
const need = ['hydrogenated palm oil', 'benzoic acid', 'citric acid', 'asafoetida', 'sunset yellow', 'yeast extract'];
const miss = need.filter(n => !t.found.some(x => x.name === n));
if (t.unknown.length) miss.push('UNKNOWN:' + t.unknown.join(','));
if (miss.length) { console.error('SELFTEST FAILED: not recognised', miss, 'unknown', t.unknown); process.exit(1); }
const noUse = t.found.filter(x => !x.uses || x.uses.length < 2).map(x => x.name);
if (noUse.length) { console.error('SELFTEST FAILED: no uses for', noUse); process.exit(1); }
console.log('phase2 selftest ok, DB', E.DB_SIZE);
// Phase 4: the bundled offline product gives the same Match ID as the label read three ways.
const w = {}; new Function('window', require('fs').readFileSync(require('path').join(__dirname, '../www/localdb.js'), 'utf8'))(w);
const lp = w.LOCAL_PRODUCTS['8901491367219'];
const lr = lp && E.analyze(lp.ingredients, {});
if (!lp || !lr || lr.fp !== R[0].fp || lr.score !== R[0].score) { console.error('SELFTEST FAILED: offline product differs from label scan', lp && lr && [lr.fp, lr.score, R[0].fp, R[0].score]); process.exit(1); }
console.log('phase4 selftest ok: offline barcode and label scan agree', lr.fp, lr.score);
