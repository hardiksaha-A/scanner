# Fixtures
- `chips.jpg` - user-supplied back-of-pack photo, 220x350 px (very low resolution: small print is only partly legible).
- `chips.reference.txt` - PROVISIONAL, UNVERIFIED transcription (read by the assistant from the low-resolution photo; nutrition table values are not legible and are omitted).
  Use it for indicative character-error-rate only. It must be replaced by a manually verified reference before any accuracy claim.
- `maggi-garbled.txt` - existing garbled-text fixture.
Real-label accuracy remains UNVERIFIED until the labelled photo set is supplied.
