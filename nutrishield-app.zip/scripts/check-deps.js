// Guard: fails if an advertising/analytics/crash/cloud SDK is added, or if app code references a network host that is not approved.
// Adding any of these needs separate owner approval AND an update to the privacy documents, Play Data safety and docs/INDIA_DATA_FLOW.
const fs = require('fs'), path = require('path');
const DENY = /(admob|google-mobile-ads|play-services-ads|firebase|crashlytics|analytics|sentry|bugsnag|mixpanel|amplitude|segment|appsflyer|adjust|branch|onesignal|applovin|unity-?ads|ironsource|facebook|fbsdk|flurry|datadog|posthog|clarity)/i;
const ALLOWED_HOSTS = new Set(['world.openfoodfacts.org', 'openfoodfacts.org', 'www.w3.org', 'github.com']); // links shown as text or SVG namespaces
const bad = [];
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
for (const sec of ['dependencies', 'devDependencies', 'optionalDependencies']) for (const n of Object.keys(pkg[sec] || {})) if (DENY.test(n)) bad.push('denied dependency: ' + n);
if (fs.existsSync('package-lock.json')) { const lock = JSON.parse(fs.readFileSync('package-lock.json', 'utf8')); for (const k of Object.keys(lock.packages || {})) if (k && DENY.test(k.replace(/^.*node_modules\//, ''))) bad.push('denied package in lockfile: ' + k); }
const hosts = new Set();
(function walk(d) { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) { if (f !== 'vendor' && f !== 'lang') walk(p); } else if (/\.(js|html)$/.test(f)) {
  const t = fs.readFileSync(p, 'utf8'); for (const m of t.matchAll(/https?:\/\/([a-z0-9.-]+)/gi)) { hosts.add(m[1].toLowerCase()); if (!ALLOWED_HOSTS.has(m[1].toLowerCase())) bad.push('unapproved host ' + m[1] + ' in ' + p); } } } })('www');
if (bad.length) { console.error('CHECK-DEPS FAILED:\n - ' + Array.from(new Set(bad)).join('\n - ')); process.exit(1); }
console.log('check-deps ok: no denied SDK; hosts referenced in app code: ' + Array.from(hosts).sort().join(', '));
