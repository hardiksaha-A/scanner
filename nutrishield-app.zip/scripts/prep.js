// Copies the OCR engine (tesseract.js + core + English data) into www/vendor/tess and checks it is complete.
const fs = require('fs'), nm = 'node_modules', out = 'www/vendor/tess';
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out + '/core', { recursive: true }); fs.mkdirSync(out + '/lang', { recursive: true });
fs.copyFileSync(nm + '/tesseract.js/dist/tesseract.min.js', out + '/tesseract.min.js');
fs.copyFileSync(nm + '/tesseract.js/dist/worker.min.js', out + '/worker.min.js');
for (const f of fs.readdirSync(nm + '/tesseract.js-core'))
  if (/^tesseract-core.*lstm.*\.(js|wasm)$/.test(f)) fs.copyFileSync(nm + '/tesseract.js-core/' + f, out + '/core/' + f);
fs.copyFileSync(nm + '/@tesseract.js-data/eng/4.0.0_best_int/eng.traineddata.gz', out + '/lang/eng.traineddata.gz');
fs.writeFileSync(out + '/lang/eng.lstm.bin', require('zlib').gunzipSync(fs.readFileSync(out + '/lang/eng.traineddata.gz'))); // plain copy: survives Android packaging
const need = [['tesseract.min.js', 50e3], ['worker.min.js', 50e3], ['core/tesseract-core-lstm.wasm.js', 1e6], ['core/tesseract-core-simd-lstm.wasm.js', 1e6], ['lang/eng.traineddata.gz', 1e6], ['lang/eng.lstm.bin', 5e6]];
const bad = need.filter(([f, min]) => !fs.existsSync(out + '/' + f) || fs.statSync(out + '/' + f).size < min);
if (bad.length) { console.error('prep FAILED - missing or too small:', bad.map(b => b[0]).join(', ')); process.exit(1); }
console.log('prep ok', fs.readdirSync(out + '/core'));
