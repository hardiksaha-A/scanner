// Pregnancy and Senior mode rules: each case states what the mode must say about a product.
const E = require('../www/engine.js'), N = require('../www/nutrition.js'), A = require('../www/advice.js');
function run(text, mode) {
  const ing = E.analyze(text, {}), parsed = N.parseNutrition(text);
  const nut = parsed && parsed.count >= 2 ? N.assess(parsed, { drink: false }) : null;
  const adv = A.evaluate({ ing, nut, product: null, profile: { mode }, overall: ing.score, hazard: ing.hazard, serving: '' });
  return adv ? adv.groups.find(g => g.id === mode).status : 'none';
}
const CASES = [
  ['pregnancy', 'Ingredients: Carbonated water, sugar, caffeine, colour (150d).', 'limit'],
  ['pregnancy', 'Ingredients: Water, alcohol, sugar.', 'avoid'],
  ['pregnancy', 'Ingredients: Unpasteurised milk, salt, cultures.', 'avoid'],
  ['pregnancy', 'Ingredients: Swordfish, olive oil, salt.', 'avoid'],
  ['pregnancy', 'Ingredients: Water, sugar, saccharin.', 'avoid'],
  ['pregnancy', 'Ingredients: Carbonated water, sugar, taurine, caffeine, inositol.', 'limit'],
  ['pregnancy', 'Ingredients: Chicken liver pate, butter, salt.', 'limit'],
  ['pregnancy', 'Ingredients: Whole grain rolled oats (100%).', 'ok'],
  ['pregnancy', 'Ingredients: Wheat flour, milk, vitamin A, iron, folic acid.', 'ok'],
  ['older', 'Ingredients: Potato, edible vegetable oil, salt.\nEnergy 520 kcal\nFat 32 g\nSaturated fat 14 g\nCarbohydrate 50 g\nSugars 1 g\nProtein 6 g\nSalt 3.2 g', 'limit'],
  ['older', 'Ingredients: Carbonated water, sugar, phosphoric acid, caffeine.', 'limit'],
  ['older', 'Ingredients: Whole wheat flour, maltitol, sucralose, oats.', 'limit'],
  ['older', 'Ingredients: Salt, potassium chloride.', 'limit'],
  ['older', 'Ingredients: Water, alcohol, sugar.', 'limit'],
  ['older', 'Ingredients: Sugar, liquorice, wheat flour.', 'limit'],
  ['older', 'Ingredients: Whole grain rolled oats (100%).', 'ok'],
  ['adult', 'Ingredients: Carbonated water, sugar, caffeine.', 'ok']
];
const bad = CASES.map(([m, t, want]) => { const got = run(t, m); return got === want ? null : m + ': "' + t.slice(13, 55) + '..." expected ' + want + ' got ' + got; }).filter(Boolean);
console.log('modes: ' + (CASES.length - bad.length) + '/' + CASES.length + ' cases pass');
bad.forEach(b => console.log(' - ' + b));
if (bad.length) process.exit(1);
