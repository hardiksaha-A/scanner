// CI gate: reports whether the in-app legal documents are production-ready. It never marks a draft as ready.
const fs = require('fs'), L = require('../www/compliance/legal.js');
const ready = L.isProductionReady(), n = L.placeholderCount();
const msg = ready ? 'Legal documents: approval record present and no placeholders.' : `Legal documents are DRAFT: ${n} [REQUIRED INPUT] placeholders outstanding, approved=${L.STATUS.approved}. Builds are labelled NOT FOR PRODUCTION.`;
console.log(msg);
if (process.env.GITHUB_OUTPUT) fs.appendFileSync(process.env.GITHUB_OUTPUT, `ready=${ready}\nsuffix=${ready ? '' : '-DRAFT-LEGAL-NOT-FOR-PRODUCTION'}\ncount=${n}\n`);
if (process.env.GITHUB_STEP_SUMMARY) fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY, `### Legal documents\n${msg}\n`);
if (process.env.REQUIRE_LEGAL_READY === 'true' && !ready) { console.error('::error::REQUIRE_LEGAL_READY is true but the legal documents are not production-ready.'); process.exit(1); }
