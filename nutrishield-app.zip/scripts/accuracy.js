// Labelled test set: each label must land in its expected band, with high coverage and the right allergy status.
// The texts are representative formulations typed from common packs; add your own photographed labels to labels.json.
const E = require('../www/engine.js'), L = require('./labels.json');
const band = s => s >= 65 ? 'good' : s >= 40 ? 'okay' : 'poor';
let pass = 0, cov = 0; const bad = [];
for (const l of L) {
  const r = E.analyze(l.t, { allergies: l.allergy ? [l.allergy] : [] });
  cov += r.coverage;
  const why = [];
  if (r.score === null) why.push('no score');
  else if (l.band === 'good' ? r.score < 65 : l.band === 'poor' ? r.score > 55 : (r.score < 35 || r.score > 78)) why.push('score ' + r.score + ' vs ' + l.band);
  if (r.coverage < 0.75) why.push('coverage ' + Math.round(r.coverage * 100) + '% unknown: ' + r.unknown.join('/'));
  if (l.algStatus && r.allergyStatus !== l.algStatus) why.push('allergy ' + r.allergyStatus + ' vs ' + l.algStatus);
  why.length ? bad.push(l.n + ': ' + why.join('; ')) : pass++;
}
console.log(`accuracy: ${pass}/${L.length} labels pass, average coverage ${Math.round(cov / L.length * 100)}%`);
if (process.argv.includes('--show') || pass < L.length) bad.forEach(b => console.log(' - ' + b));
require('fs').writeFileSync(require('path').join(__dirname, '../www/accuracy-report.js'), 'window.ACCURACY=' + JSON.stringify({ pass, total: L.length, coverage: Math.round(cov / L.length * 100) }) + ';\n');
module.exports = { pass, total: L.length };
if (pass < L.length && require.main === module) process.exit(1);
