# Scanner, OCR, image quality and barcode - implementation report

Scope: live scanner snap, camera photo, gallery upload, barcode lookup. Scoring formulas, thresholds, allergen rules and assessment logic were NOT changed
(`engine.js`, `nutrition.js`, `advice.js`, `ingredients.js` are byte-identical to the supplied source and still pass the hash-pinned compliance check).

**Verification status:** Node/desktop only (Tesseract.js; ML Kit exists only on a device). **No Android build and no Android device test were performed.**
Real-label accuracy is UNVERIFIED: the only photo so far is one 220x350 px pack back (`scripts/fixtures/chips.jpg`) with a provisional, unverified reference.

## 1. Root causes and what was done

| # | Root cause (confirmed by code reading and/or a run) | Change | Files |
|---|---|---|---|
| 1 | Live snap pre-cropped the video frame (6% / 12% / 88% x 76%) and the crop dialog then inset again (6% / 10%) | Whole frame goes to the dialog; dialog default box = automatic text region with >= 6% padding (whole image minus 1.5% when no text region is found) | `index.html`, `pipeline.js` |
| 2 | Default (low) canvas smoothing on downscale; photo decoded without guaranteed EXIF handling | One decode (`createImageBitmap` with `from-image` orientation where supported) and step-down high-quality downscale; never upscales; the user's file is never modified or re-saved | `pipeline.js`, `index.html` |
| 3 | OCR pass order depended on the wall clock (50 s / 100 s gates) | Pass order is fixed. The 100 s budget remains only as a safety net and now marks the result "partial" and tells the user | `smartscan.js` |
| 4 | Tesseract PSM / DPI unset | **Tested, not changed:** PSM 6/4, DPI 300 and lower upscale caps gave no gain (PSM 6 was clearly worse) on the one available photo (`baseline/` experiment log) | - |
| 5 | ML Kit returned nutrient names and numbers as separate lines | Rebuild rows from line bounding boxes, only for nutrient rows; identical to the old output when boxes are missing. Real plugin output must be confirmed on a device | `native-ocr.js` |
| 6 | Parser took the first number on a line; no plausibility checks | New column-aware reader (separate file, identical results on all single-column corpus texts); see section 2 | `nutrition-reader.js` |
| 7 | Valid UPC-E codes rejected; keys not normalised | `Barcode.normalize` for EAN-8, UPC-A, UPC-E, EAN-13, GTIN-14; canonical GTIN-13 key; old cache / saved-label / local keys are still found through aliases | `barcode.js`, `index.html` |
| 8 | Live barcode frame squashed to 640x360 and a reader created every 450 ms | Aspect-preserving frame (max 960 wide), one reader reused | `index.html` |
| 9 | Silent replacement of scanned text by a bundled product | Never silent: both records shown; default "Keep my scan"; replaced only on "Use offline record" | `index.html`, `pipeline.js` |
| 10 | Low-memory phones | `Pipeline.limits`: 2400 px photo / 1800 px OCR target when `deviceMemory <= 3` or `hardwareConcurrency <= 4`; temporary canvases released | `pipeline.js`, `smartscan.js` |
| 11 | No way to find where results diverge | Six-stage trace (raw, normalised, ingredients, nutrition, allergens, score) and comparator; in-memory `window.__scanTrace` in the app (never stored) | `scripts/harness/*`, `index.html` |

Added: image quality tips (blur / dark / glare / small; advisory, never blocks), small-angle deskew pass (only when a clear tilt is measured),
ImageCapture maximum photo size and continuous focus (device dependent), automatic text-region crop.

Not done (needs your approval or a device): barcode detection before the crop step
(it would send every back-of-pack photo to a lookup instead of the ingredient read); OpenCV or any new dependency; any allergen-rule change (see section 4).

## 2. Parser corrections (each differs from the original reader; tested in `scripts/harness/parser-test.js`)
| Case | Original | Now |
|---|---|---|
| "Per serve / Per 100 g" columns, serve first | took the per-serve number | per-100 g column chosen by header |
| "%RDA" column | could return the percentage | skipped |
| "Protein 14% 7.2 g" | 14 | 7.2 |
| "3O.4 g" (letter O) | 3 | 30.4, logged as a correction |
| per-serve-only table | used as per-100 g | not used, flagged `per-serve-only` |
| labels block then numbers block | 1 of 4 values | paired in order only when counts match, flagged |
| implausible values (sat > fat, sugars > carbs, macros > 100 g, kcal far from macros) | silent | numbers kept as read, a "check the nutrition numbers" note is shown |
| serving size | ignored | read ("30 g"), not used in scoring |

Unintended-change gates: corpus equivalence (28 label/demo texts + bundled products + synthetic tables): nutrition parse and `Nutrition.assess` scores identical;
`golden-test.js`: ingredients, nutrition, Match ID, allergen warnings, score and verdict identical through the new text path (28/28).
`analyze` vs `analyzeRobust` are identical wherever `analyze` already scores (28/28), so the barcode route keeps `analyze` and no assessment entry point changed.

## 3. Barcode normalisation
`isValidGtin` keeps its old meaning. `normalize()` accepts EAN-8, UPC-A, UPC-E (number system 0/1, expanded and check-digit verified), EAN-13, GTIN-14.
Canonical key = GTIN-13 (12-digit and 8-digit codes zero-padded; GTIN-14 with indicator 0 maps to its GTIN-13; other GTIN-14 keep their own key).
An 8-digit code valid both ways stays EAN-8 unless the scanner reports UPC-E. Lookups try the canonical key, then every older form (as scanned, 12-digit, 14-digit, UPC-E).
Open Food Facts: the canonical key is requested first, then the digits as scanned. **Compatibility with live Open Food Facts could not be tested** (no network access to it here).

## 4. Allergen robustness (measurement only, rules unchanged)
See `baseline/allergen-robustness.json`. Existing engine: clean wording 10/10, OCR character errors 8/8, spelling / local names 9/9,
**cut-off words 0/4, and non-English / Devanagari ingredient words 1/8** (Hindi-script milk, wheat, peanut and French / German milk were not flagged).
The 100% target applies only to the clean verified set. Improving truncated-word or multilingual detection changes allergen behaviour and needs your approval.

## 5. Performance and memory (desktop proxy, not Android)
12 MP source: normal profile 3200x2400 canvas (29 MB), resize 155 ms, metrics 135 ms, text region 131 ms, skew 204 ms, RSS growth 118 MB;
low-memory profile 2400x1800 (16 MB), resize 126 ms, metrics 75 ms, region 85 ms, skew 69 ms, RSS growth 38 MB.
Low-end Android timing, memory, crashes and freezes: NOT MEASURED (see `ANDROID_DEVICE_TEST_PLAN.md`).

## 6. Before / after (Node, Tesseract only, one 220x350 px photo, provisional reference)
Original code path copied exactly (`harness/legacy.js`) vs the new path (`harness/newpath.js`). "found" = ingredients recognised, "unk" = unrecognised tokens. Logs and JSON are in `baseline/`.

| Route | Repeats (before / after) | Stable across repeats | Raw text | Ingredients found / unknown | Raw-text error rate vs provisional reference* |
|---|---|---|---|---|---|
| camera | 10 / 10 | yes / yes | same | 1 / 20 -> 1 / 20 | 1.666 -> 1.666 |
| gallery | 10 / 10 | yes / yes | same | 1 / 20 -> 1 / 20 | 1.666 -> 1.666 |
| live snap | 10 / 3 | yes / yes | differed -> **same as camera** | 0 / 15 -> 1 / 20 | 1.501 -> 1.666 |
| crop dialog (untouched default box) | 10 / 3 | yes / yes | differed -> **same as camera** | 0 / 11 -> 1 / 20 | 1.480 -> 1.666 |

*Values above 1 mean the output is mostly wrong; the reference is provisional and unverified, so this is indicative only.

What this shows, and what it does not:
- **Consistency improved:** before, live snap and the crop dialog gave different raw text, ingredients and error rates from camera/gallery of the same image (cause: the double pre-crop). After, all four routes give identical raw text and identical stage hashes at every stage. Every route was stable across repeats on this machine.
- **No OCR accuracy gain on this image:** the photo is too small to read reliably. All routes still end with "Not enough recognised ingredients to score". The numeric error rate for live/dialog is "worse" only because the old pre-crop happened to discard some text; it is not a real regression and not a real gain.
- **Variants** (jpeg 40%, half size, dark, rotated 90/180, 5 degree skew): only jpeg40 and half-size were completed before; jpeg40 gave identical results before and after (error rate 1.243). The rest were not completed. Not claimed.
- ML Kit (the main reader on a phone), real-label accuracy, 10-repeat live/dialog on the new path (3 done), Android build and device behaviour: **not verified**.

## 7. Crop dialog - portion 1 (rotate and lossless crop)
- Added ⟲ 90° / ⟳ 90° buttons. `Pipeline.rotate90` moves pixels exactly (no interpolation); tests: every pixel lands in the right place, 4 turns = original, turn + turn back = identical on a rendered text page.
- "Read selected area" now uses `Pipeline.cropExact`: the box is rounded OUTWARD to whole pixels and copied 1:1 from the full-size photo, so it cannot blur or trim an edge pixel (before, fractional source rectangles were resampled). Tests: whole-pixel crop identical, outward rounding, clamping.
- After a turn the preview and the automatic starting box are recomputed for the new orientation.
- NOT verified: the dialog's touch behaviour in a real browser or on Android (no browser was available here); only the pixel functions are tested. Four-corner perspective was added in portion 3 (section 9).

## 8. Crop dialog - portion 2 (zoom and pan)
- Zoom: pinch, mouse wheel, or ＋ / － buttons (1x to 8x). Pan: two-finger drag while zoomed, or tap ✋ Move and drag with one finger. Single-finger drag still draws or resizes the box.
- The box is kept in photo coordinates, so zooming or panning never moves or resizes it; the preview is drawn straight from the full-size photo, so zoomed views show real detail. Handle grab size stays constant on screen.
- Tests: 6 view-maths tests (zoom keeps the point under the finger fixed, 8x cap, pan clamped on 2000 random views) and 11 tests that run the REAL `cropDialog` source against a fake DOM (zoom, pinch, pan, wheel, rotate, crop, cancel, drag still draws a new box). These check logic and runtime errors only.
- NOT verified: real touch feel, pinch smoothness and layout on a phone or in a real browser. Please try it on your device.

## 9. Crop dialog - portion 3 (four-corner perspective, clarity)
- New **⬚ Corners** button: four draggable corners (drag the nearest one; zoom/pan still work). "Read selected area" then straightens the shape to a rectangle. Crossed, concave or collapsed corners are refused with a message and the dialog stays open.
- Resolution is kept: the result is sized from the longer of each pair of corner edges (no downscale; capped at 10 MP). Untouched axis-aligned corners take the exact 1:1 pixel copy path, not the resampler. Only the region the corners cover is read into memory.
- Geometry test (distortion coded independently with Heckbert's projection): 9 marker dots return to their grid positions within 1.5 px.
- **Synthetic OCR measurement** (`harness/perspective-ocr.js`, rendered text, Tesseract; NOT real labels), error rate vs truth text: clean page 0.003; strongly skewed uncorrected 0.079 -> corrected 0.003; mild skew 0.008 -> 0.003.
- **Sharpening, measured, then limited:** a 3x3 sharpen did nothing measurable, so it was replaced by a radius-aware unsharp mask (amount 1.5, radius 3). On blurred, skewed synthetic text (blur 1.2 / 2 / 3 / 4 px): corrected only 0.003 / 0.087 / 0.497 / 0.735; corrected + sharpen 0.003 / 0.032 / 0.262 / 0.709. It is applied ONLY when the straightened result is measured as blurry (the blur metric flagged the 2 px and 3 px cases and not the 1.2 px case), only on the perspective path, and it never made a case worse. It cannot recover detail that is not in the photo (4 px blur stays poor). Not tested on real photos.
- Tests: pipeline 41 and dialog 17 (real dialog code, fake DOM). Not verified: real touch behaviour, speed on a low-end phone (the warp loop runs per output pixel; time it on the device plan), results on real curved or glossy packs (perspective correction does not flatten curved packs).
