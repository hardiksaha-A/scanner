# NutriShield India — Legal-to-Technical Gap Matrix (post-implementation)
Status key: **IT** implemented and tested (Node and/or desktop Chromium; not on Android). **IU** implemented, not verified in the real build. **NI** not implemented. **CC** counsel required. Not legal advice; India = Category 3.

| ID | Requirement | Source | Implementation / evidence | Gap remaining | Status | Counsel? | Test |
|---|---|---|---|---|---|---|---|
| G-01 | Under-18 = child; exact age; no 13/16 threshold | DPDP s.2(f), s.9; report §3, 15.3 | `age.js`, `rules.js`; 3 self-declared states; DOB helper (tested, not used by UI) | Self-declaration is unverified by design | IT | Y: evidence level | compliance: age ×5, rules |
| G-02 | Verifiable parent consent (Rule 10) | s.9; Rule 10 | `verifier.js` disabled stub; gate blocks child health regardless | No method; **not operational**; child profile stays locked | IT (interface only) | **Y** | verifier test; e2e child |
| G-03 | Consent evidence, version, timestamp, withdrawal | ss.4, 6; Rule 3; SPDI r.5 | `consent.js` ledger; UI | Legal sufficiency of in-app form; retention period unset | IT | Y | consent ×3 |
| G-04 | Health data optional, separate, scanning w/o profile | SPDI r.3, 5; report §11.1 | Separate unticked consent; optional nickname | Legal review | IT | Y | e2e adult/child |
| G-05 | Child-safe defaults; no tracking/ads | s.9(2)-(3); Play Families | Gate; `check-deps.js` in verify | Play declarations not done | IT / NI(Play) | N | check-deps; gate |
| G-06 | Deletion across stores; withdrawal cascade | SPDI r.5; DPDP s.8; report §15.9 | `wipe.js`, `registry.js`, settings | WebView native cache, OFF/Google copies, clipboard cannot be deleted (listed in UI). Android WebView not tested | IT (Chromium) / IU (Android) | N | wipe ×2; e2e 6-store check |
| G-07 | Category retention; no blanket period; Rule 8(3) gate | Rules 6(1)(e), 8; CERT-In; SPDI r.5 | `retention.js` all null + validator | Periods await counsel; nothing auto-expires | IT (framework) | **Y** | retention ×2 |
| G-08/09 | Non-misleading allergen states | FSSAI; CPA; report §9.1 | `allergen.js`; index.html | Heuristic thresholds need field validation (NS-36) | IT | N | allergen ×11; e2e |
| G-10 | MDSW boundary | MDR 2017; CDSCO Jul 2026 | Wording unchanged; no new clinical claims | No kill-switch for condition/pregnancy/senior advice | **NI** | **Y** | — |
| G-11 | In-app Privacy/Terms, separate versions, per-document re-acceptance | SPDI r.4; Play | `legal.js` (`VERSIONS`, `HISTORY`), `consent.js` `acceptance()`; ledger stores `docVersions`; app blocked until both current versions are accepted; only the changed document is re-asked; earlier records kept | Drafts; 17 placeholders; legal effect of the re-acceptance flow not reviewed | IT (drafts) | **Y** | legal; consent versions; e2e 2b |
| G-12 | Policy matches behaviour | Play Data safety; SPDI r.4 | Draft discloses barcode + category + ML Kit uncertainty | Data safety form not done; ML Kit unverified | IT / NI | Y | legal test |
| G-13 | Local data encryption | SPDI r.8 | — (Privacy Policy draft-0.2.0 discloses that NutriShield adds no encryption) | Plaintext localStorage: **OPEN security issue**; encrypted-storage plugin needs approval | **NI** (needs approval) | Y | — |
| G-14 | Country not from locale only | report §11.7, 15.3 | Country selector and country storage removed: nothing in the app used country; stored values are purged | Non-India users still not gated. If country returns it needs a real purpose, a policy update and its own test | NI (feature removed) | Y | compliance (purge); e2e 2c/2d |
| G-15 | No health/OCR in diagnostics | Rule 6(1)(e); report §15.7 | — | Not audited/changed: console error paths unchanged | **NI** | Y | — |
| G-16 | CSP | Security | img-src OFF removed | unsafe-inline/eval remain | Partial | N | ui CSP test |
| G-17 | Supply chain | Security | CLI → devDependencies | — | IT | N | npm audit 0 |
| G-18 | No silent plugin drop | Disclosure accuracy | `build.yaml` | Not run in CI | IU | N | yaml/bash -n only |
| G-19 | AAB, versioning, Play | Play | `build.yaml` bundleRelease, jarsigner | Not run; no keystore; Play declarations not done | IU | N | — |
| G-20 | Score words match bands | Accuracy | words = 75/50/25 bands; scoring hashes unchanged | Colour 70/45 mismatch (NS-37) | IT | N | ui + scoring tests |
| G-21 | Data minimisation: no unused contact data | DPDP s.6/s.8; SPDI r.5 | Email and mobile fields removed; email, mobile and country purged from stored profiles; Privacy Policy states they are not collected | Counsel to confirm wording | IT | Y | compliance (purge x3 ages); e2e 2d |
