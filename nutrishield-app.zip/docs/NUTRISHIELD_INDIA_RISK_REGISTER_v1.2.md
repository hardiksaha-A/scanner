# NutriShield — India Product & Legal Risk Register

**As of:** 25 November 2026  
**Rating method:** Severity estimates reflect likely legal, safety, platform and launch impact. They are prioritisation tools, not statutory risk scores.

| ID | Risk | Severity | Legal / policy basis | NutriShield exposure | Required mitigation / owner action | Status / uncertainty |
|---|---|---|---|---|---|---|
| IN-01 | DPDP phased commencement misread; child obligations assumed already in force or postponed | Critical | DPDP Act ss.2, 3–17, 44(2); G.S.R.843(E), 13 Nov 2025 | Product may ship without a correct transition plan | Maintain two effective-dated India regimes; counsel to verify transition; build May 2027 child flow ahead of time | Dates verified from official Gazette; repeal/transition effects require counsel |
| IN-02 | Child personal data processed without verifiable parent consent after 13 May 2027 | Critical | DPDP Act s.9; DPDP Rules r.10 | Under-18 profiles, scans, histories, allergies and health settings | Under-18 parent approval gate before processing; adult identity/age due diligence; consent evidence; re-consent/deletion decision for legacy profiles | Rule 10 does not prescribe a universal parent-child relationship proof method |
| IN-03 | Checkbox or Play age signal mistaken for statutory parent verification | High | DPDP Rules r.10; Play Age Signals terms | False/unauthorised adult could approve a child profile | Use counsel-approved verification provider/method; no checkbox-only method; retain minimal evidence | Accepted operational method and relationship proof unresolved |
| IN-04 | Current SPDI rules breached by collection/use of health or allergy data | Critical | IT Act s.43A; SPDI Rules rr.3–8 | Allergy, medical conditions, pregnancy, medical history | Privacy policy; prior specific electronic/written consent; purpose limitation; third-party permissions; transfer safeguards; security; grievance officer; deletion | Whether client-only storage is handled by operator requires legal opinion |
| IN-05 | Local-only storage incorrectly treated as blanket exemption | High | DPDP Act s.3; SPDI Rules definitions and handling scope | App logic itself collects/uses local profile data; OS backup/SDKs may transmit | Obtain counsel scope opinion based on data map, APK/SDK review, network trace, operator role | Application to pure on-device processing remains fact-specific |
| IN-06 | Child data processed in ways detrimental to well-being | Critical | DPDP Act s.9(2), scheduled 13 May 2027 | Nutrition scores, advice, body/weight messaging, allergy alerts | Child safety review; clinical validation where necessary; avoid shame/stigma; human-readable warnings; disable unsafe outputs | Product content and scoring logic not provided for detailed assessment |
| IN-07 | Child tracking/behavioural monitoring or child-targeted ads | Critical | DPDP Act s.9(3); Google Families Policy | Scan history, engagement analytics, advertising and profiling SDKs | No child targeted ads; no behavioural tracking; disable non-essential identifiers and SDKs for children/unknown age; no ad SDK preferred | Distinguish genuinely aggregate non-identifying diagnostics with counsel |
| IN-08 | Google Play Families policy breach | High | Google Play Families Policy and Families Data Practices | App intended for children and adults; unknown-age users; SDK collection | Accurate target audience; neutral age screen or equivalent; approved SDKs; no prohibited identifiers; ad controls; content review | Verify current Play Console forms at release |
| IN-09 | Misleading or unsafe allergen conclusion causes consumer harm | Critical | FSSAI Labelling & Display Regulations; Consumer Protection Act 2019; CCPA 2022 | OCR/database may miss allergen, cross-contact or updated label | Never guarantee safety; show data freshness/source; conservative unknown result; user checks original packaging; safety QA | Need product-specific clinical/food safety validation; app not label authority |
| IN-10 | Food/nutrition claims exceed substantiation or mislead children | High | FSSAI Advertising & Claims Regulations 2018; Consumer Protection Act 2019; CCPA Guidelines 2022 | Scores, “healthy/safe” claims, paid promotions, brand links | Review all copy, scores, sponsored content and endorsements; substantiation file; avoid child-shaming/body-image messaging | Applicability as FBO / marketer depends on commercial design |
| IN-11 | App functionality becomes regulated medical-device software | High | Medical Devices Rules 2017; CDSCO MDSW Guidance 21 Jul 2026 | Allergy-risk predictions, disease management, pregnancy recommendations | Freeze clinical/disease claims pending CDSCO classification; document intended purpose; get regulatory counsel; licensing/QMS/clinical evidence if required | Classification depends on actual claims, UI, algorithm and intended purpose |
| IN-12 | Open Food Facts or Google SDK transfer not disclosed/appropriately controlled | High | SPDI Rules rr.6–7; DPDP ss.8, 16 and Rules from May 2027; Play Data safety | Barcode requests, IP and SDK performance telemetry | Data flow inventory; no profile/health fields to OFF; verify vendor role, terms, transfers and retention; disclose SDK data | OFF primary privacy/retention facts not fully verified in this session |
| IN-13 | ML Kit represented as transmitting no data at all | Medium | ML Kit terms; Play Data safety / privacy policy | ML Kit usage/performance metrics and update traffic may occur | Identify API/version and metrics settings; disclose accurately; do not upload image input if using on-device OCR | Exact build configuration not provided |
| IN-14 | CERT-In incident reporting/log duties missed | High | IT Act s.70B; CERT-In Directions 28 Apr 2022 | Cyber incident in app/operator infrastructure or vendors | Determine scope; designate POC; 6-hour Annexure I reporting process; 180-day India ICT logs; time sync | Whether operator falls into covered classes and incident categories need counsel/security confirmation |
| IN-15 | DPDP future breach notification process missed | High | DPDP Act s.8; DPDP Rules r.7 (from 13 May 2027) | Breach of profile or health data | Incident playbook with notice to affected persons without delay and Board without delay; fuller Board details within 72h per Rule | Future commencement; reconcile with CERT-In reporting in a single playbook |
| IN-16 | Excessive or legally misclassified retention across NutriShield data categories | High | SPDI Rule 5; DPDP Act s.8; DPDP Rules rr.6(1)(e), 8(1)–(3), Third and Seventh Schedules | Scan history, favourites, cache, health records, consent evidence, backups and logs | Create category-specific schedules; distinguish Rule 6(1)(e) security-purpose retention from Rule 8(3) Seventh-Schedule retention and Rule 8(1)–(2) erasure; obtain written counsel view on Rule 8(3) scope; propagate deletion to vendors/backups | Rule 8(3) illustrations and Seventh Schedule create an interpretive issue; no blanket one-year user-data period assumed |
| IN-17 | Privacy policy and Google Play Data safety form mismatch | High | Google Play User Data, Privacy Policy and Data safety requirements | Local storage, OFF, ML Kit, other SDKs | Release-specific data map; network capture; maintain single source of truth; update both disclosures | Exact vendor settings and SDK list unavailable |
| IN-18 | Parent withdrawal not propagated to local/vendor copies | High | DPDP ss.6, 8, 9, 12; SPDI Rule 5 | Child profile remains in cache, backup or remote vendor | Withdrawal event stops processing; cascade deletion; verify backups and vendor deletion; retain minimal compliance evidence only | Requires architecture and vendor deletion capabilities |
| IN-19 | CERT-In and DPDP retention provisions conflated or used to justify unrelated personal-data retention | High | CERT-In 180-day India ICT-system logs; DPDP Rule 6(1)(e); Rule 8(3) and Seventh Schedule | Child scans/health values inadvertently written into logs or retained under an inapplicable one-year rule | Separate CERT-In, Rule 6(1)(e), Rule 8(3), SPDI and ordinary product-data schedules; minimise log contents; no raw health/OCR content in diagnostics; obtain counsel opinion on Rule 8(3) applicability | Logging design not audited; Rule 8(3) scope unresolved |
| IN-20 | Parent/guardian authority dispute or false parent claim | High | DPDP Act s.9; Rule 10; applicable guardianship law | Non-parent or disputed guardian approval | Counsel-approved guardian categories and escalation route; block sensitive processing pending valid authority | No universal relationship-check method set by Rule 10 |
| IN-21 | Country change / unknown age causes wrong India flow | High | DPDP Act s.3 and child definition; Google Families unknown-age restrictions | User changes country or does not share age | Rules registry; safe fallback; no unknown age treated adult. Round 2: the country selector was removed, so no flow depends on country | Global rules not yet researched by owner's sequence instruction |
| IN-22 | Play Age Signals API used for a prohibited purpose or assumed universally available | Medium | Official Play Age Signals API terms | API may not return a signal; data could be misused in analytics/ads | Use only for age-appropriate experience/legal compliance; treat absent signal as unknown; never substitute for Rule 10 | API is beta; eligibility varies by law/region |
| IN-23 | Inadequate privacy notice or grievance/rights path | High | SPDI Rules rr.4, 5(9); DPDP Act ss.11–13; Rules r.3 | Health-data users/parents cannot understand or exercise rights | Standalone plain-language notices; accessible contact/grievance route; rights, correction and deletion workflow | Need appointed contact and reviewed policy text |
| IN-24 | India source changes after research cut-off | Medium | Gazette/regulatory amendments and Play policy versioning | New commencement, FSSAI, CDSCO or Play changes | Legal source monitoring; review dates; release gate checks and change log | Research verified as of 25 Nov 2026 only |

## Top release blockers

1. Obtain written Indian counsel advice on local-only/data-fiduciary/SPDI scope and child consent during the current transition period.
2. Agree the parent identity/age and guardian verification method for DPDP Rule 10; document limits and fraud handling.
3. Complete medical-device-software intended-purpose classification for allergy, health-condition, pregnancy and senior features.
4. Approve allergen accuracy, source/version, uncertainty and safety-warning design; do not make safety guarantees.
5. Inventory and verify all SDK/network traffic and Open Food Facts handling; reconcile privacy policy and Google Play Data safety.
6. Implement a testable May 2027 transition and child-safe default design.

| IN-25 | Rule 8(3) Seventh-Schedule retention scope incorrectly assumed for a private consumer app | High | DPDP Rules r.8(3), Seventh Schedule and illustrations | NutriShield may either retain data unnecessarily for one year or erase data subject to a valid statutory minimum | Obtain written Indian counsel interpretation of the Rule/illustration tension; map every NutriShield purpose against the Seventh Schedule; do not hard-code a universal one-year period pending advice | Interpretive issue unresolved; no conclusion that Rule 8(3) applies or does not apply to NutriShield |


---
# v1.2 additions (technical implementation stage, 25 Nov 2026)
Everything above this line is the v1.1 corrected register, preserved verbatim (including its misplaced IN-25 row). IDs IN-01…IN-25 are not removed. Nothing below is a legal conclusion.

## Status of existing risks after implementation
| ID | Technical status | Remaining |
|---|---|---|
| IN-01 | Rules registry holds both regimes; behaviour not date-gated; dates flagged Gazette-unverified | Gazette verification; S.O. 5458(E) unverified |
| IN-02 | Under-18/unknown cannot create health profile, nickname, history. Verifier NOT configured | Counsel-approved Rule 10 method; before enabling any child profile |
| IN-03 | Self-declared age never "verified"; UI says so; verifier cannot unlock child health | Counsel method |
| IN-04 | Separate optional health consent, ledger, withdrawal-with-deletion, scanning without profile | Counsel review of SPDI consent form; operator role; plaintext local storage (NS-34) |
| IN-05 | No change in legal analysis | Counsel |
| IN-06/IN-07 | No tracking/ads SDK; CI guard blocks adding one; child scoring unchanged | Child-facing scoring review (CCPA) |
| IN-08 | No ad/analytics SDK; Play Families declarations NOT done | Play Console declarations |
| IN-09 | 7-state allergen result; no "clear"/"safe" wording; short terms handled; tested | Real-label field testing; product decision on thresholds (NS-36) |
| IN-10 | Score words match bands | Child-facing claims review |
| IN-11 | Wording frozen (no new clinical claims) but NOT reduced; no kill-switch added | Counsel MDSW view (G-10 open) |
| IN-12/IN-13/IN-17 | Privacy draft now discloses OFF barcode + category requests; ML Kit/Google behaviour marked REQUIRED INPUT | Merged-manifest/device traffic capture; Data safety form |
| IN-14/IN-15 | No operator infrastructure; no change | Counsel/security playbook |
| IN-16/IN-19/IN-25 | Retention config exists, all periods null, validator forbids hard-coding Rule 8(3)/consent/verification/security-log periods | Written counsel advice |
| IN-18 | Withdrawal deletes local copies; OFF/Google copies cannot be deleted by the app and are disclosed | Vendor terms |
| IN-20 | No verifier; no guardian logic | Counsel |
| IN-21 | Locale guess recorded as `locale_guess`; unknown age = child-safe. Non-India users are NOT gated | Product/counsel decision on unresearched countries |
| IN-22 | Play Age Signals not used | — |
| IN-23 | In-app draft policy and withdrawal paths exist; grievance contact is a placeholder | Publisher inputs, counsel |
| IN-24 | Re-verify at release | — |

## New risks
| ID | Severity | Risk | Evidence | Mitigation / status |
|---|---|---|---|---|
| NS-26 | Critical | "Allergy Check Clear" shown on weak data | engine.js:163 (coverage ≥0.6) | FIXED: allergen.js; tests |
| NS-27 | High | Allergy terms <3 chars silently dropped but listed as checked | engine.js:161, index.html (old 1103) | FIXED: 2-letter whole-word, 1-letter/non-Latin reported |
| NS-28 | High | Privacy draft omitted category search | lookup-web.js | FIXED in draft |
| NS-29 | High | Mandatory profile gate bundled health collection | old index.html:1529 | FIXED |
| NS-30 | Medium | Mode independent of age | old code | MITIGATED: age status gates; Kids mode still selectable by adults (parents) |
| NS-31 | Medium | CI silently dropped plugins | build.yaml | FIXED in YAML; UNVERIFIED in CI |
| NS-32 | Medium | `findSimilar` sends category + 40-row query to a community service | lookup-web.js | OPEN: throttle/cache not implemented |
| NS-33 | Low | v1.1 doc defects (IN-25 row placement; duplicate section numbers 8 and 15.8) | read | Preserved; noted |
| NS-34 | High | Profile/allergy/consent data in plaintext localStorage | index.html, registry.js | OPEN, unchanged: encrypted-storage plugin needs approval. Now disclosed in Privacy Policy draft-0.2.0; the app does not claim encryption |
| NS-35 | Medium | Self-declared age can be changed in the editor (child can claim adult) | index.html editor | OPEN by design: no verification exists. Counsel/product |
| NS-36 | Medium | Allergen heuristics (coverage 0.8, stale 365 d, min text 15) are product heuristics, unvalidated on real labels | allergen.js DEFAULTS | OPEN: needs field data |
| NS-37 | Medium | Score colour thresholds (70/45) differ from word bands (75/50) | index.html vClass | OPEN: product decision (not changed per instruction) |
| NS-38 | Medium | Free-text feedback can contain personal data and is stored for any age | features.js | OPEN: product/counsel |
| NS-39 | Medium | CSP still allows unsafe-inline / unsafe-eval | index.html | OPEN: needs device regression test of Tesseract |
| NS-40 | High | CI "Update Permanent APK Link" published a public APK on every push | old build.yaml | CHANGED to opt-in; product decision on distribution |
| NS-41 | Medium | Android WebView cache and Google/OFF-held data not deletable by app | wipe.js | DISCLOSED in UI; OPEN |
| NS-42 | Medium | Expectation-check feature uses a separate "Healthy" ≥65 rule | features.js:101 | OPEN: not a safe-choice label but review wording |
