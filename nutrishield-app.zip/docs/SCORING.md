# How NutriShield scores a product (rule-based, no AI)

## 1. Reading the label
OCR text is trimmed to the ingredient list (header found even with OCR slips such as "INGR EDIENTS"), allergen lines and nutrition lines. The list ends at footnotes, batch text, nutrition table, "may contain", manufacturer or MRP text. Percentages, bracket numerals like (ii), and claims such as "gluten free" are removed. Each item is matched against the built-in database by name, alias or E-number, with a small spelling tolerance for OCR errors.

## 2. Ingredient score (0-100)
- Every ingredient in the database has a score (100 = best) and a hazard level (low / moderate / high).
- Score = weighted average of recognised ingredients. Earlier ingredients weigh more: weight = 1 / (1 + 0.2 x position).
- Penalties: -8 for each high-hazard ingredient; -2 for each moderate one (at most 5 counted).
- Hidden sugar: -8 if three or more sugar-type names appear. If sugar is the first ingredient the score is capped at 39; within the first three, capped at 49.
- Unrecognised items are not scored; they lower the confidence.
- Confidence = recognised / total items: High at 80% or more, Medium at 50% or more, otherwise Low. Low confidence caps the score at 69. Below 34% (or nothing recognised) no score is given.
- Verdict: 75+ Good, 50-74 Okay, 25-49 Poor, under 25 Avoid.
- Hazard: High if any high-hazard ingredient or score under 35; Moderate if score under 65 or two or more moderate ingredients; otherwise Low.

## 3. Nutrition score (0-100), per 100 g (or 100 ml for drinks)
Starts at 100. Traffic-light thresholds (FSA style), low / high limits:
| per 100 g | Low up to | High above | Penalty medium / high |
|---|---|---|---|
| Fat | 3 | 17.5 | 4 / 10 |
| Saturated fat | 1.5 | 5 | 8 / 25 |
| Sugars | 5 | 22.5 | 10 / 30 |
| Salt | 0.3 | 1.5 | 10 / 25 |

Drinks use lower limits (fat 1.5/8.75, sat 0.75/2.5, sugars 2.5/11.25, salt 0.3/1.5 per 100 ml) and lose extra points when sugars are 5 g or more. Energy over 400 kcal: -10; over 250 kcal: -4. Fibre 3 g or more: +4; 6 g or more: +8. Protein 10 g or more: +6. Result limited to 0-100.

## 4. Overall score
60% ingredient score + 40% nutrition score. If only one exists, that one is used.

## 5. Match ID
A short code from the sorted list of recognised ingredient names. Same ingredients give the same Match ID, whichever way the product was scanned.

## 6. Allergies and modes
- Allergies: the label text is searched for the allergen and related terms; "contains" gives a match, "may contain / traces" gives a traces warning. If the label is unreadable the status is "unverified", never "safe".
- Pregnancy mode avoids alcohol, saccharin, raw/unpasteurised foods and high-mercury fish; limits caffeine, liver, energy-drink additives and some others; notes added vitamin A.
- Senior mode limits high salt, sugar and saturated fat, trans fat, phosphate additives, potassium chloride, alcohol, liquorice, sugar alcohols and sodium additives.
- Rules live in `www/advice.js`; test cases in `scripts/modes-test.js`.

## 7. Accuracy
`scripts/accuracy.js` runs 25 reference labels each build and checks score band, coverage and allergy status. These are typed samples; add photographed packs to `scripts/labels.json`.

## 8. Limits
Ingredient scores are the team's rule-based judgements from general food-additive knowledge, not official ratings. Ingredient order is used as a proxy for quantity. The app cannot see unlabelled risks (for example pasteurisation or cooking). Not medical advice.
