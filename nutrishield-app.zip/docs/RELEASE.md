# Signed release APK

The workflow always builds a debug APK. It also builds a signed release APK when four repository secrets exist. If they are missing the step is skipped.

## 1. Create a keystore (once, on your computer; needs Java)
    keytool -genkeypair -v -keystore nutrishield-release.jks -alias nutrishield -keyalg RSA -keysize 2048 -validity 10000

Remember the two passwords. **Back up the .jks file safely: if you lose it you cannot publish updates.** Never put it in the repository.

## 2. Encode it
Linux: `base64 -w0 nutrishield-release.jks`   Mac: `base64 -i nutrishield-release.jks`   Windows (PowerShell): `[Convert]::ToBase64String([IO.File]::ReadAllBytes("nutrishield-release.jks"))`

## 3. Add four secrets (GitHub repo > Settings > Secrets and variables > Actions)
- `RELEASE_KEYSTORE_B64`: the base64 text
- `RELEASE_KEYSTORE_PASSWORD`: keystore password
- `RELEASE_KEY_ALIAS`: `nutrishield` (or your alias)
- `RELEASE_KEY_PASSWORD`: key password

## 4. Run the workflow
The signed file appears in the run artifacts as `NutriShield-release-APK`. The step runs `assembleRelease`, aligns and signs with apksigner, verifies the signature and checks the OCR files are inside.

## Notes
- Google Play needs an app bundle (AAB) and a version code; this workflow produces an APK for direct installation.
- This step was written without a test build; if it fails, the debug APK is unaffected. Read the step log and send it for a fix.
