# NutriShield Privacy Policy (draft template)
Fill in the [brackets] and have a lawyer review it before publishing. Last updated: [date]

**Who we are.** [Your name or organisation], contact: [email]. NutriShield has no server and no user accounts.

## What the app stores, and where
The app stores the following **only on your device**: your name (or nickname), age, allergies, selected mode (for example Pregnancy or Senior), country and language, scan history, favourites, feedback you write, and labels you scanned. We do not receive this data. You can erase all of it in **Settings > Delete All My Local Data**. Uninstalling the app also removes it. Android cloud backup of the app is turned off.

## Camera and photos
The camera is used to read labels and barcodes. Photos are processed on your device and the app does not upload them.

## What leaves your device
When you scan a barcode with internet access, the app sends **the barcode number** to Open Food Facts (openfoodfacts.org) to find the product. Their servers can also see your IP address and standard connection details, under their own privacy policy. No other personal data is sent. Text reading, scoring and advice run on your device.

## Health information
Allergies, age and pregnancy or senior mode are health-related. They are used only on your device to personalise results. They are not shared.

## Children
[Choose and state a minimum age, for example 13 or 18. If younger users are allowed, local law may require a parent's consent.]

## Your choices
You can change or delete your profile and data at any time in Settings.

## Changes
If we add features that collect or share data (for example ads, accounts or cloud sync), we will update this policy and ask for consent where the law requires it.

## Contact
[Email / address]
