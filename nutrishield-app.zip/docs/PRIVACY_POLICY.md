# NutriShield Privacy Policy (draft-0.2.0)

> DRAFT. Placeholders are not completed. Not reviewed by legal counsel. Not approved for production or publication.
> Generated from www/compliance/legal.js. Edit that file, not this one.

## Document status
DRAFT. Placeholders are not completed. Not reviewed by legal counsel. Not approved for production or publication.

Effective date: [REQUIRED INPUT: effective date after counsel approval]


## Who is responsible
Publisher: [REQUIRED INPUT: legal name and legal form of the publisher]

Address: [REQUIRED INPUT: registered postal address]

Contact: [REQUIRED INPUT: contact email]

Grievance contact: [REQUIRED INPUT: name, designation and contact of the grievance officer; counsel to confirm the requirement]


## What NutriShield stores on your device
- Self-declared age status (adult, under 18, or not stated). NutriShield cannot verify your age.
- An optional nickname (adults only) and your selected mode.
- NutriShield does not ask for or store your email address, mobile number or country.
- Only if you separately agree: allergies, health conditions and pregnancy mode (health profile). Adults only.
- Only if you separately agree: scan history, favourites, scanned label text and an offline product cache.
- Feedback you write, theme, language and voice settings, and a record of the consents you gave or withdrew.
NutriShield has no account system and no server of its own. In this version it does not send this data to the publisher.


## Age and children
You tell the app whether you are 18 or older. This is not checked. If you say you are under 18, or do not say, NutriShield switches to child-safe defaults: no health profile, no nickname, no history or favourites, stricter scoring checks, and no advertising or tracking.

Parental authorisation is not available in this version. Because of that, a health profile cannot be created for anyone under 18 or whose age is not stated.

Counsel to confirm: [REQUIRED INPUT: consent and guardian process for under-18 users under current and future Indian law]


## Health information (optional)
Allergies, health conditions and pregnancy mode are health-related. They are used only on your device to adjust results. You can use barcode and label scanning without them.

You can withdraw this consent at any time in Settings. Withdrawing deletes the health information from the app.


## Camera and photos
The camera and photos are used to read labels and barcodes. The app does not save or upload your photos. Text reading runs on your device. Google ML Kit and Google Play services may download text-reading models and may send usage or performance data to Google: [REQUIRED INPUT: confirm exact Google ML Kit / Google Play services data practices for the released build]


## What leaves your device
- Barcode lookup: when you scan a barcode that is not in the app or in your saved cache, the barcode number is sent to Open Food Facts (openfoodfacts.org). Open Food Facts also sees your IP address and ordinary connection details.
- Compare feature: to find similar products, the app sends a product category name to Open Food Facts.
- No profile, age, allergy, health, history or feedback data is sent to Open Food Facts.
- Open Food Facts role, logs and retention: [REQUIRED INPUT: confirm from Open Food Facts directly]
The app has no advertising, analytics or crash-reporting service.


## How long data is kept
This version does not delete data automatically. Data stays on your device until you delete it or withdraw a consent.

Statutory retention periods: [REQUIRED INPUT: retention periods per data category, pending written Indian counsel advice]

Consent record retention: [REQUIRED INPUT: period pending counsel]

Parent-verification evidence retention: [REQUIRED INPUT: not applicable until a verification method is approved]


## Your choices and deletion
Settings lets you withdraw each consent, delete health data, delete history/favourites/saved labels, and delete everything stored by the app.

Some things cannot be deleted by the app: Open Food Facts server logs, Google-managed data, the Android WebView disk cache (clear it in Android Settings > Apps > NutriShield > Storage), text you copied to the clipboard, and copies you made elsewhere.


## Security of data on your device
Everything NutriShield stores is kept on your device. In this version NutriShield does not add its own encryption to that data. It relies on your phone's own protections, such as the screen lock. Anyone who can unlock your phone or read the app's data (for example on a rooted device) may be able to read it. You can delete it at any time in Settings.


## Changes
If features that collect or share data are added (for example ads, accounts or cloud sync), this policy will be updated and consent asked again where required.


## Version history

- draft-0.1.0: First draft.
- draft-0.2.0: States that email address, mobile number and country are not collected, and discloses that data on the device is stored without extra encryption by NutriShield.
