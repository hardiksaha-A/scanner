# Android device test plan - scanner, OCR, image quality, barcode

STATUS: **NOT PERFORMED.** No Android device or Android build was available in the working environment. Every result in
`SCANNER_PIPELINE_REPORT.md` comes from Node (Tesseract only, desktop) and is not Android verification.

## Devices
At least: one low-end (<= 3 GB RAM, 4 cores or fewer), one mid-range, one recent phone. Record model, Android version, WebView version.

## Build
1. Run the GitHub Actions workflow (`build.yaml`) and install the produced APK. Record the run link and result.
2. Confirm `npm run`/`node scripts/verify.js` is green in CI before installing.

## Checks (record pass/fail and numbers)
| # | Check | Pass criterion |
|---|---|---|
| 1 | Same printed label, 10 repeated scans of the SAME saved photo via gallery | identical stage hashes (`window.__scanTrace` + text boxes) 10/10 |
| 2 | Camera app photo vs the same file picked from gallery | identical results |
| 3 | Live "Snap" vs camera app vs gallery on the same label | report differences per stage; investigate first divergence |
| 4 | ML Kit text order for a nutrition table (device log of `detectText` blocks/lines/boundingBox) | confirm `boundingBox` is present; rows are rebuilt (Energy 537 kcal ...) |
| 5 | `ImageCapture.getPhotoCapabilities()` max `imageWidth` and the photo actually delivered | record sizes; confirm a larger still than the 1920x1080 video frame |
| 6 | Continuous focus applied (`getCapabilities().focusMode`) | record supported / not supported |
| 7 | EXIF orientation: portrait and landscape photos from camera and gallery | text upright in the crop dialog |
| 8 | Auto crop box on 10+ real labels | box never cuts a character, heading or unit |
| 9 | Barcodes: EAN-13, UPC-A, EAN-8, UPC-E, GTIN-14 samples, live and from photo | each reaches the same product; `BarcodeDetector` availability noted |
| 10 | Open Food Facts: same product via 13-digit, 12-digit, 8-digit forms | same record; note which form OFF answers |
| 11 | Existing cache/saved-label records from the previous app version after upgrade | still found |
| 12 | Low-end device: time from tap to result, peak memory (Android Studio profiler), no crash/freeze over 30 consecutive scans | no crash; record seconds and MB; compare normal vs low-memory profile (`Pipeline.limits`) |
| 13 | Offline-list confirmation dialog ("Keep my scan" / "Use offline record") | default is Keep; nothing replaced without a tap |
| 14 | Quality tips (blur / dark / glare / small) on deliberately bad photos | tip shown, read still allowed |

## Real-label accuracy
Needs the labelled photo set plus manually verified reference text. Until then real-label accuracy is UNVERIFIED.
| 15 | Crop dialog on a real phone: rotate, pinch zoom, ✋ Move, ⬚ Corners (drag corners, refused crossed corners) | smooth, no lag; box never moves while zooming |
| 16 | Four-corner straighten time and memory on the low-end device with a 3200 px photo | record seconds and MB; no freeze |
