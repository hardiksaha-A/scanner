# NutriShield Terms of Use (draft template)
Fill in the [brackets] and have a lawyer review it before publishing. Last updated: [date]

1. **Information only.** NutriShield provides general, rule-based information about ingredients and nutrition. It is not medical, dietary or allergy advice and does not replace a doctor, dietitian or the printed label.
2. **Check the pack.** Always read the printed pack, especially for allergies. Reading a label by camera can contain mistakes, and the app may miss ingredients or allergen warnings.
3. **Scores are opinions.** Scores and hazard levels are NutriShield's own rule-based assessments from ingredient names and nutrition values. They are not official ratings, certifications or statements about any brand.
4. **Special modes.** Pregnancy and Senior modes give general guidance only. Ask a qualified professional about your situation.
5. **Third-party data.** Product data comes from Open Food Facts and other open sources and may be incomplete or wrong.
6. **No warranty.** The app is provided "as is" without warranties of any kind, to the extent allowed by law.
7. **Liability.** To the extent allowed by law, [your name or organisation] is not liable for loss or harm from using the app. [Have a lawyer set the exact wording for your country.]
8. **Trademarks.** Product names and trademarks belong to their owners. No affiliation or endorsement is implied.
9. **Changes and law.** We may update these terms. They are governed by the laws of [country/state]; disputes go to the courts of [place].
10. **Contact.** [Email]
