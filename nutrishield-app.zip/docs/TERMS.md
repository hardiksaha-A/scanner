# NutriShield Terms of Use (draft-0.1.0)

> DRAFT. Placeholders are not completed. Not reviewed by legal counsel. Not approved for production or publication.
> Generated from www/compliance/legal.js. Edit that file, not this one.

## Document status
DRAFT. Placeholders are not completed. Not reviewed by legal counsel. Not approved for production or publication.

Effective date: [REQUIRED INPUT: effective date after counsel approval]


## 1. Information only
NutriShield gives general, rule-based information about ingredients and nutrition. It is not medical, dietary or allergy advice and does not replace a doctor, dietitian or the printed label.


## 2. Check the pack
Always read the current printed pack, especially for allergies. Camera reading can make mistakes, product data can be incomplete or out of date, and the app cannot know about cross-contact or recipe changes. A result of "no match found" is never a guarantee that a product is safe for you.


## 3. Scores are opinions
Scores and hazard levels are NutriShield's own rule-based assessments. They are not official ratings, certifications or statements about any brand.


## 4. Special modes
Pregnancy and Senior modes give general guidance only. Ask a qualified professional about your situation.


## 5. Age
You tell the app your age status yourself and it is not verified. Use of the health profile and history features is limited as described in the Privacy Policy.


## 6. Third-party data
Product data comes from Open Food Facts and other open sources and may be incomplete or wrong.


## 7. No warranty and liability
[REQUIRED INPUT: warranty disclaimer and limitation of liability wording approved by counsel]


## 8. Trademarks
Product names and trademarks belong to their owners. No affiliation or endorsement is implied.


## 9. Changes, governing law and disputes
Changes to these terms: [REQUIRED INPUT: change procedure]

Governing law: [REQUIRED INPUT: governing law]

Courts / dispute resolution: [REQUIRED INPUT: forum]


## 10. Contact
[REQUIRED INPUT: contact email and postal address]


## Version history

- draft-0.1.0: First draft.
