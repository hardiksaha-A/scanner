# Implementation plan — status after approved implementation
| Item | Status |
|---|---|
| Group 1: G-06, G-08, G-09, G-12, G-14, G-16, G-17, G-20 wording, tests, docs | Done. G-14 and G-16 partial (see matrix) |
| Group 2a optional profile + health consent | Done, tested |
| 2b age-status step (no DOB) | Done, tested |
| 2c disabled ParentVerifier + child lock | Done (interface only, NOT operational) |
| 2d Privacy/Terms viewer with placeholders | Done (drafts) |
| 2e CI: AAB + explicit plugin failure | Written, **not run in GitHub Actions** |
| Not done: G-10 kill-switch, G-13 encryption (not approved), G-15 logging audit, findSimilar throttling | Outstanding |
| Needs counsel: retention periods, Rule 8(3), Rule 10 method, SPDI consent form, MDSW, consent-record retention | Open |
| Needs inputs/credentials: publisher identity, contacts, grievance officer, governing law, keystore secrets, Play Console | Open |
