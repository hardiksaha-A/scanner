# NutriShield India — Data-Flow and SDK Inventory (post-implementation)
Source-based. Native Android components (Play services/ML Kit internals, merged manifest) could not be inspected: no build was possible here. Treat "to confirm" items as open.

## Third-party services
| Service | Data sent | Why | Optional? | Disclosed in draft policy | Status |
|---|---|---|---|---|---|
| Open Food Facts (`world.openfoodfacts.org`) | Barcode in URL; query field list incl. `last_modified_t`; IP/headers; User-Agent `NutriShield/0.9 (Android app)` | Product lookup | Optional (bundled, saved, cache first) | Yes | Verified in code and in Chromium (no profile data in request) |
| Open Food Facts `search` | Category tag, `page_size=40` | "Compare/similar products" | Optional | Yes (added) | Verified in code |
| Google ML Kit / Play services | Image stays on device per plugin docs. Model download and possible usage metrics: unknown | On-device OCR | Optional (Tesseract fallback) | Marked REQUIRED INPUT | **Unverified** |
| Text-to-speech (device engine) | Spoken text to OS engine; engine behaviour unknown | Read-aloud | Optional | Not detailed | Unverified |
| Advertising / analytics / crash / cloud | None | — | — | States none | `check-deps.js` finds none in JS deps; native transitive libs unverified |

## Data on device
| Data | Location (key) | Created when | Consent purpose | Deleted by |
|---|---|---|---|---|
| Age status | `ns.age.v1` | Onboarding | Terms/privacy ack | Wipe; (kept on withdrawal of other consents) |
| Consent ledger | `ns.consent.v1` | Any consent action. Terms/Privacy acceptance records the Privacy and Terms versions separately (`docVersions`); earlier records are never rewritten | n/a | Wipe only (retention period unset: counsel) |
| Profile (nickname, mode) | `nutrishield.profile` | Onboarding | Terms/privacy | Wipe |
| Email, mobile number, country | **Not collected.** The fields were removed; any value saved by an earlier test build is deleted when the profile loads (`gate.js` `sanitizeProfile`) | n/a | n/a | n/a |
| Allergies, conditions, pregnancy mode | inside profile; legacy in `ns.suspended.v1` | Adult + health consent | health_profile | Withdraw (deletes), per-category delete, wipe |
| History / favourites | `ls.history`, `ls.fav` | Adult + history consent | local_history | Withdraw, delete, wipe |
| Saved label text | `ns_lbl_<barcode>` | Adult + history consent | local_history | same |
| Offline product cache (+`cachedAt`) | `nutrishield.cache` | Adult + history consent | local_history | same |
| Feedback text | `ls.feedback` | User action | none (not gated; NS-38) | Delete feedback, wipe |
| Theme/language/voice/schema | `nutrishield.theme/lang/speak`, `ns.schema` | Use | none | Wipe |
| Photos/camera frames | memory only (no write found) | Scan | — | n/a. Device runtime check pending |

## Cannot be deleted by the app (shown to the user after deletion)
OFF server logs; Google-managed data; Android WebView disk cache (user: Settings > Apps > NutriShield > Storage); clipboard after "Export Saved Feedback"; OS screenshots/recents/TTS data/user-made backups.

## Android build settings (from `build.yaml`, UNVERIFIED until a build runs)
Permissions added: CAMERA (optional feature), INTERNET (Capacitor default); `allowBackup=false`; `usesCleartextTraffic=false`; ML Kit `DEPENDENCIES=ocr` meta-data (unless `drop_mlkit`). The workflow now audits the merged manifest and warns on extra permissions.

## Round 2 notes (accuracy of this inventory)
- No SDK, plugin, permission or network call was added or changed. Email, mobile number and country never left the device and are no longer collected.
- **Storage is plaintext (OPEN: NS-34 / G-13).** Every key above is ordinary `localStorage` in the Android WebView. NutriShield adds no encryption of its own. The Privacy Policy (draft-0.2.0, section "Security of data on your device") says so; nothing in the app or the policy claims encryption.
- Voice on/off (`nutrishield.speak`) now gates all speech, automatic and manual. It is a device preference with no data leaving the device.
