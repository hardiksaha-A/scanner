# NUTRISHIELD HANDOVER (India compliance implementation, 25 Nov 2026)
Not legal advice. **Not legally cleared. Not launch-ready.** India = Category 3: Indian counsel required.

## 1. Project overview
NutriShield: offline-first food-label scanner. **Capacitor 6 hybrid app** (vanilla JS in `www/`); the Android/Gradle project is generated only in CI (`npx cap add android`). appId `com.nutrishield.app`, version 1.0.0. Only India researched; baseline = `research_baseline_v1.1/` (6 files, unmodified).
## 2. Original source and inventory
`nutri_8.zip` (sha256 `49b2f585…`) = `nutrishield-app.zip` + `build.yaml`. No Git history. Baseline commit `b63a6f2`. Full inventory: `NUTRISHIELD_AUDIT_AND_PLAN.md` §A. Work branch `india-compliance` (commit `0204451`; patch in `patches/`).
## 3. Final architecture
Existing: `engine.js`, `nutrition.js`, `advice.js`, `features.js`, `lookup-web.js`, OCR files (**scoring files unchanged, hash-tested**). New `www/compliance/`: `rules, age, consent, retention, registry, gate, migrate, wipe, verifier, allergen, legal` (UMD, no dependencies). UI wiring in `index.html`.
## 4. India requirements addressed
Child = under 18, no 13/16 threshold; SPDI-era and DPDP-child controls both applied now (not date-gated); separate health consent; consent evidence; withdrawal with deletion; no blanket retention; allergen non-guarantee wording; policy accuracy. See `INDIA_COMPLIANCE_GAP_MATRIX.md`.
## 5. Code changes
`IMPLEMENTATION_CHANGELOG.md`.
## 6. Database/migration
No DB; localStorage. Schema key `ns.schema` {v:2}. Migration `migrate.js` (legacy adult health data → `ns.suspended.v1`, unused until re-consent; legacy under-18/unknown → health/name/history/cache deleted). Idempotent, tested.
## 7. Age and parental authorisation
Self-declared status only (`ns.age.v1`, `verified:false` always). Unknown/under-18/missing = child-safe: no health profile, nickname, history, favourites, saved labels, offline cache; stricter-child mode only. `ParentVerifier` is a **disabled interface**; `install()` needs provider + counsel approval ref; even then child health stays blocked (`gate.js`). Known limit: user can change declared status in the editor (NS-35). `Age.isAdultByDob` exists for a future verified DOB flow.
## 8. Privacy and data flow
`INDIA_DATA_FLOW_AND_SDK_INVENTORY.md`. Only network: Open Food Facts (barcode; category search).
## 9. Retention and deletion
`retention.js`: all periods `null`; validator forbids hard-coding Rule 8(3), consent, verification, security-log, CERT-In periods and any blanket key. Rule 8(3) = COUNSEL GATE. Deletion: `wipe.js` (6 browser stores, verified after) + per-category + withdrawal cascade. Not deletable by app: WebView disk cache, OFF/Google copies, clipboard, OS copies.
## 10. Allergy and nutrition safety
States: MATCH_DETECTED, MAY_CONTAIN_DETECTED, NO_MATCH_IN_AVAILABLE_INFO, INFO_INCOMPLETE, OCR_UNCERTAIN, NOT_POSSIBLE, DATA_OUTDATED_OR_UNAVAILABLE. Heuristics (product decisions, not law): coverage ≥ 0.8, text ≥ 15 chars, data ≤ 365 days, all entries checkable. Score words = bands 75/50/25; thresholds untouched; colour thresholds 70/45 untouched (NS-37).
## 11. Dependencies
Unchanged runtime deps: Capacitor core/android/app 6.x, community TTS 5.1, pantrist ML Kit plugin 6.2.1, tesseract.js 5.1.1, eng data. `@capacitor/cli` now dev-only. **No ads/analytics/cloud/verification provider added.**
## 12. Permissions and network
CI adds CAMERA; INTERNET default; backup/cleartext off. Unverified until built; CI now audits merged manifest.
## 13. Terms and Privacy
`www/compliance/legal.js` is the single source (docs/*.md generated: `node scripts/build-legal-docs.js`). **Separate versions per document:** Privacy `draft-0.2.0`, Terms `draft-0.1.0` (`Legal.VERSIONS`, with `Legal.HISTORY`). Bump only the document that changed materially and add a HISTORY entry: users are then asked to accept that document only, and the app stays blocked until both current versions are accepted. Editorial fixes keep the version. **17 `[REQUIRED INPUT]` placeholders**, `isProductionReady()` false. `scripts/legal-gate.js` labels CI artifacts `-DRAFT-LEGAL-NOT-FOR-PRODUCTION`. To approve: counsel review, fill placeholders, set `STATUS.approved/reviewer/approvedOn`.
## 14. Advertising
None integrated (verified in JS deps). `check-deps.js` fails on ad/analytics SDK names. Any future ad needs approval, Families review, separation from assessments.
## 15. Tests executed
`INDIA_TEST_REPORT.md`: verify exit 0; compliance 43/43; E2E 46/46 (desktop Chromium); stress passed; npm audit 0; syntax OK.
## 16. Build commands
Local: `npm ci && node scripts/prep.js && node scripts/verify.js`. E2E: `python3 scripts/e2e/browser_e2e.py`. CI: `build.yaml` (debug APK, release AAB, optional signed APK).
## 17. APK/AAB outputs
**None generated.** No Android SDK here; Google Maven unreachable. No APK/AAB build success is claimed. First CI run is the first real build.
## 18. Known defects/limits
Android WebView untested; ML Kit/Play-services traffic unknown; plaintext local storage; CSP `unsafe-eval/inline`; findSimilar not throttled; G-10, G-15 not done; non-India users not gated; feedback ungated; colour/word band mismatch.
## 19. Unresolved legal questions
Counsel register in audit §G. Plus: DPDP dates and S.O. 5458(E) need **official Gazette verification** (secondary sources only); effect of recording age status for minors; guardian dispute handling.
## 20. Outstanding product decisions
Public "latest" APK publishing (now opt-in); allergen heuristics; history default; Kids mode open to adults; non-India handling; encrypted storage; colour thresholds.
## 21. Counsel review
Everything in legal.js; consent form (SPDI); Rule 10 method; retention periods; MDSW; FSSAI wording; vendor roles.
## 22. Launch blockers
Counsel sign-off; publisher inputs; Gazette verification; real CI build + device testing (Android); Play Data safety/Families/Health declarations; signing keystore/Play Console; merged-manifest and network capture review.
## 23. Next steps
1) Push to GitHub, run workflow, fix first-build issues, review build-info. 2) Test on a real Android device: scan, OCR, wipe, WebView cache. 3) Capture traffic. 4) Send counsel the register + drafts. 5) Fill placeholders. 6) Field-test allergen heuristics. 7) Decide open product items.

## Post-delivery changes (rounds 1 and 2)
Round 1 made email/mobile optional, hid the Terms tick box after first acceptance, removed the main-page chips and added a voice button and country selector. Round 2 corrected or replaced parts of that. **Current state:**
- **Email and mobile:** not collected. Fields removed; values saved by a round-1 test build are deleted on load. Country is also no longer collected or shown (the selector did nothing).
- **Terms and Privacy:** separate version numbers and separate re-acceptance (see Legal section). Privacy `draft-0.2.0` was bumped because it now states that email, mobile and country are not collected and discloses plaintext storage. Terms are unchanged (`draft-0.1.0`), so Terms are not re-asked. Existing consent records are kept as written; users whose record has an older Privacy version will see a re-acceptance screen that names only the Privacy Policy.
- **Main page and result card:** the "No AI", category chips and "Zero AI" wording are removed (the formula explanation is kept, now headed "How the score is calculated"). Code comments in `engine.js`/`advice.js`/`features.js` still say "no AI"; they are not user-facing and those files are hash-protected, so they were not edited.
- **Default mode:** self-declared 18+ now starts in Adult mode. Under 18 and "prefer not to say" stay child-safe (Stricter Child Checks only). An adult can still choose Stricter Child Checks. Profiles already saved in Kids mode by the old default are **not** migrated. Scoring formulas, thresholds and allergen matching are untouched (hash-tested; same product scores the same in both modes).
- **Voice:** one setting. When Off, automatic speech, "Speak Result Aloud" and "Test Voice" are disabled; Stop buttons still work.
- **Still open:** plaintext local storage (NS-34, G-13); counsel review of everything; 17 placeholders; Android build and device testing not done (no Android SDK or GitHub Actions access in the authoring environment); colour/word score-band mismatch; non-India handling.
- **Tests:** compliance 45/45, browser E2E 79/79, `verify.js` ok (desktop Chromium and Node only). See `INDIA_TEST_REPORT.md`.

## Scanner / OCR / barcode round (this delivery)
Full detail: `docs/SCANNER_PIPELINE_REPORT.md`; device checks still to do: `docs/ANDROID_DEVICE_TEST_PLAN.md`.
- Architecture: all photo routes (live snap, camera, gallery) now share `www/pipeline.js` (decode, quality tips, auto text region, deskew, normalisation, record) and `smartscan.js` (fixed pass order). Barcode routes use `www/barcode.js` (`normalize`) and then the same text boxes and assessment.
- New files: `www/pipeline.js`, `www/nutrition-reader.js`, `scripts/harness/*` (tests, trace, baseline runner, experiments), `docs/SCANNER_PIPELINE_REPORT.md`, `docs/ANDROID_DEVICE_TEST_PLAN.md`, `baseline/` (before/after run logs).
- Unchanged and hash-pinned: `engine.js`, `nutrition.js`, `advice.js`, `ingredients.js`.
- Behaviour changes to know: offline-list matches always ask first (default "Keep my scan"); per-serve-only tables are no longer used as per-100 g; a "check the nutrition numbers" note appears for implausible values; the crop box starts on the detected text area.
- Test tools: `node scripts/verify.js` runs everything that needs no canvas. Image tests and the OCR harness need the optional `npm i --no-save @napi-rs/canvas` (not a project dependency). `node scripts/harness/baseline.js <image> 10 --engine pipeline --route camera,gallery,live,dialog --ref <reference.txt>`.
- Known limits: no Android build/device verification yet; real-label OCR accuracy unverified (waiting for the labelled photo set); truncated-word and non-English allergen detection gaps (rules unchanged, approval needed); Open Food Facts compatibility with the new key forms untested live.
- Crop dialog now has rotate 90 degrees, zoom/pan (pinch, wheel, buttons), and four-corner straightening (`Pipeline.straighten`, conditional unsharp only when measured blurry). Pixel-exact crops via `Pipeline.cropExact`. Tests: `harness/pipeline-test.js`, `harness/dialog-test.js`; synthetic OCR measurement: `harness/perspective-ocr.js`.
