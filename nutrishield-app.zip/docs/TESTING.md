# Testing NutriShield: attack and load tests (your own app and devices only)

## 1. Automated (run first)
`node scripts/stress-test.js` (about 1 minute). It throws hostile and huge input at the scorer, nutrition reader, advice rules, crop box and storage reader, and checks: no crash, no hang, numbers in range, same input gives same result, memory stays flat. `node scripts/verify.js` runs the functional tests.

## 2. Security tests on the APK
- **Static scan:** upload the APK to MobSF (free, mobsf.live or self-hosted). Review high findings.
- **Manifest:** `apktool d NutriShield.apk`, then check `AndroidManifest.xml`: `allowBackup="false"`, `usesCleartextTraffic="false"`, no `debuggable="true"` in the release build, only CAMERA and INTERNET permissions, no unneeded exported components.
- **Backup:** `adb backup -noapk <package>` must produce an empty or refused backup.
- **Network:** put your phone behind mitmproxy or Burp. Confirm: only https, only to openfoodfacts.org, and only the barcode number is sent. Check the app fails safely when the connection is blocked or the reply is garbage.
- **Malicious text:** type or scan these into ingredients, nutrition, feedback and the barcode box: `<img src=x onerror=alert(1)>`, `"><script>alert(1)</script>`, 5,000 characters, emoji, right-to-left text. No popup, no crash, text shown as plain text. Print a QR or barcode containing such text and scan it.
- **Tampered storage:** in a debug build use chrome://inspect, edit `localStorage` (profile, ls.history, ls.fav) to broken JSON, wrong types, huge values; reopen the app. It must start and not crash.
- **Permissions:** deny camera, then allow; revoke while the camera is open; no internet; storage full.

## 3. Load and endurance (it runs on the phone, there is no server)
- Run 100 scans in a row (demo buttons, then camera and upload) and watch memory: `adb shell dumpsys meminfo <package>` before and after, or Android Studio Profiler. Memory should return to near the start level.
- Fill history and favourites with thousands of items (script `localStorage` in a debug build) and time app start and the history screen.
- Test on a low-end phone or an emulator with 2 GB RAM, with battery saver on, and while rotating, backgrounding and resuming.
- Scan with the camera for 10 minutes. Check heat, battery and that the camera is released when you leave the screen.
- **Do not** hammer Open Food Facts with automated requests: it is a free community service with its own rate limits. Mock the barcode lookup for load tests.

## 4. Record results
Make a table: test, device, result, notes. Fix anything that crashes, hangs, or shows unescaped text, and rerun `node scripts/verify.js`.
