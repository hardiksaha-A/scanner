# NutriShield Security Notes
**Done**
- All network calls use https; the build turns off plain-http traffic and Android cloud backup.
- Data stays on the device; no server, no accounts. Settings has a Delete All My Local Data button.
- Text from labels and from product databases is escaped before it is shown.
- Release signing key is kept in GitHub Secrets, never in the repository.

**Known issues**
- `npm audit` lists 5 advisories (1 critical, 1 high, 3 moderate) in build tools (`@capacitor/cli` and its `tar`, `glob`, `minimatch`, `rimraf`). They are not packaged in the APK. The only fix is a major Capacitor upgrade, which would also change every plugin, so it is postponed. Re-check before release with `npm audit --omit=dev`.
- Profile and history are stored unencrypted in the app's private storage. On a rooted phone they could be read. Encrypt them if you later store more sensitive data.
- The debug APK is for testing only; publish the signed release build.

**Reporting a problem:** [contact email].
