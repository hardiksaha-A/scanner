# NutriShield India — Test Report (actual results)
Run on 25 Nov 2026 in the build sandbox: Node v22.23.5, Linux, Chromium via Playwright (Python). **No Android SDK, emulator or device was available. No APK or AAB was built or run.**

| Suite | Command | Result |
|---|---|---|
| Clean install from lockfile | `npm ci` | exit 0 (117 packages) |
| Existing project suite (prep + selftest phases, modes, accuracy, localdb) + new guards | `node scripts/verify.js` | **exit 0**, "verify ok" (includes the two rows below) |
| Dependency/host guard | `node scripts/check-deps.js` | PASS: no denied SDK; only host in app code: world.openfoodfacts.org |
| Compliance tests | `node scripts/compliance-test.js` | **43/43 passed** |
| Stress test | `node scripts/stress-test.js` | passed, 20,000 analyses |
| Real-browser E2E (desktop Chromium) | `python3 scripts/e2e/browser_e2e.py` | **46/46 passed** |
| Syntax | `node --check` on 39 JS files | no failures. **No linter is configured in the project, so no lint run was possible** |
| Dependency audit | `npm audit --omit=dev` | 0 vulnerabilities |
| build.yaml | Python `yaml.safe_load` + `bash -n` on all 20 steps | syntax OK. **NOT executed in GitHub Actions** |

## What the tests prove, and what they do not
- **Proven (Node):** age/consent/gate/migration/retention/allergen logic, wording, scoring files unchanged (SHA-256), OFF request shape, legal drafts contain placeholders and no invented identity.
- **Proven (desktop Chromium):** onboarding gating, no pre-selected/pre-ticked controls, child vs adult storage contents, no network on text scans, OFF-only requests with no profile data, consent withdrawal cascades, legal viewer, legacy-data migration, and deletion of localStorage, sessionStorage, IndexedDB, CacheStorage, service workers and cookies with post-deletion verification inside the page.
- **NOT proven:** behaviour in the Android WebView/Capacitor build; the native WebView disk cache (cannot be deleted from JS; user told to clear it in Android settings); Capacitor HTTP behaviour; ML Kit/Google Play services network traffic; the merged Android manifest; TTS; camera/barcode/OCR on a device; the CI workflow; AAB signing.
- **Not covered by any test:** Android instrumented/UI tests (none exist in the project); network-traffic capture on a real device; Play Data safety consistency.

## Compliance suite (43) — full output
```
PASS age: declare maps choices, never verified
PASS age: unknown/under18/missing are child-safe; only self-declared adult is not
PASS age: stored record cannot be tampered into verified
PASS age: legacy integer conversion incl. boundaries and junk
PASS age: exact 18th birthday arithmetic (17y364d, 18y0d, 18y+, leap day, invalid)
PASS rules: no universal consent-age constant; 18 child age; behaviour not date-gated; Gazette flag present
PASS consent: grant records version, timestamp, tz, unverified age; append-only withdrawal
PASS consent: adult-only purposes refused for under18/unknown/missing age; others need notice version
PASS consent: corrupt or hostile storage is tolerated
PASS retention: shipped config valid; every period unset; no blanket period; Rule 8(3) not coded
PASS retention: validator rejects hard-coded unresolved or blanket periods
PASS gate: permissions by age status and consent
PASS gate: sanitizeProfile strips health fields, child name, pregnancy mode, legacy age
PASS gate: withdrawal cascades (health fields + suspended; history/fav/labels/cache)
PASS migrate: legacy adult with health data -> suspended, profile stripped, notices, age record self-declared
PASS migrate: legacy child / junk age -> health, name, history, cache deleted; kids mode
PASS migrate: idempotent, fresh install, corrupt profile, notices dismissible
PASS registry: every storage key literal used by the app source is registered
PASS registry: deleteCategories removes only the named categories; unregistered() detects strays
PASS wipe: clears localStorage, sessionStorage, IndexedDB, CacheStorage, service workers, cookies; verifies and reports
PASS wipe: reports partial/blocked, unsupported and errors instead of claiming success
PASS verifier: not operational, cannot verify, install needs approval, never unlocks child health
PASS allergen: no allergies set -> NONE, no panel
PASS allergen: contains / may contain detected
PASS allergen: best case is NO_MATCH_IN_AVAILABLE_INFO, qualified, never "clear"/"safe"
PASS allergen: unreadable OCR / unrecognised text / rescued -> never reassuring
PASS allergen: missing text / empty product record -> NOT_POSSIBLE / INCOMPLETE
PASS allergen: OFF data date: old/cached-old -> OUTDATED; unknown date still caveated; fresh ok
PASS allergen: declared allergen tags matched even if ingredient text silent
PASS allergen: terms shorter than 3 characters are handled, never silently dropped
PASS allergen: one allergy matched + another not -> warning plus qualified status for the other
PASS allergen: custom allergen outside dictionary is matched literally
PASS ui: misleading absolute wording removed from app source
PASS ui: score wording matches the actual score bands exactly (75/50/25)
PASS ui: onboarding markup — no pre-selected age, nothing pre-ticked, legal links, new storage-gated controls
PASS ui: CSP no longer allows Open Food Facts images; connect-src only OFF
PASS ui: history/favourites/labels/cache writes are consent-gated in source
PASS scoring: engine/nutrition/advice/ingredients files byte-identical to the supplied baseline
PASS lookup: OFF request adds only last_modified_t (a response field); data date parsed; no profile data in request
PASS legal: drafts carry REQUIRED INPUT placeholders, never production-ready, no invented identity
PASS legal: privacy draft discloses category search to Open Food Facts and ML Kit uncertainty; states health/child limits
PASS legal: HTML rendering escapes and highlights placeholders
PASS docs: docs/PRIVACY_POLICY.md and TERMS.md are generated from legal.js (in sync)

compliance tests: 43/43 passed
exit=0
```
## E2E (46) — full output
```
PASS fresh install opens onboarding
PASS no age option pre-selected, no box pre-ticked
PASS cannot save without choosing an age status
PASS under-18: child notice shown, health/history/nickname hidden
PASS under-18: only stricter-child mode selectable
PASS age record: under18, self-declared, verified=false
PASS ledger: only terms/privacy ack with notice version + timestamp
PASS child profile: kids mode, no name, no health data
PASS child scan works without profile
PASS child: nothing saved to history
PASS child: no network request during text scan
PASS barcode lookup contacts only world.openfoodfacts.org with fields param
PASS request carries no profile/age/allergy data
PASS child: offline cache not written
PASS settings shows self-declared age, unavailable parental authorisation, health off
PASS no "verified"/"compliant" claim in privacy card
PASS legal viewer: draft banner + placeholders highlighted
PASS legal viewer: no invented email/phone/company
PASS legal viewer closes
PASS child session: no JS errors
PASS adult: health & history blocks visible, fields locked until consent
PASS health consent unlocks fields and pregnancy mode
PASS 1-letter allergy entry rejected with message (not silently dropped)
PASS ledger: terms + health + history granted, adult self-declared
PASS adult profile holds allergies only with consent
PASS clean label -> qualified "No match found in the available information"
PASS no "Allergy Check Clear" / "Safe Choice" anywhere in result
PASS score band wording shown as range
PASS analysis saved to history with consent
PASS peanut label -> ALLERGY WARNING
PASS unreadable text never gives a reassuring allergy message
PASS OFF product -> source and data date shown, still qualified
PASS offline cache written with cachedAt (consent given)
PASS withdraw health: fields deleted, ledger keeps withdrawn record
PASS withdraw history: history/fav/labels/cache deleted
PASS adult session: no JS errors
PASS pre-wipe: all six stores populated
PASS post-wipe: every store empty (verified in the browser)
PASS wipe report lists each store and the not-deletable items
PASS after wipe + restart: onboarding again, no age/consent remembered
PASS legacy adult: forced through new consent screen with explanatory notice
PASS legacy adult: health data suspended (unused), mode reset, age field removed, prefilled for re-consent
PASS legacy adult: adult radio pre-set from legacy field (user can change)
PASS legacy adult: health consent NOT pre-ticked
PASS legacy child: health, name and history deleted; kids mode; notice shown
PASS migration sessions: no JS errors

browser e2e: 46/46 passed
exit=0
```
## verify.js — output
```
selftest ok NS-SVKCZZ 55 Okay unknown: -
phase2 selftest ok, DB 354
phase4 selftest ok: offline barcode and label scan agree NS-SVKCZZ 55
phase6 selftest ok: whole-pack text trimmed, garbled pack recognised, no false snap
phase7 selftest ok: garbled pack rescued (6 known ingredients, low confidence, allergy not clear)
phase8 selftest ok: crop box geometry and known-pack suggestion
phase9 selftest ok: global additive names recognised (6 of 6, DB 354)
phase11 selftest ok: disclaimer, licences, delete-data present; consent not pre-ticked
phase12 selftest ok: boxes split, nutrition identical on all routes (overall 45), reset on new scan
modes: 17/17 cases pass
accuracy: 25/25 labels pass, average coverage 100%
check-deps ok: no denied SDK; hosts referenced in app code: world.openfoodfacts.org
PASS age: declare maps choices, never verified
PASS age: unknown/under18/missing are child-safe; only self-declared adult is not
PASS age: stored record cannot be tampered into verified
PASS age: legacy integer conversion incl. boundaries and junk
PASS age: exact 18th birthday arithmetic (17y364d, 18y0d, 18y+, leap day, invalid)
PASS rules: no universal consent-age constant; 18 child age; behaviour not date-gated; Gazette flag present
PASS consent: grant records version, timestamp, tz, unverified age; append-only withdrawal
PASS consent: adult-only purposes refused for under18/unknown/missing age; others need notice version
PASS consent: corrupt or hostile storage is tolerated
PASS retention: shipped config valid; every period unset; no blanket period; Rule 8(3) not coded
PASS retention: validator rejects hard-coded unresolved or blanket periods
PASS gate: permissions by age status and consent
PASS gate: sanitizeProfile strips health fields, child name, pregnancy mode, legacy age
PASS gate: withdrawal cascades (health fields + suspended; history/fav/labels/cache)
PASS migrate: legacy adult with health data -> suspended, profile stripped, notices, age record self-declared
PASS migrate: legacy child / junk age -> health, name, history, cache deleted; kids mode
PASS migrate: idempotent, fresh install, corrupt profile, notices dismissible
PASS registry: every storage key literal used by the app source is registered
PASS registry: deleteCategories removes only the named categories; unregistered() detects strays
PASS wipe: clears localStorage, sessionStorage, IndexedDB, CacheStorage, service workers, cookies; verifies and reports
PASS wipe: reports partial/blocked, unsupported and errors instead of claiming success
PASS verifier: not operational, cannot verify, install needs approval, never unlocks child health
PASS allergen: no allergies set -> NONE, no panel
PASS allergen: contains / may contain detected
PASS allergen: best case is NO_MATCH_IN_AVAILABLE_INFO, qualified, never "clear"/"safe"
PASS allergen: unreadable OCR / unrecognised text / rescued -> never reassuring
PASS allergen: missing text / empty product record -> NOT_POSSIBLE / INCOMPLETE
PASS allergen: OFF data date: old/cached-old -> OUTDATED; unknown date still caveated; fresh ok
PASS allergen: declared allergen tags matched even if ingredient text silent
PASS allergen: terms shorter than 3 characters are handled, never silently dropped
PASS allergen: one allergy matched + another not -> warning plus qualified status for the other
PASS allergen: custom allergen outside dictionary is matched literally
PASS ui: misleading absolute wording removed from app source
PASS ui: score wording matches the actual score bands exactly (75/50/25)
PASS ui: onboarding markup — no pre-selected age, nothing pre-ticked, legal links, new storage-gated controls
PASS ui: CSP no longer allows Open Food Facts images; connect-src only OFF
PASS ui: history/favourites/labels/cache writes are consent-gated in source
PASS scoring: engine/nutrition/advice/ingredients files byte-identical to the supplied baseline
PASS lookup: OFF request adds only last_modified_t (a response field); data date parsed; no profile data in request
PASS legal: drafts carry REQUIRED INPUT placeholders, never production-ready, no invented identity
PASS legal: privacy draft discloses category search to Open Food Facts and ML Kit uncertainty; states health/child limits
PASS legal: HTML rendering escapes and highlights placeholders
PASS docs: docs/PRIVACY_POLICY.md and TERMS.md are generated from legal.js (in sync)

compliance tests: 43/43 passed
verify ok
phase10 selftest ok: on-device reader is tried first and accepted when clean
verify exit=0
```
## Stress
```
stress test: all passed | 20,000 analyses in 43681 ms (458 per second) | heap growth -8.6 MB
stress exit=0
```
Machine-readable: `docs/test-results/compliance-test-results.json`, `docs/test-results/e2e-results.json`. Raw logs in `logs/`.

## Run after round 2 (desktop Chromium + Node only)
| Check | Result |
|---|---|
| `npm ci`, `scripts/prep.js`, `scripts/verify.js` | pass |
| `scripts/compliance-test.js` | 45/45 passed (adds per-document consent versions, privacy wording, contact/country purge for adult, under-18 and unknown) |
| `scripts/e2e/browser_e2e.py` | 79/79 passed (adds per-document re-acceptance, voice on/off on every screen, default-mode flow, scoring unchanged) |
| `scripts/legal-gate.js` | runs; 17 [REQUIRED INPUT] placeholders outstanding; builds labelled NOT FOR PRODUCTION |
| Android APK/AAB build (GitHub Actions) and device testing | **NOT run**. Nothing here is verified on Android |

The older sections above show the original 43/46 results and are kept as history.
