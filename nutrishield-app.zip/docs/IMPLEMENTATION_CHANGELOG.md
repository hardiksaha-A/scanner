# NutriShield India Compliance — Implementation Changelog
Branch `india-compliance` (commit 0204451) on top of `baseline` (b63a6f2 = unmodified contents of `nutrishield-app.zip`). Git diff vs baseline: 28 files changed, 2094 insertions(+), 125 deletions(-).
Original ZIPs unchanged (sha256 `70a62a77…` and `49b2f585…` re-checked after all work).

## Changes by area
| Area | Change | Files |
|---|---|---|
| Age status | Free "age 1–120" removed. Three self-declared options (18+, under 18, prefer not to say), none pre-selected. Stored as `ns.age.v1` with `verified:false` always. Exact DOB arithmetic helper exists and is tested but the UI does not collect DOB | `www/compliance/age.js`, `index.html` |
| Rules registry | India rules as DATA: separate majority / DPDP-child / digital-consent concepts; regimes flagged "Gazette verification pending"; S.O. 5458(E) flagged UNVERIFIED. Behaviour is NOT date-gated: strictest controls apply now | `rules.js` |
| Consent ledger | Append-only per-purpose records (terms/privacy ack, health profile, history) with notice version, doc versions, UTC time + tz offset, language, age status, `ageVerified:false`. Adult-only purposes refused for under-18/unknown | `consent.js` |
| Gate | Under-18/unknown/missing: no health profile, no nickname, no history/favourites/labels/offline cache, only the stricter-child mode. Health fields, pregnancy mode cannot exist in the stored profile without adult + consent | `gate.js` |
| Optional profile | Name optional (adults). Health profile behind its own unticked consent. History/cache behind its own unticked consent. Scanning works with no profile | `index.html` |
| Migration | One-time schema 1→2. Legacy adult health data moved to an unused "suspended" store until re-consent. Legacy under-18/unknown: health data, name, history, favourites, labels, cache deleted; one-time notice shown. Legacy `age` removed | `migrate.js` |
| ParentVerifier | Interface + disabled stub, status text "not available in this version". `install()` needs a provider and counsel approval reference; even installed, child health stays blocked by the gate | `verifier.js` |
| Retention | Per-category config, every period `null`; validator rejects hard-coded Rule 8(3) / consent / verification / security-log periods, any blanket key, and any numeric period lacking `PRODUCT_DECISION` source | `retention.js` |
| Deletion | `Delete All My Local Data` → `Wipe.deleteAll`: localStorage, sessionStorage, IndexedDB, CacheStorage, service workers, cookies; verifies afterwards; shows per-store report and a list of what the app cannot delete. Per-category deletes and consent withdrawal cascade in Settings | `wipe.js`, `registry.js`, `index.html` |
| Allergen safety | New 7-state result. "Allergy Check Clear" and "Good / Safe Choice" removed. Best case is "No match found in the available information" with source, data date, and explicit non-guarantee. Not reassuring if OCR uncertain, coverage < 80%, no ingredient list, data older than 365 days, or any allergy entry cannot be checked. Entries of 2 letters match whole words only; 1-letter / non-Latin entries are reported, never dropped | `allergen.js`, `index.html`, `features.js` (spoken line) |
| Score wording | Words now match bands exactly: Higher 75–100, Moderate 50–74, Low 25–49, Very low 0–24. Scoring files byte-identical to baseline (hash test) | `index.html` |
| Data date | OFF request now also asks for response field `last_modified_t` (no new data sent). Cached products get `cachedAt` | `lookup-web.js`, `index.html` |
| Legal viewer | In-app Privacy Policy and Terms (drafts) from onboarding and Settings; version `draft-0.1.0`; placeholders highlighted; banner "Not approved for production". `docs/*.md` generated from same source. Privacy draft now discloses the category search to OFF and ML Kit uncertainty | `legal.js`, `index.html`, `docs/PRIVACY_POLICY.md`, `docs/TERMS.md`, `scripts/build-legal-docs.js` |
| Country | Locale guess kept as a suggestion; `countrySource` recorded (`user`/`locale_guess`/`unset`) and shown | `index.html` |
| CSP | Removed OFF from `img-src` (no OFF images used) | `index.html` |
| Packaging | `@capacitor/cli` moved to devDependencies; `npm audit --omit=dev` = 0 vulnerabilities (was 5) | `package.json`, `package-lock.json` |
| Guards | `check-deps.js` fails on ad/analytics/crash/cloud SDK names or unapproved hosts; `legal-gate.js` labels builds with draft legal text | `scripts/` |
| CI | No silent plugin dropping; `drop_mlkit`/`drop_tts` manual inputs; versionName/versionCode set; AAB build + jarsigner signing only if the four RELEASE_* secrets exist, else labelled UNSIGNED; build-info + merged-manifest permission audit; artifacts suffixed `-DRAFT-LEGAL-NOT-FOR-PRODUCTION`; public "latest" release publishing now opt-in | `build.yaml` |
| Tests | 43 Node compliance tests; 46-check real-Chromium E2E; wired into `verify.js` | `scripts/compliance-test.js`, `scripts/e2e/browser_e2e.py` |

## File list (git name-status vs baseline)
```
A	build.yaml
M	docs/PRIVACY_POLICY.md
M	docs/TERMS.md
M	docs/TESTING.md
A	docs/test-results/compliance-test-results.json
A	docs/test-results/e2e-results.json
M	package-lock.json
M	package.json
A	scripts/build-legal-docs.js
A	scripts/check-deps.js
A	scripts/compliance-test.js
A	scripts/e2e/browser_e2e.py
A	scripts/legal-gate.js
M	scripts/verify.js
A	www/compliance/age.js
A	www/compliance/allergen.js
A	www/compliance/consent.js
A	www/compliance/gate.js
A	www/compliance/legal.js
A	www/compliance/migrate.js
A	www/compliance/registry.js
A	www/compliance/retention.js
A	www/compliance/rules.js
A	www/compliance/verifier.js
A	www/compliance/wipe.js
M	www/features.js
M	www/index.html
M	www/lookup-web.js
```
## Behaviour changes users will notice
Onboarding screen replaced; nickname optional; allergies/conditions/pregnancy need a separate consent; history/favourites/offline cache are OFF until an adult opts in (previously automatic); under-18/unknown users get no health profile or history; result wording changed; kids-mode label no longer says "Under 13", senior no longer "60+".

## Change 1 (post-handover): email and mobile made optional
- www/index.html: pEmail/pMobile (profile) and sEmail/sMobile (settings) enabled, optional, validated if filled, adults only (hidden for under-18/not stated).
- www/compliance/gate.js: sanitizeProfile clears email/mobile for non-adults and clamps types. registry.js + legal.js (privacy wording) updated; docs regenerated.
- scripts/compliance-test.js: PII-disabled assertion replaced; contact-gating tests added. Scoring/allergen files untouched.

## Change 2: Terms/Privacy approval asked once
- www/index.html: profile editor hides the Terms/Privacy tick box (#pConsentWrap) when an active acceptance for the current Legal.VERSION exists; shown again if never accepted or the version changes. Terms/Privacy stay viewable from Settings.
- scripts/e2e/browser_e2e.py: +6 checks (section 2b).

## Change 3: main-page text removed
- www/index.html: removed header chip "No AI • Rule-Based" and the category chip row (Food & Beverages, Cosmetics, Personal Care, Household). No JS referenced them. Result-card formula note and legal disclaimers unchanged.

## Change 4: voice on/off and country select at top of main page
- www/index.html: #topBar in scan view with #topVoiceBtn (same setting as Settings auto-voice, key nutrishield.speak; turning off stops speech) and #topCountry (data-country-select, so it shares the existing country handler and stays synced with Settings/profile).
- scripts/e2e/browser_e2e.py: +9 checks (section 2c).

## Round 2 (supersedes parts of Changes 1, 2 and 4)
- Email/mobile (supersedes Change 1): fields removed from the profile and Settings; `gate.js` deletes `email`, `mobile`, `country`, `countrySource` from stored profiles; registry/retention text and Privacy Policy updated.
- Terms/Privacy (supersedes Change 2): `legal.js` now exports `VERSIONS` (privacy `draft-0.2.0`, terms `draft-0.1.0`) and `HISTORY` instead of one `VERSION`; `consent.js` ledger gained `acceptance()` (per-document, records never rewritten); `index.html` blocks the app and navigation until both current versions are accepted and names only the changed document; generated docs include a "Version history" section.
- Result card: "Rule-Based Formula (Point 10 — Zero AI)" heading replaced by "How the score is calculated".
- Default mode: `applyFormGating` keeps the person's chosen mode (default Adult for 18+, Kids for under 18/unstated).
- Voice (extends Change 4): `speakText` refuses when Voice is Off; Speak Result Aloud and Test Voice are disabled while Off.
- Country (supersedes Change 4): selector removed from the top bar, profile and Settings; no country is stored or shown.
- Tests: compliance 43 -> 45; browser E2E 61 -> 79. Docs updated: Privacy/Terms (generated), data-flow inventory, gap matrix (G-11, G-13, G-14, new data-minimisation row), risk register (NS-34, IN-21), README, handover, test report.
